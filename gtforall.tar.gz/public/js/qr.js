
var quicksmart = {
	pos: -1,
	quote_op: function() {
		var txt = $("#thread-edit textarea").val();
		this.quote(txt);
	},
	quote_reply: function(el) {
		var txt = el.closest('.posts-left-inner').find('.posts-edit textarea').val();
		this.quote(txt);
	},
	quote: function(txt) {
		txt = txt.split("\n");
		var data = [];
		for (var i in txt)
		{
			if (!txt[i]) { continue; }
			if (txt[i].indexOf('>') == 0) { continue; }
			if (txt[i].indexOf('[quote]') == 0) { continue; }
			
			data.push('> '+txt[i]); 
		}
		data = '\n\n'+data.join('\n\n\n\n')+'\n\n';
		$("#qr-message").append(data);
		bscroll('#qr-message');
		this.pop();
	},
	pop: function() {
		$("#qr-popper").attr('func','unpop').html('Collapse');
		$("#qr").addClass('qr-pop');
		
		$("#qr-message").focus();
		$("#qr-message").scrollTop($("#quickreply").scrollHeight-$("#quickreply").height());
		$("#page-wrapper").removeClass('page-center');
		
		// TODO: css(height), not height()
		$("#qr-message").height(screen.height-$("header").height()-$("#qr-tools").height()-220);
		$("#qr").width(screen.width-$(".posts-left:first").width()-68);
		bscroll("#quickreply");
	
		$("#op-wrapper").addClass('op-left');
		
		$("#qr-fullscreen").show();
		
		$(".posts-user-popped").show();
	},
	unpop: function() {
		$("#qr-popper").attr('func','pop').html('Expand');
		$("#qr").removeClass('qr-pop');

		$("#page-wrapper").addClass('page-center');
		$("#qr-message").height('initial');
		$("#qr").width('initial');
		$("#op-wrapper").removeClass('op-left');
		$(".posts-user-popped").hide();
		$("#qr-fullscreen").hide();
	},
	width: '',
	fullscreen: function() {
		this.width = $("#qr").css('width');
		$("#qr").css('width','100%');
		$("#qr-fullscreen").attr('func','shrink').html('Shrink');
	},
	shrink: function() {
		$("#qr").css('width',this.width);
		this.width = '';
		$("#qr-fullscreen").attr('func','fullscreen').html('Fullscreen');
	}
	
};

