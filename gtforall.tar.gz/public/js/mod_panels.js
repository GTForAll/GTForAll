$(".doc-edit").click(function(e)  {
e.preventDefault();
var docid = $(this).attr('docid');
var doc = _docs[docid];
$("#title").val(doc['title']);
$("#message").val(doc['message']);
$("#docid").val(docid);
window.scrollTo(0,0);
});
