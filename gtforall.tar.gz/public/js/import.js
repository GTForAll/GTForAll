function obj_size(obj)
{
    return Object.keys(obj).length;
}

function showspoiler(q)
{
	$("#spoilclick"+q).hide();
	$("#spoil"+q).fadeIn('fast');
}

function showtube(link,num)
{
	var area = $("#yt"+num);
	vv = link.replace('https://www.youtube.com/v/','');
	area.html('<input type="button" onclick="hidetube(\''+vv+'\',\''+num+'\');" value="Hide Youtube" /><br /><object width="640" height="385"><param name="movie" value="'+link+'&hl=en_US&fs=1"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="'+link+'&hl=en_US&fs=1" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="640" height="385"></embed></object>');
	area.parent().css('height','auto');
}

function hidetube(link,num)
{
	var area = $("#yt"+num);
area.html('<div id="yt'+num+'" class="show-youtube"><img src="http://i3.ytimg.com/vi/'+link+'/default.jpg" onclick="showtube(\'http://www.youtube.com/v/'+link+'\',\''+num+'\');" /></div>');
	area.parent().css('height','auto');
}