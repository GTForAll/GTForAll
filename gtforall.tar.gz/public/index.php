<?php

if (strpos($_SERVER['REQUEST_URI'],'moonraygames.co.uk') !== false) { die; }

ini_set('session.cache_limiter','public');
session_cache_limiter(false);
session_start();
require "../Website.php";
$site = new Website();

$site->log_user();

if ($_POST)
{
    $site->post();
}

$site->route();

if (!$dont_save_page)
{
    $_SESSION['last_page'] = $_SERVER['REQUEST_URI'];
}
