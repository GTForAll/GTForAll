<?php
Class Engine_Disclaimer
{
    public function is_signed($forum)
    {
    
        if (!$forum['disclaimer']) { return true; }

        $fid = $forum['fid'];

        if (my('uid') && Read::signed()->by_uid($fid,my('uid')))
        {
            return true;
        }
        elseif (Read::signed()->by_ip($fid,my('ip')))
        {
            return true;
        }
        return false;
    }
}
