<?php
Class Engine_Pages
{
    private $tid, $replies;
    
    public $type,$amt,$disable,$onpage;
    
    private $setup = false;
    
    public $last_page;
    
    public function init($tid,$replies=0)
    {
        $this->tid = $tid;
        $this->replies = $replies;
        
        $this->type = 'posts';
        $this->amt = get_setting('pagination_amt') ?: 7;
        
        $this->disable = false;
        
        // Highlighting should override this
        if ($this->disable)
        {
            $this->disable_style = 'display: none';
        }
        
        $this->onpage = 1;
        
        $read_pid = Read::views()->get_read_tid(my('uid'),$tid);
        
        if ($read_pid)
        {
            $post_number = Read::posts()->count_from($tid,$read_pid);
            $this->onpage = ceil($post_number/$this->amt);
        }   
        
        $this->last_page = ceil($this->replies/$this->amt);
        
        $this->setup = true;
    }
    
    public $page = 0;
    public function paginate($i)
    {
        if (!$this->setup) { return; }
        
        if ($i % $this->amt == 1)
        {
            $this->page++;
        }
        return ' page-'.$this->page;
    }
    
    public function hide_pages($i)
    {
        
        if (!$this->setup) { return; }
        
        if ($this->page != $this->onpage && !($this->page == 0 && $this->onpage == 1))
        {
            return 'display: none;';
        }
    }
    
    public function page_to_pid($page)
    {
        if (!$this->setup) { return; }
        
        // Page 1 should be page 0, etc
        $page--;
        $offset = $this->amt*$page;
        // Ignore OP's
        $offset++;
        
        $pid = ZXC::sel('pid/posts')->where('tid',$this->tid)->lim(1)->off($offset)->sort('dateline++')->one();
        return $pid;
    }
    
    // ----------------
    
    public function post_top()
    {
        if (!$this->setup) 
        {
            Engine::plugins()->bar('post_pagination');
            return; 
        }
        
        $onpage = $this->onpage;
        $chunk = 1;
        
        if ($this->replies <= $this->amt)
        {
            return;
        }
        
        $last_page = $this->last_page;
        
        $chunk_last = $last_page-$chunk;
        $chunk_first = 1+$chunk;
        ?>
        
        <style type="text/css">
            #post-pages {
                position: relative;
            }

            #post-pages-amt {
                width: 3em;
                text-align: center;
            }
        </style>
        
        <div id="post-pages" class="post-pages">
            
            
            <div id="post-pages-links" class="post-pages-links" style="<?=$this->disable_style?>">
                <?php if ($this->onpage != 1) { ?>
                <a href="" page="prev" id="prev-page">Previous Page</a>
                <?php } ?>
                <a href="" page="all">Load all posts</a>
                <span class="page-disp">On page:</span>
                <?php for ($i = 1; $i <= $last_page; $i++) { 
                    $style = 'display: none;';
                    $class = 'page-link-hidable';
                    
                    $id = 'id="page-link-'.$i.'"';
                    
                    if ($i <= $chunk_first || $i >= $chunk_last) { $style = ''; $class = ''; }
                    if ($i == $onpage || $i == $onpage-1 || $i == $onpage+1) { $style = ''; }
                    
                    // ellipses
                    if ($i == $chunk_first+1)
                    {
                        $class .= ' page-chunk-1';
                        $dotid = 'dots-1';
                        $dotstyle = '';
                        if ($onpage <= $chunk_first+2) { $dotstyle = 'display: none;'; }
                        echo '<span class="dots '.$dotclass.'" id="'.$dotid.'" style="'.$dotstyle.'">...</span>';
                    }
                    
                    if ($i == $chunk_last-1)
                    {
                        $class .= ' page-chunk-2';
                        $dotid = 'dots-2';
                        $dotstyle = '';
                        if ($onpage >= $chunk_last-2) { $dotstyle = 'display: none;'; }
                        echo '<span class="dots" id="'.$dotid.'" style="'.$dotstyle.'">...</span>';
                    }
                    
                    if ($i == $onpage) { $class .= ' current-page'; }
                ?>
                <a href="" page="<?=$i?>" style="<?=$style?>" class="<?=$class?>" <?=$id?>><?=$i?></a>
            <?php } ?>
            
            <?=Engine::plugins()->settings_link('post-pages-settings')?>
            
            </div>            
        </div>
        
        <div id="post-pages-settings" class="post-pages plugin-settings" style="margin-top: 10px; display: none;">
        <div class="post-pages-links">
            <a href="" obj="pages" func="disable"><?=ic('extension',15)?>Disable Pagination</a>
            <span class="page-disp">Posts per thread: </span><input value="<?=$this->amt?>" id="post-pages-amt" /> 
            <a href="" obj="pages" func="save_settings">Save</a>
        </div>
        </div>
        
    <?php
    }

    public function post_bottom() 
    {
        if (!$this->setup) { return; }
        if ($this->replies <= $this->amt) { return; }
        
        ?>
        <div class="post-pages" id="bottom-navigation" style="<?=$this->disable_style?>">
            <div class="post-pages-links" id="post-pages-bottom">
                <a href="" action="load_next">Next page</a>
                <a href="" action="load_rest">Load rest of pages</a>
                <span class="page-disp">On page:</span>
                <span class="page-disp"><span id="bottom-curr-page"></span> / <span id="bottom-total-pages"></span> </span> 
            </div>
        </div>
        <?php
    }
}