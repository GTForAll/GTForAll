<?php
Class Engine_Nav
{
    public function uptop()
    {
        if (!my('uid'))
        {
            $navs = Array(
                'register' => Array('icon' => 'perm_identity', 'link' => '/register'),
                'login' => Array('icon' => 'vpn_key', 'link' => '/login'),
    
            );
        }
        else
        {
            // logout, user cp, people
            $navs = Array(
                'logout' => Array('icon' => 'exit_to_app', 'link' => '/logout'),
                'user_CP' => Array('icon' => 'settings', 'link' => '/CP')
            );
            
            
            $alerts = Read::alerts()->my_unarchived();
            
            if ($alerts)
            {
                $color = 'aaf';
                if ($alerts[0]['status'] == 'new')
                {
                    $color = 'faa';
                }
                $navs['alerts'] = Array('icon' => 'notifications_active', 'color' => $color, 'ajax_html' => 'alerts');
            }
            
            if (iam('mod'))
            {
                $navs['mod'] = Array('icon' => 'vpn_lock', 'ajax_html' => 'mod');
            }
        }
        
        /*'people' => Array('icon' => 'group', 'ajax_html' => 'people'),*/
        
        // site feed
        $navs['search'] = Array('icon' => 'search', 'link' => '/search');
        $navs['people'] = Array('icon' => 'group', 'ajax_html' => 'people');
        $navs['site_feed'] = Array('icon' => 'update', 'link' => '/feed');
        
        if (installed('newest_replies'))
        {
            $navs['replies'] = Array('icon' => 'update', 'link' => 'newest_replies');
        }
        
        Engine::view()->add_navs($navs);
    }
}