<?php
Class Engine_Process
{
    private $post, $thread;
    public function message($pid,$message) {
        $this->post = Read::posts()->by_pid($pid);
        $this->thread = Read::threads()->by_tid($this->post['tid']);
        
        if (has($message,'[[') && has($message,']]'))
        {
            $proc = explode('[[',$message);
            $proc = $proc[1];
            $proc = explode(']]',$proc);
            $proc = $proc[0];
            
            $arr = explode(';',$proc);
            
            foreach ($arr as $row)
            {
                $kv = explode(':',$row);
                
                $fname = trim(array_shift($kv));
                
                $val = trim(implode(':',$kv));
                
                $func = 'process_'.$fname;
                $op_func = 'process_OP_'.$fname;
                
                if (method_exists('Engine_Process',$op_func) && $pid == $this->thread['firstpost']) 
                {            
                    $this->$op_func($val);      
                }
                else if (method_exists('Engine_Process',$func))
                {                
                    $this->$func($val); 
                }
            }
            
            $message = str_replace('[['.$proc.']]','',$message);
        }
        
        return $message;
    }
    
    // -----------------------
    
    public function process_OP_icon($icon)
    {
        if (!has($icon,'https'))
        {
            $icon = str_replace('http','https',$icon);    
        }
        
        $icon = str_replace('"','&quot;',$icon);
        
        Write::threads()->set_icon($this->thread['tid'],$icon);
    }    
    
    // ---
    
    public function process_tag($val)
    {
        $val = explode(',',$val);
        
        $link = '/thread/'.$this->thread['slug'].'/hi='.$this->post['pid'];
        
        $message = $this->post['user'].' tagged you in a post.';
        
        foreach ($val as $name)
        {
            $uid = Engine::sherlock()->find_uid($name);
            if (!$uid) { continue; }
            Write::alerts()->add($uid,$message,$link);
        }
    }
}