<?php
Class Engine_Quirks
{
    public function submit_thread_survey($tid,$data)
    {
        $survid = Write::surveys()->add($tid);
        // survey_questions, survey_types, survey_choices
        foreach ($data['survey_questions']?:Array() AS $key => $question)
        {
            if (!$question) { continue; }
            $quid = Write::surveys()->add_question($survid,$data['survey_types'][$key],$question);
            $answers = explode(',',$data['survey_choices'][$key]);
            foreach ($answers?:Array() AS $answer)
            {
                Write::surveys()->add_answer($quid,$answer);    
            }
        }
    }
    
    public function input_post_survey($tid)
    {
        $survey = Read::surveys()->by_tid($tid);
        $questions = pair(Read::surveys()->questions_by_survid($survey['survid']),'quid');
        $answers = Read::surveys()->answers_by_survid($survey['survid']);
        $arr = Array(
            'survey' => $survey,
            'questions' => $questions
        );
        foreach ($answers as $answer) 
        {
            $arr['questions'][$answer['quid']]['answers'][$answer['answerid']] = $answer['value'];
        }
        
        foreach ($questions as $quid => $question)
        {
            if ($question['type'] == 'free_poll')    
            {
                $arr['questions'][$quid]['answers']['custom'] = '-- Custom --';    
            }
        }
        
        $arr['survey'] = $survey;
        $arr['responses'] = Read::surveys()->responses_by_user(my('user')) ?: Array();
        $arr['aggregate'] = Read::surveys()->survey_responses($survey['survid']);
        
        return $arr;
    }
    
    public function submit_post_survey($pid,$data)
    {
        $responses = Read::surveys()->responses_by_user($data['user']);
        $prev = Array();
        foreach ($data['survey_answer']?:Array() AS $quid => $answer)
        {
            $question = Read::surveys()->question_by_quid($quid);
            
            $full_answer = $answer;
            $text_answer = '';
            
            if ($question['type'] == 'poll' || $question['type'] == 'free_poll')
            {
                $full_answer = Read::surveys()->get_answer_by_answerid($answer);
            }
            else if ($question['type'] == 'text')
            {
                $text_answer = $answer;
                $answer = 0;
                $full_answer = $text_answer;
            }
            
            if ($data['survey_answer_custom'][$quid])
            {
                $text_answer = $data['survey_answer_custom'][$quid];
                $answer = 0;
                
                $full_answer = $text_answer;
            }
            
            $prev = $responses[$quid];
           
           
            Write::surveys()->alter_response($data['survid'],$data['user'],$quid,$answer,$text_answer);
            
            if ($prev['canon'] != $answer || $prev['text_answer'] != $text_answer)
            {
                Engine::interaction()->add_message('<span class="interact-survey-question">'.$question['name'].'</span><span class="interact-survey-answer">'.$full_answer.'</span>');
            }
        }
    }
    
    // ----------------------
}