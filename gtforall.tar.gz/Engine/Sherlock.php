<?php
Class Engine_Sherlock
{
    public function find_uid($name)
    {
        // account name?
        $uid = ZXC::sel('uid/users')->like('username',$name)->the();
        if ($uid) { return $uid; }

        $uu = ZXC::sel('nameid/names')->like('username',$name)->the();
        if (!$uu) { return; }

        // primary user?
        $uid = ZXC::sel('uid/users')->where('primary_nameid',$uu)->the();
        if ($uid) { return $uid; }

        // TODO: Altnames
    }

    // --

    public function filter($filters,$data=Array())
    {
        foreach ($filters?:Array() as $row)
        {
            if ($row['field'] == 'ip')
            {
                $val = my('ip');
            }
            elseif ($row['field'] == 'host')
            {
                $val = my('host');
            }
            elseif ($row['field'] == 'user')
            {
                $val = $data['user'];
            }

            if ($row['type'] == 'is')
            {
                if ($val == $row['value'])
                {
                    return true;
                }
            }
            elseif ($row['type'] == 'contains')
            {
                if (has($val,$row['value']))
                {
                    return true;
                }
            }
        }
        return false;
    }
}
