<?php
Class Engine_Routes
{

    public function __call($func,$args)
    {
        $func = str_replace('route_','',$func);
        $this->title(deslug($func));
        $this->view($func);
    }

    private $REQ = Array();

    public function get()
    {
        $REQ = explode('/',$_SERVER['REQUEST_URI']);
        array_shift($REQ);
        $this->request = $REQ;

        // Fix fbclid nonsense
        $succerman = false;
        foreach ($REQ as $key => $val)
        {
            if (has($val,'?fbclid'))
            {
                $val = explode('?fbclid',$val);
                $REQ[$key] = $val[0];
                $succerman = true;
            }
            if (has($val,'='))
            {
                $val = explode('=',$val);
                $_REQUEST[$val[0]] = $val[1];
            }
        }

        if ($succerman)
        {
            return redir_to('/'.implode('/',$REQ));
        }

        $type = $REQ[0];
        $id = $REQ[1];

        if (has($_SERVER['REQUEST_URI'],'.php'))
        {
            redir_to('/');
        }

        if (!$REQ[0])
        {
            $type = 'index';
        }

        return Array(
            'type' => $type,
            'id' => $id,
            'index' => $REQ[2]
        );
    }

    public function alter_url($index,$value)
    {
        $req = $this->request;
        $req[$index] = $value;

        return '/'.implode('/',$req);
    }

        private function title($title)
        {
            Engine::view()->set_title($title);
        }

        private function view($src,$data=Array())
        {
            Engine::view()->add_file($src,$data);
        }

        private function js($arr)
        {
            foreach ($arr?:Array() AS $key => $value)
            {
                Engine::view()->set_js($key,$value);
            }
        }

        // ----

        private function error($message)
        {
            $GLOBALS['page_error'] = $message;
        }

    // ---------------

        private function info($page) {
            sidepage();
            page('no_uptop',true);
            page('no_footer',true);
            Engine::view()->add_css('info');
            return $this->view($page);
        }

    /*
    public function route_session() {
        die(my('sessid'));
    }*/



    public function route_temp() {
        Engine::__temp()->run();
        die;
    }

    public function route_t() {
        $htm = file_get_contents('../public/js/textris.js');
        echo $htm; die;
    }

    public function route_mod($slug, $panel, $var1=0)
      {

        $forum = Read::forums()->by_slug($slug);

        if (!iam('mod'))
          {

            $error_text= 'you are not a saxophone player';
            return $this->error($error_text);

          }

          $data = Array();
          $this->title($forum['name'].' '.deslug($panel).' CP');

          $func = 'panel_'.$panel;
          if (method_exists(Engine::mod_panel_data(),$func))
          {
              $data = Engine::mod_panel_data()->$func($forum['fid'],$var1);
          }

          $data = Array(
          'data' => $data,
          'forum' => $forum
          );

          return $this->panel($panel,$data,'mod');


      }

    public function route_ipseeder() {
        $ip = my('ip');
        $totes = 1;
        for ($i = 0; $i < strlen($ip); $i++)
        {
            $totes *= ord($ip[$i]);
            $totes %= 438583;
        }
        srand($totes);
        echo genhash(6);
        die;
    }

    public function route_events() {
        Engine::events()->render();
        die;
    }

    public function route_login() {
        $this->title('Login');
        return $this->info('login');
    }

    public function route_register() {
        $this->title('Register');
        if (get_var('registrations_locked'))
        {
            return $this->view('lockdown', Array('message' => 'No new registrations can be done at this time.'));
        }
        return $this->info('register');
    }

    public function route_logout() {
        sidepage();
        Engine::auth()->logout();
        last_page();
    }

    public function route_rules() {
        $this->title('Site Rules');
        return $this->view('rules');
    }

    public function route_old_rules() {
        $this->title('Site Rules');
        return $this->view('old_rules');
    }

    public function route_principles() {
        $this->title('Site Principles');
        return $this->view('principles');
    }

    public function route_community() {
        $this->title('Community Feedback Model');
        return $this->view('old_community');
    }

    public function route_new_community() {
        $this->title('Community Feedback Model');
        return $this->view('community');
    }

    public function route_posting_stats($user='') {
        if (!my('uid')) { return $this->error('You must be logged in.'); }
        $this->title('GT For All Posting Stats');

        $forums = Read::forums()->on_ql();
        $arr = Array();

        if (!$user)
        {
            $user = my('user');
        }
        else
        {
            $user = urldecode($user);
        }

        foreach ($forums as $forum)
        {
            $arr[] = Array(
                'forum_slug' => $forum['slug'],
                'forum_name' => $forum['name'],
                'threads' => ZXC::sel('=tid/threads')->where('fid',$forum['fid'],'user',$user)->the(),
                'posts' => ZXC::sel('=pid/posts')->where('fid',$forum['fid'],'user',$user)->the()
            );
        }

        $data = Array('stats' => $arr, 'user' => $user);

        return $this->view('posting_stats',$data);

    }

    // ------------

    public function route_ajax($func)
    {
        $data = Engine::ajax_routing()->$func($_POST);
        echo json_encode($data);
        die;
    }

    public function route_ajax_html($func)
    {
        Engine::ajax_html_routing()->$func($_POST);
        die;
    }

    public function route_index()
    {
        $this->title('Home');
        $forums = pair(Read::forums()->on_ql(),'fid');

        $data = Array(
            'forums' => $forums,
            'threads' => pair(Read::threads()->most_recent_by_fids(array_keys($forums)),'fid'),
            'thread_count' => pair(Read::threads()->count_by_fids(array_keys($forums)),'fid'),
            'post_count' => pair(Read::posts()->count_by_fids(array_keys($forums)),'fid')
        );
        $this->view('index',$data);
    }

    // -----

        // TODO: Would like to have navigation/etc soonish.
        private function fheader($forum)
        {
            Engine::view()->set_js('my_fid',$forum['fid']);

            if (!Engine::disclaimer()->is_signed($forum))
            {
                if (!my('uid'))
                {
                    $this->view('disclaimer',Array('type' => 'ip', 'forum' => $forum));
                }
                else
                {
                    $this->view('disclaimer',Array('type' => 'uid', 'forum' => $forum));
                }
                return 'break';
            }

            $forum['mods'] = Read::forums()->mods_by_fid($forum['fid']);
            if (!$forum['mods'])
              {
                // TODO: Heavily kludged
                $forum['mods'] = Read::forums()->mods_by_uids(Array(-73,5367));
              }

            $forum['docs'] = Read::documents()->by_fid($forum['fid']);

            $this->view('fheader',$forum);
        }

        private function forum_index($page,$data,$nav_dir,$new_thread_link='',$slug='')
        {
            $blocks = Read::blocks()->by_uid(my('uid'));

            if (!$page) { $page = 1; }

            $send = Array('threads' => $data, 'slug' => $slug, 'page' => $page, 'nav_dir' => $nav_dir, 'new_thread_link' => $new_thread_link, 'blocks' => $blocks);

            $this->view('pagination',$send);
            $this->view('forum',$send);
            $this->view('pagination',$send);
        }

    public function route_search($page) {

        $this->title('Search');
        if (!$_SESSION['search'])
        {
            $data = Engine::view()->data['forums'];
            $ql = Array();
            foreach ($data as $row)
            {
                $ql[$row['fid']] = $row['name'];
            }

            $this->view('search',Array('ql' => $ql));

            return;
        }


        $data = Engine::search()->threads($_SESSION['search'],$page);

        $say = '';
        foreach ($data['say'] as $key => $val)
        {
            $val = str_replace('*','<span class="search-wild">*</span>',$val);
            $say .= '<span class="search-block">';
            $say .= '<span class="search-key">'.deslug($key).'</span><span class="search-val">'.$val.'</span>';
            $say .= '</span>';
        }

        $this->view('new_search',Array('say' => $say));

        $this->forum_index($page,$data['data'],'/search',false);
    }

    private function render_cement($data)
    {

      $cemented = Read::threads()->cemented();
      $tids = array_column($cemented,'tid');

      foreach ($data as $key => $value)
      {
          if (has($tids,$value['tid']))
          {
              unset($data[$key]);
          }
      }
      $data = array_merge($cemented,$data);

      return $data;
    }
    public function route_forum($slug,$page=1)
    {
        $forum = Read::forums()->by_slug($slug);
        $this->title($forum['name']);

        if ($forum['fid'] == 7 && !iam('mod'))
        {
            return $this->error('You are not a saxophone player!');
        }

        if ($forum['fid'] == 171 && !iam('admin'))
        {
            return $this->error('You do not belong to a small group of secret plotters!');
        }

        if ($slug == 'sidebar')
        {
            Engine::view()->add_module('sidebar');
        }

        $fhead = $this->fheader($forum);
        if ($fhead == 'break') { return; }

        $data = Read::threads()->by_fid_and_page($forum['fid'],$page);

        $data = $this->render_cement($data);

        $this->forum_index($page,$data,'/forum/'.$forum['slug'],'/new/thread/'.$forum['slug'],$forum['slug']);
    }

    public function route_feed($type='',$page=0)
    {
        $this->title('Feed');
        if (!$type)
        {
            $type = 'hottest';
            $page = 1;
        }

        $func = 'feed_'.$type;
        if (!method_exists(Read::threads(),$func)) { $this->error('Invalid feed type'); return; }

        $data = Read::threads()->$func($page);

        $data = $this->render_cement($data);

        $this->view('feed_fheader',Array('type' => $type));

        $this->forum_index($page,$data,'/feed/'.$type);
    }

    public function route_newest_replies()
    {
        $this->title('Newest Replies');
        $arr = Array();

        $this->view('newest_replies',$arr);

    }

    public function route_read($slug)
    {
        redir_to('/thread/'.$slug);
    }


    public function route_document($docid)
    {
        $doc = Read::documents()->by_docid($docid);
        $this->title($doc['title']);

        $forum = Read::forums()->by_fid($doc['fid']);

        $fhead = $this->fheader($forum);

        $this->view('document',$doc);
    }


    public function route_all_mycards() {
        Engine::view()->add_css('mycard');
        return $this->view('all_mycards');
    }

    // Replaces /read/
    public function route_thread($slug)
    {
        $thread = Read::threads()->by_slug($slug);
        if (!$thread['tid'])
        {
            return  $this->error('<span style="color: #fc0;">'.$slug.'</span> is an invalid thread');
        }
        $quirk = $thread['quirk'];

        if ($quirk)
        {
           $func = 'input_post_'.$quirk;
           $quirk_data = Engine::quirks()->$func($thread['tid']);
        }

        $op = Read::posts()->OP($thread['tid']);

        if ($op['tag_nameid'] && !iam('mod'))
        {
            return $this->error('Thread is tagged');
        }


        Engine::view()->add_css('thread');
        Engine::view()->add_js('qr');
        Engine::view()->add_js('thread');
        Engine::view()->set_name('thread');
        $this->title($thread['title']);

        $forum = Read::forums()->by_fid($thread['fid']);

        $fhead = $this->fheader($forum);
        if ($fhead == 'break') { return; }

        $posts = Read::posts()->replies($thread['tid']);

        if (my('uid'))
        {
            $blocks = Read::blocks()->by_uid(my('uid'));
        }

        $mycards = Engine::mycards()->thread($thread['tid']);

        $data = Array(
            'op' => $op,
            'thread' => $thread,
            'replies' => $posts,
            'blocks' => $blocks,
            'quirk_data' => $quirk_data,
            'mycards' => $mycards
        );

        if (installed('post_pagination'))
        {
            Engine::pages()->init($thread['tid'],Read::posts()->count_replies($thread['tid']));
            Engine::view()->set_js('on_page',Engine::pages()->onpage);
        }

        $this->view('thread_op',$data);

        $this->view('thread_replies',$data);

        if (installed('post_pagination'))
        {
            Engine::view()->set_js('last_page',Engine::pages()->last_page);
            Engine::view()->set_js('on_page',Engine::pages()->onpage);
        }

        if ($_REQUEST['hi'])
        {
            Engine::view()->run_js('scroll','to_post',$_REQUEST['hi']);
        }

        Engine::view()->set_js('tid',$thread['tid']);

        if (!$thread['locked'])
        {
            if (!my('uid') && get_var('accounts_required'))
            {
                $this->view('lockdown',Array('message' => 'Accounts are required to post for the forseeable future.
                Contact me through discord for account issues or registration: Riven#7868 '));
            }
            else
            {
                $this->view('quickreply',Array(
                    'mode' => 'new_reply',
                    'form_action' => 'Reply to: '.$thread['title'],
                    'id' => 'tid',
                    'value' => $thread['tid'],
                    'draft_type' => 'post',
                    'draft_id' => $thread['tid']
                ));
                if ($quirk)
                {
                    $this->view('quirks/'.$quirk,$quirk_data);
                }
                $this->view('new/__submit',Array(
                        'submit_name' => 'Post Reply',
                ));
            }
        }
        else
        {
            $this->view('locked_thread');
        }
    }

        private function panel($panel,$data=Array(),$prefix='panels')
        {
            page('no_uptop',true);
            page('no_footer',true);
            Engine::view()->add_css('panels');
            return $this->view($prefix.'/'.$panel,$data);

        }

    public function route_CP($panel)
    {
        return $this->panel('index');
    }

    public function route_my($panel)
    {
        $data = Array();
        $this->title(deslug($panel).' CP');

        $func = 'panel_'.$panel;
        if (method_exists(Engine::panel_data(),$func))
        {
            $data = Engine::panel_data()->$func();
        }
        return $this->panel($panel,$data);
    }

    public function route_panel($panel)
    {
        return $this->route_my($panel);
    }

    public function route_admins($panel)
    {
        if (!iam('white'))
        {
            return $this->error('You do not have access to this.');
        }

        return $this->route_my($panel);
    }

    public function route_new($type,$forum_slug)
    {
        Engine::view()->add_js('qr');
        $this->title('New '.deslug($type));

        /*
        if ($type != 'thread')
        {
            $func = 'new_'.$type;
            return Engine::content()->$func($forum_slug);
        }*/

        $forum = Read::forums()->by_slug($forum_slug);
        if (!$forum['fid']) { return $this->error('Invalid forum!'); }

        $data = Array(
            'quirk' => $type,
            'forum' => $forum,
            'type' => $type
        );

        if (!my('uid') && get_var('accounts_required'))
        {
            $this->view('lockdown',Array( 'message' => 'Accounts are required to post'));
        }
        else
        {
            $this->view('new/__title',$data);
            $this->view('quickreply',Array(
                'id' => 'fid',
                'value' => $forum['fid'],
                'draft_type' => 'thread',
                'draft_id' => $forum['fid']
            ));
            if ($type != 'thread')
            {
                $this->view('new/'.$type,$data);
            }
            $this->view('new/thread',Array(
            ));
            $this->view('new/__submit',Array(
                    'submit_name' => 'Post Thread',
            ));
        }
    }
}
