<?php
Class Engine_View
{
    private $files = Array();

    public $data = Array (
        'navs' => Array(),
        'css' => Array(),
        'js' => Array(),
        'js_vars' => Array(),
        'js_exec' => Array(),
        'modules' => Array()
    );

    private $path = Array(
        'css' => '/css/',
        'js' => '/js/'
    );

    private $name = '';

    public function set_name($name)
    {
        $this->name = $name;
    }

    public function add_module($name,$value=true)
    {
        $this->data['modules'][$name] = $value;
    }

    public function name_is($name)
    {
        if ($this->name == $name) { return true; }
    }

    public function add_navs($arr)
    {
        foreach ($arr AS $name => $obj)
        {
            $obj['enslug'] = $name;
            $obj['name'] = deslug($name);
            $this->data['navs'][$obj['name']] = $obj;
        }
    }

    public function init_scripts()
    {
        $this->add_js('jquery');
        $this->add_js('objects');
        $this->add_js('events');
        $this->add_js('import');
        $this->add_js('jscolor');

        $this->add_css('main');
        $this->add_css('https://fonts.googleapis.com/icon?family=Material+Icons',true);
        $this->add_css('https://fonts.googleapis.com/css?family=Charm&display=swap',true);

        $this->data['forums'] = Read::forums()->on_ql();
    }

    //

    public function add_file($src,$data)
    {
        $data = map_deep($data,'safe');
        $this->files[] = Array('src' => $src, 'data' => $data);
    }

    public function add_css($src,$external=false)
    {
        if (!$external)
        {
            $src = $this->path['css'].$src.'.css';
        }
        $this->data['css'][] = $src;
    }

    public function set_title($title)
    {
        $this->data['title'] = $title.' - GT For All';
    }

    // --

    public function add_js($src,$external=false)
    {
        if (!$external)
        {
            $src = $this->path['js'].$src.'.js';
        }
        $this->data['js'][] = $src;
    }

    public function set_js($key,$value)
    {
        if (is_array($value)) { $value = json_encode($value); }
        else if (is_numeric($value)) { }
        else { $value = "'".$value."'"; }

        $this->data['js_vars'][$key] = $value;
    }

    public function run_js($obj,$func,$vars=Array())
    {
        $this->data['js_exec'][] = Array(
            'obj' => $obj,
            'func' => $func,
            'vars' => $vars
        );
    }

    // --

        private function render_file($src,$data)
        {
            if ($data)
            {
                extract($data);
            }

            require "../views/".$src.".php";
        }

    public function render($data=Array())
    {
        $this->render_file('header',$this->data);

        foreach ($this->files?:Array() AS $file)
        {
            $this->render_file($file['src'],$file['data']);
        }

        $this->render_file('footer',$this->data);
    }
}
