<?php
Class Engine_Plugins
{
    function bar($arr)
    {
        if (!is_array($arr)) { $arr = Array($arr); }
        
        $amt = 0;
        foreach ($arr as $unit)
        {
            if (installed($unit)) { $amt++; }
        }
        if ($amt == count($arr)) { return; }
        
        ?>
        <div class="plugin-bar">
            <div class="plugin-bar-inner">
                <?php foreach ($arr as $plug) { if (installed($plug)) { continue; } ?>
                    <a href="" obj="plugins" func="enable" var1="<?=$plug?>"><?=ic('extension',15)?>Enable <?=deslug($plug)?></a>
                <?php } ?>
            </div>
        </div>
        <?php 
    }
    
    function settings_link($id)
    {
        ?>
        <a class="plugin-settings-link" obj="plugins" func="settings_link" var1="<?=$id?>" href=""><?=ic('settings',5)?>Settings</a>
        <?php 
    }
    
    function settings($slug,$id,$redir=false)
    {
        $var2 = '';
        if ($redir)
        {
            $var2 = $redir;
        }
        
        ?>
        <div class="plugin-bar">
            <div class="plugin-bar-inner">
                <a href="" obj="plugins" func="disable" var1="<?=$slug?>" var2="<?=$var2?>"><?=ic('extension',15)?>Disable <?=deslug($slug)?></a>
                <?=$this->settings_link($id)?>
            </div>
        </div>
        <?php 
    }
}