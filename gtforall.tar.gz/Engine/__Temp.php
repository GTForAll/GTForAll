<?php
Class Engine___Temp
{
    public function run()
    {

    }
}