<?php
Class Engine_Ajax_Routing
{
    public function archive_alert($data)
    {
        Write::alerts()->archive($data['alertid']);
    }
    
    public function save_draft($data)
    {
        Write::drafts()->save(my('uid'),$data['type'],$data['id'],$data['message']);
    }
    
    public function preview($data)
    {
        return parse(trim($data['message']));
    }
    
    public function plugins($data)
    {
        $pluginid = Read::plugins()->id_by_slug($data['name']);
        if ($data['type'] == 'enable')
        {
            Write::plugins()->enable(my('uid'),$pluginid);
        }
        elseif ($data['type'] == 'disable')
        {
            Write::plugins()->disable(my('uid'),$pluginid);
        }
    }
    
    public function settings($data)
    {
        $uid = my('uid');
        foreach ($data as $name => $value)
        {
            if ($name == 'ajax') { continue; }
            Write::users()->set_setting($uid,$name,$value);
        }
    }
    
    // ------------
    
    public function set_read_pid($data)
    {
        $page = $data['page'];
        $tid = $data['tid'];
        
        if (!my('uid')) { die; }
        
        Engine::pages()->init($tid);
        
        $read_pid = Engine::pages()->page_to_pid($page);
        
        ZXC::alt('thread_views')->set('read_pid',$read_pid)->key('uid',my('uid'),'tid',$tid)->go();   
    }
    
    public function block_user($data)
    {
        $post = Read::posts()->by_pid($data['pid']);
        Write::blocks()->block_user(my('uid'),$post['user']);
    }
    
    public function unblock_user($data)
    {
        $post = Read::posts()->by_pid($data['pid']);
        Write::blocks()->unblock_user(my('uid'),$post['user']);
    }
    
    public function block_thread($data)
    {
        Write::blocks()->block_thread(my('uid'),$data['tid']);
    }

    public function unblock_thread($data)
    {
        Write::blocks()->unblock_thread(my('uid'),$data['tid']);
    }
}