<style type="text/css">


    #thread-replies {
        box-shadow: initial !important;
    }

    #thread-replies .posts-left, #thread-replies .posts-right {
        text-align: left !important;
        vertical-align: top;
        color: #c7c7c7 !important;
    }

    .posts-left {
        width: 890px;
        max-width: 890px;
        background-color: initial !important;
        padding: 10px;
        overflow-x: hidden;
    }

    .op-left {
        width: 860px;
      }
        max-width: 860px;
    }

    .posts-message {
            overflow-x: hidden;
    }

    .mature-post {
      color: #faa000;
    }

    .posts-left-inner {
        padding: 20px;
        padding-bottom: 76px !important;
        line-height: 1.5em;
        position: relative;
        min-height: 115px;
    }

    .td.posts-right {
        width: 300px;
        max-width: 300px;
        background-color: initial;
        padding: 10px;
    }

    .td {
        border-top: 0px !important;
        border-left: 0px !important;
        border-right: 0px !important;
        border-bottom: 0px !important;
    }

    .posts-bottom-date {
        margin-left: 10px;
    }

    .posts-bottom-tools {
        position: absolute;
        bottom: 3px;
        right: 0px;
    }

    .posts-bottom-tools a, .posts-bottom-tools label {
        margin-right: 15px;
        color: #d0d0d0 !important;
        text-decoration: underline;
    }

    .posts-bottom-tools a:hover {
        color: #ffa !important;
    }

    .mark-label {
        display: inline-block;
        background-color: #111;
        border: 1px solid #333;
        border-radius: 0px;
        text-decoration: none !important;
    }

    .posts-user {
        margin-bottom: 20px;
        padding: 10px 0px;
        text-align: center;
    }

    .posts-mycard {
        width: 300px;
        height: 150px;
    }

    .pbg {
        background-color: #111;
      }

    .posts-user, .posts-mycard, .posts-left-inner {
        border: 1px solid #202020;
        border-radius: 10px;
        box-shadow: 0px 0px 6px #000 inset;
    }

    .tr {
        margin-bottom: 10px;
    }

    .posts-bottom {
        position: absolute;
        bottom: 0px;
        left: 0px;
        width: 100%;
        /*background-color: #1e3331; TODO: Good color, use somewhere but not here */
        background-color: #1d1d1d;
        box-shadow: 0px 0px 10px #000 inset;
        padding: 10px 0px;
        border-bottom-left-radius: 10px;
        border-bottom-right-radius: 10px;

    }

    .tr-me .pbg {
        background-color: #0a2332;
    }

    .tr-me .posts-bottom {
        background-color: #103144;
    }


    .tr-op .pbg {
        background-color: #141D2F;
    }

    .tr-op .posts-bottom {
         background-color: #213251;
    }

    .tr-decision .pbg {
        background-color: #330a0a;
    }

    .tr-decision .posts-bottom {
            background-color: #4a1212;
    }

    .pag {
        background-color: #222;
        box-shadow: 0px 0px 10px #000 inset;
        color: #d0d0d0;
        padding: 5px;
    }

    #pagination-top {
    }

    #pagination-bottom {
    }

    .tr-full {
        width: 100%;
        background-color: #262626;
        box-shadow: 0px 0px 10px #000 inset;
        padding-left: 20px;
    }

    .blocked-show {
        margin-left: 20px;
    }

    .block-bar {
        background-color: #131313;
        box-shadow: 0px 0px 10px #000 inset;
        padding: 15px;
    }

</style>

<?php if ($data['thread']['replies']) { ?>
<h2 class="there-are" id="there-are-replies">There are <?=count($data['replies'])?> Replies</h2>

<?php if (Engine::auth()->can_mod($data['thread']['tid'])) { ?>
    <?=f('moderate')?>
    <input type="hidden" name="modmode" value="thread" />
    <input type="hidden" name="tid" value="<?=$data['thread']['tid']?>" />
<?php } ?>

<?=Engine::pages()->post_top()?>

<div class="table tm chunk" id="thread-replies">
    <?php $i = 0; ?>
    <?php foreach ($data['replies'] as $post) {
        $i++;
        $tr_class = 'post-'.$post['pid'];

        if (get_setting('show_mature_content')) { $post['mature'] = 0; }

        if ($post['tag_nameid']) { $tr_class = 'tagged'; }

        if ($post['user'] == my('user'))
        {
            $tr_class .= ' tr-me';
        }

        if ($post['user'] == $data['op']['user'])
        {
            $tr_class .= ' tr-op';
        }

        if ($post['user'] == 'Decision')
        {
            $tr_class .= ' tr-decision';
        }

        $tr_class .= Engine::pages()->paginate($i);
        $tr_style = Engine::pages()->hide_pages($i);

        $post['uhash'] = crc32($post['user']);
        //

        $is_blocked = 'display: none;';
        if ($data['blocks'])
        {
            if ($data['blocks'][$post['user']])
            {
                $is_blocked = '';
                $tr_style = 'display: none;';
            }
        }
    ?>
        <div class="tr tr-full tr-blocked blocked-<?=$post['uhash']?>" style="<?=$is_blocked?>">
            <div class="td posts-left">Blocked user.
                <a href="" class="blocked-show" obj="user_block" func="show" var1="#self" var2="<?=$i?>">Show post</a>
            </div>
            <div class="td posts-right"></div>
        </div>

        <div class="tr <?=$tr_class?> user-<?=$post['uhash']?>" style="<?=$tr_style?>" id="tr-<?=$i?>">
            <div class="td posts-left">
                <div class="posts-left-inner pbg">
                    <div class="block-bar blocked-<?=$post['uhash']?>" style="<?=$is_blocked?>">
                        <a href="" class="confirm" obj="user_block" func="unblock" var1="<?=$post['uhash']?>" var2="<?=$post['pid']?>">Unblock <?=$post['user']?></a>
                    </div>
                    <div class="posts-user-popped posts-user pbg" style="display: none;"><?=$post['user']?></div>
                    <div class="posts-edit" style="display: none;">
                        <input type="hidden" class="posts-edit-pid" value="<?=$post['pid']?>" />
                        <?php if ($post['user'] != my('user') && !Engine::auth()->can_mod($post['fid'])) { ?>
                            <input class="posts-edit-password" type="password" placeholder="Enter password for <?=$post['user']?>" />
                        <?php } ?>

                        <textarea><?=$post['message']?></textarea><br />
                        <input type="button" obj="edit" func="save" var1="#self" value=" Save " />
                    </div>
                    <div class="posts-message">
                      <?php if (!$post['mature'])
                      {?>
                        <div class="posts-message"><?=parse($post['message'])?></div>
                        <?php if ($post['interaction']) { ?>
                            <div class="posts-message"><?=unsafe($post['interaction'])?></div>
                            <?php } ?>
                      <?php }
                      else
                      {?>
                          <div class="hide-message" style="display: none;"><?=parse($post['message'])?></div>
                          <?php if ($post['interaction']) { ?>
                              <div class="posts-message"><?=unsafe($post['interaction'])?></div>
                              <?php } ?>
                                <a href="" class="mature-post" obj="mature" func="show_post" var1="#self">Show mature content</a>
                      <?php } ?>
                      </div>

                    <div class="posts-bottom">
                        <div class="posts-bottom-date"><?=dinpago($post['dateline'])?></div>
                        <div class="posts-bottom-tools">
                            <a href="" obj="quicksmart" func="quote_reply" var1="#self">Quote</a>
                            <a href="" obj="edit" func="link" var1="#self">Edit</a>
                            <?php if (my('uid')) { ?>
                            <a href="" class="confirm" obj="user_block" func="block" var1="<?=$post['uhash']?>" var2="<?=$post['pid']?>">Block</a>
                            <?php } ?>
                            <?php if (iam('mod')) { ?>
                                <a href="" obj="toggler" func="remote" var1="#self" var2=".posts-left-inner" var3=".post-mod-info">Mod Info</a>
                                <label class="mark-label">Mark <input name="marked[]" value="<?=$post['pid']?>" class="mark" type="checkbox" /></label>
                            <?php } ?>
                        </div>

                    </div>
                    <?php if (iam('mod')) { ?>
                    <div class="post-mod-info" style="display: none;">
                          <table class="tm">
                              <tr><th>IP</th><td><?=$post['ip']?></td></tr>
                              <?php // TODO: WARNING! THIS BELOW LINE  MAY COST SERVER RESOURCES! ?>
                              <tr><th>Host</th><td><?=gethostbyaddr($post['ip'])?></td></tr>
                              <tr><th>Post id</th><td><?=$post['pid']?></td></tr>
                              <tr><th>Epoch</th><td><?=$post['dateline']?></td></tr>
                          </table>
                    </div>
                    <?php } ?>
                </div>
            </div>
            <div class="td posts-right">
                <div class="posts-user pbg"><?=$post['user']?></div>
                <div class="posts-mycard pbg">
                    <?php if ($data['mycards'][$post['user']]) { ?>
                        <?php echo unsafe($data['mycards'][$post['user']]); ?>
                    <?php } ?>
                </div>
            </div>
        </div>
    <?php } ?>
</div>

<?=Engine::pages()->post_bottom()?>

<?php // TODO: REALLY need to generalize this with the other one, but requires time to think it through. ?>
<?php if (iam('mod')) { ?>

    <div id="mod-tools" style="display: none;">
        <div id="mod-tools-tools">
            <input type="button" obj="mark" func="down" value="v Toggle down v" />
            <label>Tag <input name="tag_mode" value="tag" type="radio" /></label>
            <label>Delete <input name="tag_mode" value="recycle" type="radio" /> </label>
            <label>Untag <input name="tag_mode" value="untag" type="radio" /></label>
            <label>Mature Content <input name="mature_toggle" value="1" type="checkbox" /></label>
            <label>Split <input name="split" value="1" type="checkbox" /></label>
            <label>Move <input name="move" value="1" type="checkbox" class="trigger" func="toggle" var1="mod-move" /></label>
            <label>Kick <input name="kick" value="1" type="checkbox" /></label>
            <label>Ban <input name="ban" value ="1" type = "checkbox" class="trigger" func="toggle" var1="ban-form" /></label>
            <label>Permaban <input name="permaban" value="1" type="checkbox" /></label>
        </div>
        <div id="mod-move" style="display: none;">
            <input name="move_posts" placeholder="Move to thread (URL)" value="" />
        </div>
        <div id="ban-form" style="display: none;">
            <input name="ban_data[reason]" placeholder="Ban Reason" value="" /> />
            <input name="ban_data[end_time]" placeholder="Ban Until (MM/DD/YYYY)" type="date" value="" />
            <label>Local Ban <input name="ban_data[fid]" value="local" type="radio" /></label>
            <label>Global Ban <input name="ban_data[fid]" value="global" type="radio" /></label>
            <label>IP Ban <input name="ban_data[type]" value="ip" type="radio" /></label>
            <label>Name Ban <input name="ban_data[type]" value="user" type="radio" /></label>
        </div>
        <?php if (get_var('mod_lockdown')) { ?>
        <div style="margin-top: 10px;"><input name="password" type="password" placeholder="Moderator Password" /></div>
        <?php } ?>
        <div id="mod-tools-submit">
            <?=uf('Moderate')?>
        </div>
    </div>

<?php } ?>

<?php } ?>
