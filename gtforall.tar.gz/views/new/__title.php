<style type="text/css">
    #new-thread-title-wrapper {
        background-color: #111;
        padding: 10px;
    }

    #new-thread-title-wrapper input {
        padding: 10px;
        font-size: 1.5em;
        color: #d0d0d0;
        width: 100%;
    }
</style>
<h1 class="there-are">New <?=deslug($type)?> in <strong><?=$data['forum']['name']?></strong></h1> 
<?=f('new_thread')?>


<input type="hidden" name="quirk" value="<?=$data['quirk']?>" />
<input type="hidden" name="fid" value="<?=$data['forum']['fid']?>" />

<div id="new-thread-title-wrapper" class="main-chunk"><input name="title" placeholder=" Enter your title here " value="<?=$_POST['title']?>" /></div>
