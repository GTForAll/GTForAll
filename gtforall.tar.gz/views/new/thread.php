<table class="tm">
    <tr><td>Link Color</td><td><input class="jscolor" name="link_color" placeholder="Link Color" style="" value="ffa" /></td></tr>
</table>
