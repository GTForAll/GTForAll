<style type="text/css">
    .survey-question {
    }
    
    .survey-question input, .survey-question select, .survey-question label {
        padding: 10px !important;
    }
    
    .survey-question input[type=text] {
        width: 545px;
    }
    
    .survey-question select {
    }
    
    .survey-question input[type=button] {
    }
    
    .survey-question-custom label {
        display: inline-block;
        width: initial;
    }
    
    #survey-add {
    }
</style>
<h2 class="there-are">Survey questions</h2>
<div id="survey-questions-list">
    <div class="survey-question" id="survey-question-template">
        <input name="survey_questions[]" type="text" placeholder="Question" />
        <span class="survey-question-type">
            <?=fill_select('survey_types[]',deslug_all(Array('poll','free_poll','text')),'poll')?>
        </span>
        <span class="survey-question-choices" style="">
            <input name="survey_choices[]" type="text" placeholder="Choices (separate with commas)" />
        </span>
    </div>
</div>
<div class="list"><a id="survey-add" href="">Add more</a></div>