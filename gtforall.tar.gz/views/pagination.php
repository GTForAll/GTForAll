
<div class="list">
    <?php if ($data['page'] != 1) { ?>
        <a href="<?=$data['nav_dir']?>/<?=($data['page']-1)?>">Previous Page</a>
    <?php } ?>
    <a href="<?=$data['nav_dir']?>/<?=($data['page']+1)?>">Next Page</a>
    <?php if ($data['new_thread_link']) { ?>
        <a href="<?=$data['new_thread_link']?>"><?=ic('add_comment')?> New Thread</a>
        <a href="/new/survey/<?=$data['slug']?>"><?=ic('assignment')?> New Survey</a>
    <?php } ?>
</div>