<style type="text/css">
    #document-message {
        background-color: #111;
        padding: 15px;
        border: 1px solid #333;
        border-radius: 7px;
    }
</style>

<h2 class="there-are"><?=$title?></h2>

<p id="document-message"><?=parse($message)?></p> 