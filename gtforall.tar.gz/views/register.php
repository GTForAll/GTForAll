<?php

$GLOBALS['interval'] = 60*5;

function get_offset()
{
    global $interval;
    return (time() % $interval);
}

function display_issue($issue)
{
    echo '<ul><li>'.$issue.'</li></ul>';
}


$offset = get_offset();

$seed = rand(1,99999999);
$data = get_coin_data($seed,$offset);

?>

<style type="text/css">
    body { font-family: Verdana;  color: #efefef; }

    input:not([type=submit]):not([type=button]),textarea,select { font-size: 1.2em; background-color: #000; color: #fff; border: 1px solid #555; box-shadow: 0px 0px 10px #000; padding: 10px; border-radius: 6px; }

    .reghelp {
        display: inline-block;
        min-height: 120px;
        vertical-align: top;
        line-height: 1.3em;
        font-size: 1em;
    }
</style>

<div class="content">
<h1>Register for a GT For All Account</h1>

<div>
<div class="help reghelp">
If you're new, just fill this form out how you normally would on other websites.
</div>

<!--
<div class="help reghelp">
    If you're from the original GT, you can use an existing username that doesn't have an account attached to it if you put in the password you use here.
</div>-->

<div class="help reghelp">
    Already have an account?<br /><br />
    <div class="list"><a href="/login">Login</a></div>
</div>

</div>

<style type="text/css">
    #human {
        border-spacing: 0px;
        display: inline-block;
    }
    #human td {
        border-right: 1px solid #013;
        border-bottom: 1px solid #013;
        border-right: 0px;
        border-left: 0px;
        border-bottom: 0px;
        border-top: 0px;
        padding: 3px;
        width: 26px;
        height: 38px;
        background-color: #8F8BEE;
        font-size: 1.4em;
        color: #fc0;
        text-shadow: 1px 1px #000, 1px -1px #000, -1px 1px #000, -1px -1px #000;
    }
    #human td:hover {
        background-color: #079;
        cursor: pointer;
    }
</style>

<style type="text/css">
    <?php foreach ($data['css']?:Array() AS $key => $val) { ?>
    .<?=$key?><?=ds()?>{<?=ds()?><?=$val?><?=ds()?>}<?=ds()?>

    <?php } ?>
</style>

<?=f('register')?>
<table class="cp">
    <tr><td>Username</td><td><input name="user" value="<?=$_POST['user']?>" /></td></tr>
    <tr><td>Password</td><td><input name="pass" type="password"  /></td></tr>
    <tr><td>Confirm Password</td><td><input name="pass_conf" type="password" /></td></tr>
    <tr><td>E-mail</td><td><input name="email" value="<?=$_POST['email']?>" /></td></tr>
    <tr><td colspan="2" style="font-size: 1.3em;">
        Click all the gold coins and only the gold coins:
        <center><table id="human">
            <?php for ($y = 0; $y < $data['cols']; $y++) { ?>
            <tr>
                <?php for ($x = 0; $x < $data['rows']; $x++) { ?>
                    <td style="" x="<?=$x?>" y="<?=$y?>">
                    <?php if ($data['locs'][$x][$y]) { ?>
                        <img src="/images/human_coin.png" class="<?=pick($data['real'])?>" />
                    <?php } else { ?>
                        <img src="/images/human_coin.png" class="<?=pick($data['fake'])?>" />
                    <?php } ?>
                    </td>
                <?php } ?>
            </tr>
            <?php } ?>
        </table></center>

        <input name="seed" type="hidden" value="<?=$seed?>" />
        <input name="locs" type="hidden" value="" />
        <input name="offset" type="hidden" value="<?=$offset?>" />

    </td></tr>
</table>
<input type="submit" value=" Register! " />
</form>
<script src="/js/jquery.js"></script>
<script type="text/JavaScript">

    $("#human td").click(function() {
        if ($(this).attr('done') == 1) { return; }
        var x = $(this).attr('x');
        var y = $(this).attr('y');

        var el = $("input[name=locs]");
        var val =  el.val();

        if (val.length)
        {
            val = val.split(';');
        }
        else
        {
            val = [];
        }
        val.push(x+','+y);
        val = val.join(';');
        el.val(val);
        $(this).html('✓');
        $(this).attr('done',1);
    });
</script>
