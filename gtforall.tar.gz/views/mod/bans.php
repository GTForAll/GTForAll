<h1><?=$forum['name']?></h1>
<h2>Bans</h2>

<?php if ($forum['fid'] != -1) { ?>
<div class="list"><a href="/mod/global/bans">Global Bans</a></div>
<?php } ?>

<?=f("mod_ban_updates")?>
  <table class="cp">
    <tr>
      <th>Banned User</th>
      <th>Banned Username/IP</th>
      <th>Ban Reason</th>
      <th>Ban Start</th>
      <th>Ban Expiration</th>
      <th>Moderator</th>
      <th>Unban Now</th>
      <th>Extend Ban Until</th>
    </tr>
    <?php foreach ($data as $ban) { ?>
      <?php $start = $ban['start_time'];?>
      <?php $new_start = date('m/d/y', $start);?>
      <?php $end = $ban['end_time'];?>
      <?php $new_end = date('m/d/y', $end);?>

    <tr>
      <td><?=$ban['ban_user']?></td>
      <td><?=$ban['value']?></td>
      <td> <?=$ban['reason']?></td>
      <td><?=$new_start?></td>
      <td><?=$new_end?></td>
      <td><?=$ban['username']?></td>
      <td><label><input name="unban[<?=$ban['banid']?>]" value ="1" type = "checkbox" func="toggle"/></label></td>
      <td><input name="ban_until[<?=$ban['banid']?>]" placeholder="Ban Until (MM/DD/YYYY)" type="date" value="" /></td>
    </tr>
  <?php } ?>
  </table>
<?=uf()?>
