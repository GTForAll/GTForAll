<style type="text/css">
    #userpass {

    }

    .userpass-left {
        text-align: left !important;
        width: 20%;
    }

    .userpass-right {
        width: 80%;
    }

    .userpass-left input, .userpass-right input {
        width: 100%;
        padding: 10px;
        font-size: 2em;
    }

    #quickreply-submit-wrapper {
        text-align: center;
        background-image: url("/images/there_are_op.png");
        padding: 20px 0px;
    }

    #quickreply-submit-wrapper input {
        display: inline-block;
    }

    #save-draft-status {
        display: inline-block;
        padding: 7px;
        background-color: #2b2b2b;
        margin-top: 5px;
        border: 1px solid #3f3f3f;
        margin-right: 13px;
        font-style: italic;
    }

    .form-action {
        height: initial !important;
        background-size: 100%;
         background-image: url('/images/fheader.png');
         padding: 6px 12px;
         line-height: 1.5em !important;
    }

    #qr-preview {
        background-color: #000;
        color: #d0d0d0;
        border: 1px solid #444;
        border-radius: 6px;
        padding: 10px;
        text-align: left;
        height: 215px;

    }

    #qr-tools {
        text-align: right;
        margin-top: 15px;
    }

    #qr-tools a {
        width: 182px;
    }

    #qr-wrapper {
        position: relative;
    }

    #qr {
        position: relative;
        background-color: #111;
    }

    .qr-pop {
        position: fixed !important;
        right: 0px;
        bottom: 0px;
        z-index: 10;
    }

    .qr-pop #qr-tools a {
        width: initial !important;
    }
</style>

<?php if ($data['mode']) { ?>
    <?=f($data['mode'])?>
<?php } ?>

<input type="hidden" name="<?=$data['id']?>" value="<?=$data['value']?>" />

<?php if ($data['form_action']) { ?>
    <h2 class="there-are form-action"><?=$data['form_action']?></h2>
<?php } ?>

<table class="tm chunk" id="userpass">

    <?php
        if (my('uid') && !$_POST['user'])
        {
            $ups = 'display: none;';
            ?>
            <tr>
                <td colspan="2" style="text-align: left;">
                <input type="hidden" name="use_primary" value="<?=$_POST['use_primary']?:1?>" />
                Posting as <strong><?=my('user')?></strong> <a href="" id="posting-as-change">Change</a></td>
            </tr>
            <?php
        }
    ?>

    <tr class="ups" style="<?=$ups?>">
        <td class="userpass-left">Username</td>
        <td class="userpass-right"><input name="user" value="<?=$_POST['user']?>" placeholder="Username" /></td>
    </tr>

    <tr class="ups" style="<?=$ups?>">
        <td class="userpass-left">Password</td>
        <td class="userpass-right">
            <input name="pass" value="<?=$_POST['pass']?>" type="password" placeholder="Password" />
            <input name="email" style="display: none; visibility: hidden;" placeholder="Email" autocomplete="off" />
        </td>

    </tr>

    <tr>
        <td colspan="2" id="qr-wrapper"><div id="qr">

            <textarea rows="10" cols="50" name="message" placeholder="Enter your message here" id="qr-message"><?=$_POST['message']?:Read::drafts()->get($data['draft_type'],$data['draft_id'])?></textarea>
            <div id="qr-preview" style="display: none;">Preview</div>
            <?php if (my('uid')) { ?>
            <div id="qr-tools" class="list" style="align:left; text-align:left">
                <div id="save-draft-status" style="display: none;"></div>
                <input id="draft-type" name="draft_type" type="hidden" value="<?=$data['draft_type']?>" />
                <input id="draft-id" name="draft_id" type="hidden" value="<?=$data['draft_id']?>" />
                <a href="" obj="quicksmart" func="fullscreen" id="qr-fullscreen" style="display: none;">Fullscreen</a>
                <a href="" obj="quicksmart" func="pop" id="qr-popper">Expand</a>
                <a href="" obj="preview" func="preview" id="preview-button">Preview</a>
                <a href="" obj="drafts" func="save">Save Draft</a>
            </div>
            <?php } ?>
            <div>
                <label style="align:left; text-align:left; margin-top:15px; background-color: #111; box-shadow: 0px 1px 3px 0px #000">
                  <input type="checkbox" name="mature" value="1">
                  Mature Content
                </label>
            </div>

        </div></td>
    </tr>

</table>
