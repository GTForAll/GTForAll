<h1>Posting Filters</h1>

<?php 

$fields = deslug_all(Array('username','message','title'));
$types = deslug_all(Array('is','contains','length','regex'));

?>

<style type="text/css">
    .cond input, .cond select { 
        display: inline-block !important;
        width: auto !important;
    }
</style>

<?=f('admin_create_filter')?>
<h2>Create Filter</h2>

<table class="cp">
    <tr><td>Field</td><td><?=fill_select('field',$fields,'')?> </td></tr>
    <tr><td>Type</td><td><?=fill_select('type',$types,'')?> </td></tr>
    <tr><td>Value</td><td><input name="value" value="<?=$filter['value']?>" /></td></tr>
</table>

<?=uf()?>

<?=f('admin_update_filters')?>
<table class="cp">
    <tr><th>Filter ID</th><th>Creator</th><th>Condition</th><th>Remove</th></tr>
    <?php foreach ($data['filters'] as $filter) { $filterid = $filter['filterid']; ?>
    <tr>
        <td>#<?=$filterid?></td>
        <td><?=$filter['username']?></td>
        <td class="cond">
            <?=fill_select('field['.$filterid.']',$fields,$filter['field'])?> 
            <?=fill_select('type['.$filterid.']',$types,$filter['type'])?> 
            <input name="value[<?=$filterid?>]" value="<?=$filter['value']?>" />
        </td>
        <td>
            <label>
                Remove
                <input type="checkbox" name="remove[]" value="<?=$filterid?>" />
            </label>
        </td>
    </tr>
    <?php } ?>
</table>

<?=uf()?>