<style type="text/css">
    .block-wrapper > table, .block-wrapper > div {
        display: inline-block;
        vertical-align: top;
    }
    
    .help {
        background-color: #111;
        padding: 10px;
        margin-top: 10px;
        margin-left: 50px;
        border: 1px solid #222;
        line-height: 1.5em;
        color: #d0d0d0;
        width: auto !important;
    }
</style>
<h1>User Settings</h1>
<?=f('user_settings')?>

<h2>Change Posting Name</h2>
<div class="block-wrapper">
<table class="cp">
    <tr><td>Posting name</td><td><input name="posting_name" value="<?=my('user')?>"</td></tr>
    <tr><td>Password<br /></td><td><input name="posting_password" type="password" /></td></tr>
</table>

<div class="help">
    Enter a password in either of these circumstances:
    <ul>
        <li>You're changing your posting name to a name that already exists and has a password</li>
        <li>You're creating a new posting name and want to give it a password</li>
    </ul>
</div>

</div>

<h2>Change Login Name</h2>
<table class="cp">
    <tr><td>Login Name</td><td><input name="login_name" value="<?=my('account_user')?>" /></td></tr>
</table>

<h2>Change Password</h2>
<div class="block-wrapper">
<table class="cp">
    <tr><td>New password</td><td><input type="password" name="pass" /></td></tr>
    <tr><td>Confirm New password</td><td><input type="password" name="passconf" /></td></tr>
</table>
<div class="help">Fill these out only if you want to change the password for logging in</div>
</div>

<?=uf()?>