<?php $setts = Engine::auth()->user_settings; ?>
<?php my('settings',Read::users()->settings_by_uid(my('uid'))); ?>
<h2>Settings</h2>
<?php f('save_settings')?>
  <table class="cp">

    <tr><th>Setting</th><th>Value</th></tr>
      <?php foreach ($setts as $set) { ?>

        <tr>
        <td><?=deslug($set)?></td>
        <td><?=checkbox('Enabled', $set, get_setting($set))?></td>
        </tr>

      <?php } ?>

  </table>
<?=uf('Save Settings')?>
