<style type="text/css">
    input:not([type="submit"]) {
        padding: 15px;
        min-width: 400px;
    }
</style>
<h1>Filter #30</h1>

<?=enable_var('filter_30')?>

<h2>Add thread</h2>
<?=f('admin_f30_add_thread')?>
<input name="link" placeholder="Thread URL" />
<?=uf()?>

<?php if ($data['filter_threads']) { ?>
    <h2>Remove threads</h2>
    <?=f('admin_f30_remove_threads')?>
    <table class="cp"><tr><th>Thread</th><th>Thread ID</th><th>Remove</th></tr>
    <?php foreach ($data['filter_threads']?:Array() as $thread) { ?>
        <tr>
            <td><a href="/thread/<?=$thread['slug']?>"><?=$thread['title']?></td>
            <td><?=$thread['tid']?></td>
            <td><label><input type="checkbox" name="tids[]" value="<?=$thread['tid']?>" />Remove</label></td>
        </tr>
    <?php } ?>
    </table>
    <?=uf()?>
<?php } ?>

<h2>Add whitelist entry</h2>
<?=f('admin_f30_add_whitelist')?>
<select name="type"><option value="user">Username</option><option value="ip">IP address</option></select>
<input name="value" placeholder=" Value " />
<?=uf()?>

<?php if ($data['filter_whitelist']) { ?>
<?=f('admin_f30_remove_whitelists')?>
<h2>Remove whitelist entries</h2>
<table class="cp"><tr><th>Type</th><th>Value</th><th>Remove</th></tr>
    <?php foreach ($data['filter_whitelist']['user']?:Array() as $user) { ?>
        <tr>
            <td>Username</td>
            <td><?=$user?></td>
            <td><label><input type="checkbox" name="users[]" value="<?=$user?>" />Remove</label></td>
        </tr>
    <?php } ?>
    <?php foreach ($data['filter_whitelist']['ip']?:Array() as $user) { ?>
        <tr>
            <td>IP Address</td>
            <td><?=$user?></td>
            <td><label><input type="checkbox" name="ips[]" value="<?=$user?>" />Remove</label></td>
        </tr>
    <?php } ?>
</table>
<?=uf()?> 
<?php } ?>
