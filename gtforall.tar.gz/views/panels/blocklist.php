<?php die; ?>
<h1>Blocklists</h1>

<?php if ($data['blocks']) { ?>

<h2>Edit Blocked Users</h2>
<table class="cp">
    <tr><th>User</th><th colspan="2">Options</th><th>Remove</th></tr>
<?php foreach ($data['blocks']?:Array() as $block) { ?>
    <tr><td><?=$block['user']?></td>
        <td><?=fill_select('')?></td>
        <td><?=fill_select('')?></td>
        <td><label>Remove<input type="checkbox" name="remove[]" value="<?=$block['blockid']?>" /></label></td>
    </tr>
<?php } ?>
</table>

<?php } ?>

<?=f('blocklist')?>

<h2>Add Users to be blocked (separate with new lines)</h2>

<textarea name="names"></textarea>

<?=uf()?>