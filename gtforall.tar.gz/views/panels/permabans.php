<h1>Permabans</h1>
<?=f('admin_permabans')?>
<table class="cp">
    <tr><th>Ban issuer</th><th>Date Issued</th><th>IP address</th><th>Remove</th></tr>
    <?php foreach ($data['bans']?:Array() as $ban) { ?>
    <tr>
        <td><?=$ban['username']?></td>
        <td><?=dago($ban['dateline'])?></td>
        <td><?=$ban['ip']?></td>
        <td><label>Remove<input type="checkbox" name="remove[]" value="<?=$ban['banid']?>" /></label></td>
    </tr>
    <?php } ?>
</table>
<?=uf()?>