<style type="text/css">
    .title, .user, .type {
        padding: 10px;
        background-color: #222;
    }
    
    .title-message {
        max-width: 760px;
    }
    
    td {
        vertical-align: top;
    }
</style>

<h1>Filter Queue</h1>

<?php if ($data['queue']) { ?>
<?=f('admin_filter_queue')?>
<table class="cp">
    <tr><th>Type/Filter</th><th>Location</th><th>User/Date</th><th>Title/Message</th><th>Approve</th><th>Reject</th></tr>
    <?php foreach ($data['queue']?:Array() AS $q) { ?>
    <tr>
        <td>
            <div class="type"><?=$q['net_type']?></div>
            <?=$q['desc']?>
        </td>
        <td><a href="<?=$q['loc']['url']?>"><?=$q['loc']['name']?></td>
        <td>
            <div class="user"><?=$q['user']?></div>
            <?=dinpago($q['dateline'])?>
        </td>
        <td class="title-message">
            <?php if ($q['title']) { ?>
            <div class="title"><?=$q['title']?></div>
            <?php } ?>
            <?=parse($q['message'])?>
        </td>
        <td><label><input type="checkbox" name="approve[]" value="<?=$q['logid']?>" />Approve</label></td>
        <td><label><input type="checkbox" name="reject[]" value="<?=$q['logid']?>" />Reject</label></td>
    </tr>
    <?php } ?>
</table>
<?=uf()?>
<?php } ?>