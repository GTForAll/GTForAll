<style type="text/css">

    #op-wrapper {
        margin: 5px;
    }

    #thread-title {
        color: #DDD;
        padding: 10px 15px;
        background-image: url("/images/there_are_op.png");
        margin: 0px;
    }

    #thread-posted-by {
        background-color: #111;
        position: relative;
        padding: 15px;
        font-size: 0.8em;
    }

    #thread-op {
        line-height: 1.5em;
        color: #c7c7c7;
        background-color: #090909;
        font-size: 1.03em;
        padding: 20px;
        text-align: left;
        overflow-x: hidden;
    }

    #thread-tools {
        position: absolute;
        top: 15px;
        right: 15px;
    }

    #thread-tools a {
        font-size: 1.2em;
        text-decoration: underline;
        margin-left: 15px;
    }

    #thread-tools a:hover {
        color: #ff9;
    }

    #thread-edit textarea {
        width: 100% !important;
    }

    .survey-none {
        padding: 20px;
        background-color: #111;
        text-align: center;
        box-shadow: 0px 0px 10px #000 inset;
        font-style: italic;
    }
</style>


<div id="op-wrapper" class="main-chunk">
    <h2 id="thread-title"><?=$data['thread']['title']?></h2>

    <div id="thread-posted-by">
        Posted <?=dinpago($data['thread']['dateline'])?> by <?=$data['thread']['user']?>
        <div id="thread-tools">
            <a href="" obj="quicksmart" func="quote_op">Quote</a>
            <a href="" obj="edit" func="edit_thread">Edit</a>
            <?php if (my('uid')) { ?>
                <?php if ($data['blocks']['thread_'.$data['thread']['tid']]) { ?>
                <a href="" class="confirm" obj="user_block" func="unblock_thread" var1="<?=$data['thread']['tid']?>">Unblock thread</a>
                <?php } else { ?>
                <a href="" class="confirm" obj="user_block" func="block_thread" var1="<?=$data['thread']['tid']?>">Block thread</a>
                <?php } ?>
            <?php } ?>
            <?php if (iam('mod')) { ?>
                <a href="" obj="toggler" func="remote" var1="#self" var2="#op-wrapper" var3=".post-mod-info">Mod Info</a>
            <?php } ?>
        </div>
    </div>

    <div id="thread-edit" class="posts-edit" style="display: none;">
        <input type="hidden" class="posts-edit-pid" value="<?=$data['op']['pid']?>" />
        <input type="hidden" id="posts-edit-tid" value="<?=$data['thread']['tid']?>" />
        <input id="posts-edit-title" value="<?=$data['thread']['title']?>" />
        <?php if ($data['op']['user'] != my('user') && !Engine::auth()->can_mod($data['op']['fid'])) { ?>
            <input class="posts-edit-password" type="password" placeholder="Enter password for <?=$data['op']['user']?>" />
        <?php } ?>

        <textarea><?=$data['op']['message']?></textarea><br />
        <input type="button" obj="edit" func="save_thread" value=" Save " />
    </div>

    <?php if (iam('mod')) { ?>
    <div class="post-mod-info" style="display: none;">
          <table class="tm">
              <tr><th>IP</th><td><?=$data['op']['ip']?></td></tr>
              <?php // TODO: WARNING! THIS BELOW LINE  MAY COST SERVER RESOURCES! ?>
              <tr><th>Host</th><td><?=gethostbyaddr($data['op']['ip'])?></td></tr>
              <tr><th>Post id</th><td><?=$data['op']['pid']?></td></tr>
              <tr><th>Thread id</th><td><?=$data['thread']['tid']?></td></tr>
              <tr><th>Forum id</th><td><?=$data['thread']['fid']?></td></tr>
              <tr><th>Epoch</th><td><?=$data['op']['dateline']?></td></tr>
          </table>
    </div>
    <?php } ?>

    <div id="thread-op" class="posts-message">
        <?=parse($data['op']['message'])?>

        <?php if ($data['thread']['quirk'] == 'survey') { $agg = $data['quirk_data']['aggregate'];  ?>
            <?php foreach ($data['quirk_data']['questions']?:Array() AS $quid => $question) { ?>
                <h2 class="there-are" style="height: initial !important; background-size: 100% 100%;"><?=$question['name']?></h2>
                <?php if ($agg[$quid]) { ?>

                    <table class="tm">
                    <?php foreach ($agg[$quid]?:Array() as $answer => $votes) { ?>
                        <tr>
                            <?php if ($question['type'] == 'poll' || $question['type'] == 'free_poll') { ?>
                                <th><?=$answer?></th>
                                <td><?=count($votes)?></td>
                                <td style="text-align: left;"><?=implode(', ',$votes)?></td>
                            <?php } elseif ($question['type'] == 'text') { ?>
                                <td style="text-align: left; width: 20%;"><?=$votes[0]?></td>
                                <td style="text-align: left; width: 80%;"><?=$answer?></td>
                            <?php } ?>
                        </tr>
                    <?php } ?>
                    </table>

                <?php } else { ?>
                <div class="survey-none">No answers yet</div>
                <?php } ?>
            <?php } ?>
        <?php } ?>
    </div>

</div>
