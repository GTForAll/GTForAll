<style type="text/css">
    #sidebar {
        width: 300px;
        margin-top: 20px;
    }
    
    #page {
        width: 1100px !important;
    }
    
    #sidebar, #page {
        min-height: 1200px;
    }
</style>
<div class="stone" id="sidebar">
    <h2 class="there-are">Sidebar</h2>
</div>