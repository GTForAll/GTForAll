<h1 class="there-are">Newest Replies</h1>
<?=Engine::plugins()->settings('newest_replies','settings','/')?>
<div id="settings" class="plugin-bar" style="display: none;">

</div>