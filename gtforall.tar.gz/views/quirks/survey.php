<style type="text/css">
    .survey-post-table td {
        text-align: left;
    }
    .survey-post-table .left {
        width: 25%;
    }
    .survey-post-table .right {
        width: 75%;
    }
    
    .survey-post-table input, .survey-post-table select {
        min-width: 420px;
        padding: 10px !important;
    }
</style>
<input type="hidden" name="survid" value="<?=$data['survey']['survid']?>" />
<h2 class="there-are">Survey Questions</h2>
<table class="tm survey-post-table">
<?php foreach ($data['questions'] AS $quid => $question) { $type = $question['type']; ?>
<tr>
    <td class="left"><?=$question['name']?></td>
    <td class="right">
        <?php if ($type == 'text') { ?>
            <input type="text" name="survey_answer[<?=$quid?>]" value="<?=$data['responses'][$quid]['text_answer']?>" />
        <?php } elseif ($type == 'poll' || $type == 'free_poll') { ?>
            <?=fill_select('survey_answer['.$quid.']',$question['answers'],$data['responses'][$quid]['answer'],true,'survey-answer')?>
        <?php } ?>
        
        <?php if ($question['type'] == 'free_poll') { 
            $custom_style = 'display: none;';
            $resp = '';
            if ($data['responses'][$quid]['answer'] == 'custom')    
            {
                $resp = $data['responses'][$quid]['text_answer'];
                $custom_style = '';
            }
        ?>
        <input class="survey-answer-custom" name="survey_answer_custom[<?=$quid?>]" style="<?=$custom_style?>" value="<?=$resp?>" placeholder="Custom Answer" />
        <?php } ?>
    </td>
</tr>
<?php } ?>
</table>