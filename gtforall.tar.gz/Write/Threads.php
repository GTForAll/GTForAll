<?php
Class Write_Threads
{
    public function add($fid,$title,$user,$ip='')
    {
        if (!$ip) { $ip = my('ip'); }
        $tid = ZXC::ins('threads')->set('fid',$fid,'title',$title,'user',$user,'lastposter','-','dateline',time(),'ip',$ip)->go();
        $slug = Engine::slugs()->create($tid,$title);
        return Array('tid' => $tid, 'slug' => $slug);
    }

    public function refresh($tid)
    {
        if (!$tid) { return; }
        $thread = Read::threads()->by_tid($tid);
        if (!$thread) { return; }
        $pid = ZXC::sel('>pid/posts')->where('tid',$tid)->the();
        $post = Read::posts()->by_pid($pid);

        $user = '-';
        $lastpid = $thread['firstpost'];
        if ($post)
        {
            $user = $post['user'];
            $lastpid = $post['pid'];
        }
        $replies = ZXC::sel('=pid/posts')->where('tid',$tid)->the()-1;

        ZXC::up('threads')->set('lastposter',$user,'lastpid',$lastpid,'replies',$replies)->where('tid',$tid)->go();
    }

    public function update_title($tid,$title)
    {
        ZXC::up('threads')->set('title',$title)->where('tid',$tid)->go();
    }

    public function set_icon($tid,$icon)
    {
        ZXC::up('threads')->set('icon',$icon)->where('tid',$tid)->go();
    }

    // ----

    public function recycle($tid)
    {
        ZXC::up('threads')->set('fid',186)->where('tid',$tid)->go();
    }

    public function sticky($tid)
    {
        ZXC::up('threads')->set('sticky',1)->where('tid',$tid)->go();
    }

    public function unsticky($tid)
    {
        ZXC::up('threads')->set('sticky',0)->where('tid',$tid)->go();
    }

    public function lock($tid)
    {
        ZXC::up('threads')->set('locked',1)->where('tid',$tid)->go();
    }

    public function unlock($tid)
    {
        ZXC::up('threads')->set('locked',0)->where('tid',$tid)->go();
    }

    public function add_mature($tid)
    {
      ZXC::up('threads')->set('mature',1)->where('tid',$tid)->go();
    }

    public function remove_mature($tid)
    {
      ZXC::up('threads')->set('mature',0)->where('tid',$tid)->go();
    }    
    // --

    public function edit_link_color($tid,$color)
    {
        ZXC::up('threads')->set('link_color',$color)->where('tid',$tid)->go();
    }
}
