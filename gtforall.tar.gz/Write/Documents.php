<?php
Class Write_Documents
{
  public function add($fid,$title,$message)
  {

    ZXC::ins('documents')->set('title',$title,'message',$message,'fid',$fid)->go();

  }

  public function delete($docid)
  {
    ZXC::del('documents')->where('docid',$docid)->go();
  }

  public function edit($docid,$title,$message)
  {

      ZXC::up('documents')->set('title',$title,'message',$message)->where('docid',$docid)->go();
  }
}
