<?php
Class Write_Autotagger
{
}