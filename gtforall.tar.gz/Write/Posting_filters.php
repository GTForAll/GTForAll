<?php
Class Write_Posting_Filters
{
    public function add($uid,$field,$type,$value)
    {
        return ZXC::ins('posting_filters')->set('uid',$uid,'field',$field,'type',$type,'value',$value)->go();
    }

    public function update($filterid,$field,$type,$value)
    {
        ZXC::up('posting_filters')->set('field',$field,'type',$type,'value',$value)->where('filterid',$filterid)->go();
    }

    public function remove($filterid)
    {
        ZXC::del('posting_filters')->where('filterid',$filterid)->go();
    }

    // --------

    public function add_f30_thread($tid)
    {
        return ZXC::ins('f30')->set('tid',$tid)->go();
    }

    public function remove_f30_thread($tid)
    {
        ZXC::del('f30')->where('tid',$tid)->go();
    }

    public function add_f30_whitelist($type,$value)
    {
        ZXC::ins('f30_whitelist')->set('type',$type,'value',$value)->go();
    }

    public function remove_f30_whitelist($type,$value)
    {
        ZXC::del('f30_whitelist')->where('type',$type,'value',$value)->go();
    }

    // ---------


    public function add_f31($field,$type,$value)
    {
        return ZXC::ins('f31')->set('field',$field,'type',$type,'value',$value)->go();
    }

    public function remove_f31($id)
    {
        ZXC::del('f31')->where('id',$id)->go();
    }

    public function add_f33($field,$type,$value)
    {
        return ZXC::ins('f33')->set('field',$field,'type',$type,'value',$value)->go();
    }

    public function remove_f33($id)
    {
        ZXC::del('f33')->where('id',$id)->go();
    }

    public function add_f31_whitelist($field,$type,$value)
    {
        return ZXC::ins('f31_whitelist')->set('field',$field,'type',$type,'value',$value)->go();
    }

    public function remove_f31_whitelist($id)
    {
        ZXC::del('f31_whitelist')->where('id',$id)->go();
    }

    // ----

    public function add_log($filterid,$data)
    {
        return ZXC::ins('filter_log')->vset('tid,fid,user,title,message',$data)->set('filterid',$filterid,'dateline',time())->go();
    }

    public function remove_log($logid)
    {
        ZXC::del('filter_log')->where('logid',$logid)->go();
    }

}
