<?php
Class Write_Posts
{
    public function add_op($tid,$user,$message)
    {
        $pid = $this->add($tid,$user,$message);
        ZXC::up('threads')->set('firstpost',$pid,'lastpid',$pid)->where('tid',$tid)->go();
        return $pid;
    }

    public function make_op($tid,$pid)
    {
        ZXC::up('threads')->set('firstpost',$pid)->where('tid',$tid)->go();
    }

    public function add_reply($tid,$user,$message)
    {
        $pid = $this->add($tid,$user,$message);
        ZXC::up('threads')->set('lastposter',$user,'lastpid',$pid,'replies++')->where('tid',$tid)->go();
        return $pid;
    }

        private function save_edit($pid,$message)
        {
            return ZXC::ins('post_edits')->set('pid',$pid,'dateline',time(),'uid',my('uid'),'ip',my('ip'),'message',$message)->go();
        }

    public function add($tid,$user,$message)
    {
        $fid = Read::threads()->get_fid($tid);
        Write::users()->link_ip(my('ip'),$user);

        $sban = my('sban');

        $pid = ZXC::ins('posts')->set('tid',$tid,'fid',$fid,'user',$user,'dateline',time(),'message',$message,'ip',my('ip'),'sban',$sban)->go();
        $this->save_edit($pid,$message);
        return $pid;
    }

    // ---

        private function get_op($tid)
        {
            return ZXC::sel('firstpost/threads')->where('tid',$tid)->the();
        }

    public function tag_op($tid)
    {
        $pid = $this->get_op($tid);
        $this->tag($pid);
    }

    public function untag_op($tid)
    {
        $pid = $this->get_op($tid);
        $this->untag($pid);
    }

    public function tag_by_tid($tid)
    {
        ZXC::up('posts')->set('tag_reason','#alpha_tag','tag_nameid',3)->where('tid',$tid)->go();
    }

    public function untag_by_tid($tid)
    {
        ZXC::up('posts')->set('tag_reason','','tag_nameid','')->where('tid',$tid)->go();
    }

    public function recycle_thread($tid)
    {
        ZXC::up('posts')->set('fid',186)->where('tid',$tid)->go();
    }

    public function tag($pid)
    {
        ZXC::up('posts')->set('tag_reason','#alpha_tag','tag_nameid',3)->where('pid',$pid)->go();
    }

    public function recycle($pid)
    {
        ZXC::up('posts')->set('fid',186,'tid',-1)->where('pid',$pid)->go();
    }

    public function untag($pid)
    {
        ZXC::up('posts')->set('tag_reason','','tag_nameid','')->where('pid',$pid)->go();
    }

    // ---

    public function move_batch($arr,$tid)
    {
        ZXC::up('posts')->set('tid',$tid)->iter('pid',$arr)->go();
    }


    // ---

    public function straight_edit_message($pid,$message)
    {
        ZXC::up('posts')->set('message',$message)->where('pid',$pid)->go();
    }

    public function edit_message($pid,$message)
    {
        $this->straight_edit_message($pid,$message);
        $this->save_edit($pid,$message);
    }

    public function add_mature($pid)
    {
      ZXC::up('posts')->set('mature',1)->where('pid',$pid)->go();
    }

    public function remove_mature($pid)
    {
      ZXC::up('posts')->set('mature',0)->where('pid',$pid)->go();
    }
}
