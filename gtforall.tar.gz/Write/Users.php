<?php
Class Write_Users
{
    public function add($user,$pass,$email,$nameid=0)
    {
        if (!$nameid)
        {
            $nameid = $this->add_name($user,'',true);
        }

        $hash = Engine::auth()->hashify($GLOBALS['branchid'],$pass);

        $uid = ZXC::ins('users')->set('branchid',$GLOBALS['branchid'],'username',$user,'hash',$hash,'email',$email,
        'primary_nameid',$nameid)->go();

        return $uid;
    }

    public function set_primary_nameid($uid,$nameid)
    {
        ZXC::up('users')->set('primary_nameid',$nameid)->where('uid',$uid)->go();
    }

    public function add_name($user,$pass,$claimed=false)
    {
        return ZXC::ins('names')->set('username',$user,'password',$pass,'claimed',$claimed)->go();
    }

    public function change_username($uid,$username)
    {
        ZXC::up('users')->set('username',$username)->where('uid',$uid)->go();
    }

    public function change_hash($uid,$password)
    {
        $branchid = Read::users()->get_branchid($uid);
        $hash = Engine::auth()->hashify($branchid,$password);

        ZXC::up('users')->set('hash',$hash)->where('uid',$uid)->go();
    }

    public function set_setting($uid,$name,$value)
    {
        ZXC::alt('user_data')->key('uid',$uid,'name',$name)->set('value',$value)->go();
    }

    // --

    public function ban($uid)
    {
        ZXC::up('users')->set('banned',1)->where('uid',$uid)->go();
    }

    public function unban($uid)
    {
        ZXC::up('users')->set('banned',0)->where('uid',$uid)->go();
    }

    // ---

    public function add_login_attempt($uid)
    {
        ZXC::ins('login_attempts')->set('uid',$uid,'ip',my('ip'),'dateline',time())->go();
    }

    public function delete_login_attempts($uid,$ip)
    {
        ZXC::del('login_attempts')->where('uid',$uid,'ip',$ip)->go();
    }

    // ---

    public function link_ip($ip,$user)
    {
        ZXC::ins('ips')->set('ip',$ip,'user',$user)->go();
    }
}
