<?php
Class Write_Plugins
{
    public function enable($uid,$pluginid)
    {
        ZXC::ins('user_plugins')->set('uid',$uid,'pluginid',$pluginid)->go();
    }
    
    public function disable($uid,$pluginid)
    {
        ZXC::del('user_plugins')->where('uid',$uid,'pluginid',$pluginid)->go(); 
    }
}