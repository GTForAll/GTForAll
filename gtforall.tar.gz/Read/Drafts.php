<?php
Class Read_Drafts
{
        private function draft()
        {
            return ZXC::sel('uid,type,id,message/drafts');
        }
        
    public function get($type,$id)
    {
        $row = $this->draft()->where('uid',my('uid'),'type',$type,'id',$id)->row();
        return $row['message'];
    }
}