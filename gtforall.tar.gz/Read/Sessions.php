<?php
Class Read_Sessions
{
        private function sess() {
            return ZXC::sel('1sessid,1uid,1ip,1dateline,2branchid,2username,2is_mod,2is_admin,2invisible,3nameid,3username|primary_username/sessions<uid>users'
            .'<2primary_nameid=3nameid<names');
        }

    public function mine() {
        return $this->sess()->where('sessid',my('sessid'))->row();
    }
}
