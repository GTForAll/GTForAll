<?php
Class Read_Events
{
        private function event() 
        {
            return ZXC::sel('eventid,dateline,func,var1,var2,var3,var4/events');
        }
        
    public function get_ready()
    {
        return $this->event()->where('dateline<=',time())->sort('dateline--')->go();
    }
}