<?php
Class Read_Alerts
{
        private function alert()
        {
            return ZXC::sel('alertid,uid,dateline,status,message,link/alerts');
        }
        
    public function my_unarchived()
    {
        return $this->alert()->where('uid',my('uid'))->where('status!=','archived')->sort('dateline--')->go();
    }
}