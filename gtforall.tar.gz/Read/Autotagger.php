<?php
Class Read_Autotagger
{
        private function filter()
        {
            return ZXC::sel('id,field,type,value/autotagger');
        }
    
    
}