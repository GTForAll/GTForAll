<?php
Class Read_Plugins
{  
        private function user()
        {
            return ZXC::sel('1uid,1pluginid,2slug,2name,2desc/user_plugins<pluginid>plugins');
        }
    
    public function get_installed($uid)
    {
        $arr = $this->user()->where('1uid',$uid)->go();
        $installed = Array();
        foreach ($arr?:Array() as $row)
        {
            $installed[$row['slug']] = true;
        }
        return $installed;
    }
    
        private function plugin() 
        {
            return ZXC::sel('pluginid,slug,name,desc/plugins');    
        }
    
    public function id_by_slug($slug)
    {
        $row = $this->plugin()->where('slug',$slug)->row();
        return $row['pluginid'];
    }
}