<?php
Class Read_Posting_Filters
{
        private function filter()
        {
            return ZXC::sel('1filterid,1uid,1field,1type,1value,2username/posting_filters<uid>users');
        }

    public function get_all()
    {
        return $this->filter()->sort('filterid--')->go();
    }

        private function f30()
        {
            return ZXC::sel('1tid,2title,2slug/f30<tid>threads');
        }

        private function f30_whitelist()
        {
            return ZXC::sel('type,value/f30_whitelist');
        }

    public function get_f30_threads()
    {
        return $this->f30()->go();
    }

    public function get_f30_whitelist()
    {
        return $this->f30_whitelist()->go();
    }

        private function f31()
        {
            return ZXC::sel('id,field,type,value/f31');
        }

        private function f31_whitelist()
        {
            return ZXC::sel('id,field,type,value/f31_whitelist');
        }

    public function get_f31()
    {
        return $this->f31()->go();
    }

    public function get_f31_whitelist()
    {
        return $this->f31_whitelist()->go();
    }

        private function f33()
        {
            return ZXC::sel('id,field,type,value/f33');
        }

    public function get_f33()
    {
        return $this->f33()->go();
    }

    // ---

        private function queue()
        {
            return ZXC::sel('1logid,1dateline,1tid,1fid,1user,1title,1message,1filterid,2field,2type,2value,3title|thread_title,3slug|thread_slug,4name|forum_name,4slug|forum_slug/filter_log<filterid<posting_filters<tid<threads<1fid=4fid<forums');
        }

    public function get_queue()
    {
        return $this->queue()->sort('dateline++')->go();
    }

    public function log_by_logid($logid)
    {
        return $this->queue()->where('logid',$logid)->row();
    }
}
