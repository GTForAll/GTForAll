<?php
Class Write_Drafts
{
    public function save($uid,$type,$id,$message)
    {
        ZXC::alt('drafts')->key('uid',$uid,'type',$type,'id',$id)->set('message',$message)->go();
    }
    
    public function remove($uid,$type,$id)
    {
        ZXC::del('drafts')->where('uid',$uid,'type',$type,'id',$id)->go();
    }
    
}