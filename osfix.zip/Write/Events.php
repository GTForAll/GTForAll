<?php
Class Write_Events
{
    public function remove($eventid)
    {
        ZXC::del('events')->where('eventid',$eventid)->go();
    }
    public function add($func,$dateline,$arr)
    {
        ZXC::ins('events')->set('func',$func,'dateline',$dateline,'var1',$arr[0],'var2',$arr[1],'var3',$arr[2],'var4',$arr[3])->go();
    }
}