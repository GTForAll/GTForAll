<?php
Class Write_Bans
{

  public function add($data)
  {

    $data['uid'] = my('uid');
    $data['start_time'] = time();
    ZXC::ins('bans')->vset($data)->go();
    ZXC::ins('bans_log')->vset($data)->go();
  }

  public function set_end_time($banid, $value)
  {

    ZXC::up('bans')->set('end_time',$value)->where('banid',$banid)->go();

  }

  public function remove($banid)
  {

    ZXC::del('bans')->where('banid',$banid)->go();

  }

}
