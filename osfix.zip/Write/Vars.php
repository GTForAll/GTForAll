<?php
Class Write_Vars
{
    public function set($name,$value)
    {
        ZXC::up('vars')->set('value',$value)->where('name',$name)->go();
    }
}