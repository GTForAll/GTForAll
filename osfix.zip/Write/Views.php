<?php
Class Write_Views
{
}