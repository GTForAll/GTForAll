<?php
Class Write_Forums
{
  public function edit($data)
  {
    $fid = $data['fid'];
    $unallowed = Array('fid','__mode');

    foreach ($data?:Array() as $key => $value)
    {
      if (has($unallowed,$key))
      {
        unset($data[$key]);
      }
    }

    ZXC::up('forums')->vset($data)->where('fid',$fid)->go();
  }
}
