<?php
Class Write_Kicks
{
    public function add($uid,$ip)
    {
        return ZXC::ins('kicks')->set('uid',$uid,'ip',$ip,'dateline',time())->go();
    }
}