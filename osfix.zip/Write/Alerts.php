<?php
Class Write_Alerts
{
    public function add($uid,$message,$link)
    {
        return ZXC::ins('alerts')->set('uid',$uid,'dateline',time(),'message',$message,'link',$link,'status','new')->go();
    }
    
    public function archive($alertid)
    {
        ZXC::up('alerts')->set('status','archived')->where('alertid',$alertid)->go();
    }
    
    public function i_saw()
    {
        ZXC::up('alerts')->set('status','seen')->where('uid',my('uid'),'status!=','archived')->go();
    }
}