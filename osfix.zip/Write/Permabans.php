<?php
Class Write_Permabans
{
    public function add($uid,$ip)
    {
        return ZXC::ins('permabans')->set('uid',$uid,'ip',$ip,'dateline',time())->go();
    }
    
    public function delete($banid)
    {
        ZXC::del('permabans')->where('banid',$banid)->go();
    }
    
}
