<?php
Class Write_Signed
{
    public function sign($fid,$type,$value)
    {
        ZXC::ins('signed')->set('fid',$fid,'type',$type,'value',$value)->go();
    }
}