<?php
Class Write_Blocks
{
    public function block_user($uid,$user,$duration=0)
    {
        if (!$uid || !$user) { return; }
        $time_end = -1;
        if ($duration)
        {
            $time_end = time()+$duration;
        }
        return ZXC::ins('blocks')->set('uid',$uid,'user',$user,'time_end',$time_end)->go();
    }
    
    public function unblock_user($uid,$user)
    {
        ZXC::del('blocks')->where('uid',$uid,'user',$user)->go();
    }
    
    public function block_thread($uid,$tid,$duration=0)
    {
        if (!$uid || !$tid) { return; }
        $time_end = -1;
        if ($duration)
        {
            $time_end = time()+$duration;
        }
        return ZXC::ins('blocks')->set('uid',$uid,'tid',$tid,'time_end',$time_end)->go();
    }
    
    public function unblock_thread($uid,$tid)
    {
        ZXC::del('blocks')->where('uid',$uid,'tid',$tid)->go();
    }
}