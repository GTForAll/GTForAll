<?php
Class Write_Sessions
{
    public function add($uid)
    {
        $sessid = md5($uid.'--'.time());
        setcookie('sessid',$sessid,time()+60*60*24*7,'/','gtforall.com',false,true);
        ZXC::ins('sessions')->set('sessid',$sessid,'uid',$uid,'ip',my('ip'),'dateline',time())->go();
    }

    public function sweep($uid)
    {
        ZXC::del('sessions')->where('uid',$uid)->go();
    }
}
