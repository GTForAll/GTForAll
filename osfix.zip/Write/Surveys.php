<?php 
Class Write_Surveys 
{
    public function add($tid)
    {
        return ZXC::ins('surveys')->set('tid',$tid)->go();
    }
    
    public function add_question($svid,$type,$question)
    {
        return ZXC::ins('survey_questions')->set('survid',$svid,'type',$type,'name',$question)->go();
    }
    
    public function add_answer($quid,$answer)
    {
        $answer = trim($answer);
        if (!$answer) { return 0; }
        return ZXC::ins('survey_answers')->set('quid',$quid,'value',$answer)->go();
    }
    
    public function alter_response($survid,$user,$quid,$answer,$text_answer)
    {
        if (!$answer && !$text_answer) { return; }
        return ZXC::alt('survey_responses')
            ->key('survid',$survid,'user',$user,'quid',$quid)
            ->set('answer',$answer,'text_answer',$text_answer)->go();
    }
}