<?php
Class Engine_Mod_Panel_Data
{
  public function panel_bans ($fid)
  {

    return Read::bans()->by_fid($fid);

  }
  public function panel_documents ($fid)
  {
    $docs = Read::documents()->by_fid($fid);
    Engine::view()->set_js('docs',pair($docs,'docid'));
    Engine::view()->add_js('mod_panels');
    return $docs;

  }

}
