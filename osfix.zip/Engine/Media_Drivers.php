<?php
Class Engine_Media_Drivers
{

    // Default format => html, not sure why you'd need anything else.
    public $drivers = Array(
        'twitter_com' => Array( 'tool' => 'url'),
        'youtube_com' => Array( 'tool' => 'req', 'req' => 0 ),
        'bitchute_com' => Array( 'tool' => 'full_url' ),
        'facebook_com' => Array( 'tool' => 'full_url' ),
        'twitch_tv' => Array( 'tool' => 'req', 'req' => 1),
        'giphy_com' => Array('tool' => 'req', 'req' => 1),
        'dailymotion_com' => Array('tool' => 'req', 'req' => 1),
        'vimeo_com' => Array('tool' => 'req', 'req' => 0),
        'pastebin_com' => Array('tool' => 'req', 'req' => 0),
        'scribd_com' => Array('tool' => 'req', 'req' => 1),
        'soundcloud_com' => Array('tool' => 'full_url'),
        'open_spotify_com' => Array('tool' => 'only_uri', 'req' => 1),
        'polltab_com' => Array('tool' => 'req', 'req' => 1),
        'tv_getyarn_io' => Array('tool' => 'full_url'),
        'odysee_com' => Array('tool' => 'req', 'req' => 1)
    );

    public function twitter_com($url)
    {
        $url = urlencode('https://'.$url);
        $data = Engine::scrape()->url('https://publish.twitter.com/oembed?url='.$url.'&theme=dark');
        $data = json_decode($data);
        return $data->html;
    }

    public function odysee_com($req)
    {
        $req = explode(':',$req);
        $req = $req[0];
        $htm = '<iframe width="560" height="315" src="https://odysee.com/$/embed/'.$req.'" allowfullscreen></iframe>';
        return $htm;
    }

    public function youtube_com($location)
    {
        $vid = explode('=',$location);
        array_shift($vid);
        $vid = implode('=',$vid);
        $vid = explode('&',$vid);
        $vid = $vid[0];
        $vid = explode('#',$vid);
        $time = $vid[1];
        $vid = $vid[0];
        $location = $vid;

        if ($time)
        {
            $time = explode('m',$time);
            $min = str_replace('t=','',$time[0]);
            $sec = str_replace('s','',$time[1]);
            $time = ($min*60)+$sec;
        }

        $full_location = 'https://www.youtube.com/v/'.$location;

        if ($time)
        {
            $full_location .= '&version=3&start='.$time;
        }

        $htm = '<div id="yt'.$q.'" class="show-youtube show-media">';
        $htm .= '<img src="https://i3.ytimg.com/vi/'.$vid.'/default.jpg" onclick="showtube(\''.$full_location.'\',\''.$q.'\');" /></div>';

        return $htm;
    }

    public function bitchute_com($url)
    {
        $url = str_replace('/video/','/embed/',$url);
        $htm = '<div id="bitchute"><!-- <a href="" id="bitchute-fullscreen">Toggle Fullscreen</a>--><iframe src="'.$url.'"></iframe></div>';
        return $htm;
    }

    public function facebook_com($url)
    {
        $htm = '<iframe src="https://www.facebook.com/plugins/post.php?href=';
        // https%3A%2F%2Fwww.facebook.com%2FRedBlackAnarchism%2Fposts%2F3451003031677520
        $htm .= urlencode($url).'&width=500&show_text=true&height=481';
        $htm .= '&appId" width="500" height="481" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowfullscreen="true" ';
        $htm .= 'allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"></iframe>';

        return $htm;
    }

    public function twitch_tv($num)
    {
        $htm = '<iframe src="https://player.twitch.tv/?video='.$num.'&parent=gtforall.com&autoplay=false"';
        $htm .= ' frameborder="0" allowfullscreen="true" scrolling="no" height="378" width="620"></iframe>';

        return $htm;
    }


    public function giphy_com($loc)
    {
        $full = $loc;
        $loc = explode('-',$loc);
        $loc = array_pop($loc);

        $htm = '<iframe src="https://giphy.com/embed/'.$loc.'"';
        $htm .= ' width="480" height="360" frameBorder="0" class="giphy-embed" allowFullScreen></iframe>';
        $htm .= '<p><a href="https://giphy.com/gifs/'.$full.'">via GIPHY</a></p>';

        return $htm;
    }

    /// --------------------------------------------
    /// --------------------------------------------


    public function dailymotion_com($loc)
    {
        $htm = '<div style="position:relative;padding-bottom:56.25%;height:0;overflow:hidden;">';
        $htm .= '<iframe style="width:100%;height:400px;position:absolute;left:0px;top:0px;overflow:hidden" frameborder="0" type="text/html"';
        $htm .= ' src="https://www.dailymotion.com/embed/video/'.$loc.'" height="400" allowfullscreen > </iframe> </div>';
        return $htm;
    }


    public function vimeo_com($loc)
    {
        $htm = '<iframe src="https://player.vimeo.com/video/'.$loc.'" height="400" style="width: 100%;text-align: left;" frameborder="0"';
        $htm .= ' allow="autoplay; fullscreen" allowfullscreen></iframe>';
        return $htm;
    }

    public function pastebin_com($loc)
    {
        $htm = '<iframe src="https://pastebin.com/embed_iframe/'.$loc.'?theme=dark" style="border:none;width:100%; height: 400px;"></iframe>';
        return $htm;
    }

    public function scribd_com($loc)
    {
        $htm = '<iframe class="scribd_iframe_embed" title="" src="';
        $htm .= 'https://www.scribd.com/embeds/'.$loc.'/content?start_page=1&view_mode=scroll"';
        $htm .= ' data-auto-height="true" data-aspect-ratio="0.7068965517241379" scrolling="no" width="100%" height="400" frameborder="0">';
        $htm .= '</iframe><p  style="   margin: 12px auto 6px auto;   font-family: Helvetica,Arial,Sans-serif;';
        $htm .= 'font-style: normal;   font-variant: normal;   font-weight: normal;   font-size: 14px;   line-height: normal;';
        $htm .= 'font-size-adjust: none;   font-stretch: normal;   -x-system-font: none;   display: block;"   >';
        $htm .= '<a href="https://www.scribd.com/document/'.$loc.'"  style="text-decoration: underline;">View on Scribd</a></p>';

        return $htm;
    }

    public function soundcloud_com($url)
    {
        $tags = Engine::scrape()->get_meta($url);
        $tag = $tags['al:android:url'];
        $tag = explode(':',$tag);
        $tag = array_pop($tag);

        $htm =  '<iframe width="100%" height="300" scrolling="no" frameborder="no" allow="autoplay"';
        $htm .= ' src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/'.$tag;
        $htm .= '&color=%23ff5500&auto_play=false&hide_related=false&show_comments=true&show_user=true&show_reposts=false';
        $htm .= '&show_teaser=true&visual=true"></iframe>';

        return $htm;
    }

    public function open_spotify_com($uri)
    {
        $htm = '<iframe src="https://open.spotify.com/embed/'.$uri.'" style="width: 100%;" height="380"';
        $htm .= ' frameborder="0" allowtransparency="true" allow="encrypted-media"></iframe>';

        return $htm;
    }

    public function polltab_com($req)
    {
        $htm = '<iframe src="https://www.polltab.com/bracket-poll/embed/'.$req.'" style="width:100%;height:800px;border:0;"></iframe>
        <a style="display: block;" href="https://www.polltab.com/bracket-poll/'.$req.'">Go to link</a>';
        return $htm;
    }

    public function tv_getyarn_io($url)
    {
        $htm = '<iframe style="width: 100%; border: none; display: block; max-width: 420px; height: 355px;"';
        $htm .= ' src="'.$url.'/embed?autoplay=false"> </iframe> ';
        return $htm;
    }

}
