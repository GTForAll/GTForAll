<?php
Class Engine_Submit
{
    // TODO: Is this private?
    public function error($message) {
        return Array(
            'action' => 'error',
            'var1' => $message
        );
    }

    public function save_settings($data)
    {

      foreach (Engine::auth()->user_settings as $set)
      {

        Write::users()->set_setting(my('uid'),$set,$data[$set]);
      }

      return $this->conf('Settings saved!');
    }

        private function page_error($message) {
            return Array(
                'action' => 'page_error',
                'var1' => $message
            );
        }

        private function page_conf($message) {
            return Array(
                'action' => 'page_conf',
                'var1' => $message
            );
        }

        private $confs = Array();

        private function add_conf($message){
            $this->confs[] = $message;
        }

        private function render_confs() {
            return Array(
                'action' => 'conf',
                'var1' => $this->confs
            );
        }

        private function conf($message) {
            return Array(
                'action' => 'conf',
                'var1' => Array($message)
            );
        }

        private function none() {
            return Array(
                'action' => 'none'
            );
        }

        private function redir($to) {
            return Array(
                'action' => 'redirect',
                'var1' => $to
            );
        }

    public function back() {
        return Array(
            'action' => 'last_page'
        );
    }

    public function get_posting_stats($data)
    {
        return $this->redir('/posting_stats/'.urlencode($data['user']));
    }

    public function login($data) {
        $user = Read::users()->by_username($data['user']);

        $attempts = Read::users()->get_login_attempts($user['uid'],my('ip'));
        $amax = 5;

        if ($attempts >= $amax)
        {
            return $this->error('You\'re only allowed '.$amax.' attempts in a 15-minute window. Please wait for some of those to fall off or try
            again later.');
        }

        if (!$user['uid'] || (Engine::auth()->hashify($user['branchid'],$data['pass']) != $user['hash']))
        {
            Write::users()->add_login_attempt($user['uid']);
            return $this->error('Username or Password doesn\'t match. '.($amax-($attempts+1)).' Attempts remaining.');
        }

        Write::sessions()->add($user['uid']);
        Write::users()->delete_login_attempts($user['uid'],my('ip'));

        return $this->back();
    }

    public function register($data)
    {

        if (get_var('registrations_locked'))
        {
            return $this->error('Registrations are currently locked down.');
        }

        if (!$data['user'])
        {
            return $this->error('Username cannot be blank');
        }

        $user = Read::users()->by_username($data['user']);
        if ($user['uid'])
        {
            return $this->error('Username already exists');
        }

        if ($data['pass'] != $data['pass_conf'])
        {
            return $this->error('Passwords don\'t match.');
        }


        // Coin system handling (straight import)
        $interval = 60*5;

        if ($data['offset'] > $interval) { $_data['offset'] = $inverval; }

        $arr = explode(';',$data['locs']);
        $my_locs = Array();
        $coord = Array();
        foreach ($arr AS $row)
        {
            $coord = explode(',',$row);
            $my_locs[$coord[0]][$coord[1]] = true;
        }

        $s_data = get_coin_data($data['seed'],$data['offset']);

        $bad = false;
        for ($x = 0; $x < $s_data['rows']; $x++)
        {
            for ($y = 0; $y < $s_data['cols']; $y++)
            {
                if ($s_data['locs'][$x][$y] && !$my_locs[$x][$y])
                {
                    $bad = true;
                }
                if ($my_locs[$x][$y] && !$s_data['locs'][$x][$y])
                {
                    $bad = true;
                }
            }
        }

        if ($bad)
        {
            return $this->error('You either didn\'t click all the coins or clicked space that weren\'t coins. Try again.');
        }



        // TODO: Poisoning this script for now, will remove later.
        if (get_var('autotagger'))
        {
            Write::posting_filters()->add_f33('ip','is',my('ip'));
        }

        $nameid = 0;
        $name_data = Read::users()->name_by_username($data['user']);
        if ($name_data['nameid'])
        {
            if ($name_data['password'] != $data['pass'])
            {
                return $this->error('The posting name "'.$name_data['username'].'" already exists, and you entered the wrong password for it.');
            }
            $nameid = $name_data['nameid'];
        }

        $uid = Write::users()->add($data['user'],$data['pass'],$data['email'],$nameid);
        Write::sessions()->add($uid);
        return $this->back();
    }

    public function user_settings($data)
    {
        if ($data['login_name'] != my('account_user'))
        {
            if (!$data['login_name'])
            {
                return $this->error('Login name cannot be blank!');
            }

            $user = Read::users()->by_username($data['login_name']);

            if ($user['uid'])
            {
                return $this->error('An account by the name of  "'.$data['login_name'].'" already exists');
            }

            Write::users()->change_username(my('uid'),$data['login_name']);
            $this->add_conf('Login name changed to <strong>'.$data['login_name'].'</strong>');
        }

        if ($data['posting_name'] != my('user'))
        {
            if (!$data['posting_name'])
            {
                return $this->error('Posting name cannot be blank!');
            }

            if ($data['posting_name'] == 'Xhin' && my('account_user') != 'Xhin')
            {
                return  $this->error('Nice try but no');
            }

            // TODO: Special characters exploit fix (check length against ascii length iirc)

            $row = Read::users()->name_by_username($data['posting_name']);
            if (!$row['nameid'])
            {
                $nameid = Write::users()->add_name($data['posting_name'],$data['posting_password'],my('uid'));
                $row = Read::users()->name_by_nameid($nameid);
            }
            else
            {
                if ($row['password'] != $data['posting_password'])
                {
                    return $this->error('Posting password does not match');
                }
            }

            Write::users()->set_primary_nameid(my('uid'),$row['nameid']);
            $this->add_conf('Posting name changed.');
        }

        if ($data['pass'])
        {
            if ($data['pass'] != $data['passconf'])
            {
                return $this->error('Passwords do not match. Try again.');
            }

            Write::users()->change_hash(my('uid'),$data['pass']);
            $this->add_conf('Password changed successfully.');
        }

        Engine::auth()->get_session();
        return $this->render_confs();
    }

    public function blocklist($data)
    {
        $names = explode("\n",$data['names']);
        foreach ($names as $name)
        {
            $name = trim($name);
            Write::blocks()->add_block(my('uid'),$name);
        }
        return $this->conf('Blocks added');
    }

    // ----------------------

        private $error = '';

        private function render_userpass($data)
        {

            // TODO: Turned the honeypot off 9/30/2021, should re-evaluate in 6 months for future use
            /*
            if ($data['email'])
            {
                Write::permabans()->add(3,my('ip'));
                $this->error = 'Autoban';
                return;
            }
            */

            if ($data['use_primary'])
            {
                if (!my('uid'))
                {
                    $this->error = 'You must be logged in.';
                }
                $user = my('user');
            }
            else
            {
                if (!my('uid') && get_var('accounts_required'))
                {
                    $this->error = 'Accounts are required to post';
                }
                if (!Engine::auth()->check_name($data['user'],$data['pass']))
                {
                    $this->error = 'Identity is invalid';
                }
                $user = $data['user'];
            }
            return $user;
        }

        private function check_last_post()
        {
            $last = ZXC::sel('dateline/posts')->where('ip',my('ip'))->sort('dateline--')->lim(1)->the();
            $elapsed = time()-$last;

            $min = get_var('reply_freeze');
            {
            if ($elapsed < $min)
                $this->error = 'You must wait at least '.$min.' seconds in between posts. Please wait an additional '.($min-$elapsed).' seconds.';
            }
        }

        private function post_common($data)
        {
          if (Engine::bans()->am_banned($data))
          {
            $this->error = Engine::bans()->banned_error;
            return;
          }

            $this->check_post_filter($data);
            $len = strlen($data['message']);
            $lim = 65535;
            $rem = $len-$lim;
            if ($len > $lim)
            {
                $this->error = 'Your message is above '.$lim.' Characters.
                <br />Message size: <span style="color: #42a0ff">'.$len.'</span> <span style="color: #faa;">(+'.$rem.')</span>
                <br />Consider breaking it into pieces.';
                return;
            }
        }

            private function flog($filterid,$data)
            {
                return Write::posting_filters()->add_log($filterid,$data);
            }

        private function check_post_filter($data)
        {
            $filters = Read::posting_filters()->get_all();
            $f30 = pair(Read::posting_filters()->get_f30_threads(),'tid');
            $arr = Read::posting_filters()->get_f30_whitelist();
            $f30_whitelist = Array();
            foreach ($arr as $white)
            {
                $f30_whitelist[$white['type']][$white['value']] = true;
            }

            if ($data['tid'] == 136157 && $data['user'] != 'Weird Occurance' && $data['user'] != 'Riven')
            {
                $this->error = 'Due to filter #32, you cannot respond to this thread.';
                return;
            }

            foreach ($filters?:Array() AS $filter)
            {
                $value = $filter['value'];

                $host = gethostbyaddr(my('ip'));
                /*
                if ($f30[$data['tid']] && has($host,'cust.fastspeed.dk'))
                {
                    $this->flog(28,$data);
                    $this->error = 'Some part of your post was blocked by Filter #28';
                    return;
                }
                if ($f30[$data['tid']] && has($data['user'],'Denida'))
                {
                    $this->flog(29,$data);
                    $this->error = 'Some part of your post was blocked by Filter #29';
                    return;
                }
                */
                if ($f30[$data['tid']] && !my('uid'))
                {
                    $this->flog(30,$data);
                    if (!$f30_whitelist['user'][$data['user']] && !$f30_whitelist['ip'][my('ip')])
                    {
                        $this->error = 'Some part of your post was blocked by Filter #30';
                        return;
                    }
                }

                if ($filter['field'] == 'username')
                {
                    $check = $data['user'];
                }
                elseif ($filter['field'] == 'message')
                {
                    $check = $data['message'];
                }
                elseif ($filter['field'] == 'title')
                {
                    $check = $data['title'];
                }

                if ($filter['type'] == 'is')
                {
                    if ($check != $value) { continue; }
                }
                elseif ($filter['type'] == 'contains')
                {
                    if (!has($check,$value)) { continue; }
                }
                elseif ($filter['type'] == 'length')
                {
                    if (strlen($check) != $value) { continue; }
                }
                elseif ($filter['type'] == 'regex')
                {
                    if (!preg_match('/'.$value.'/',$check)) { continue; }
                }

                $this->flog($filter['filterid'],$data);
                $this->error = 'Some part of your post was blocked by Filter #'.$filter['filterid'];
                return;
            }
        }

        // TODO: Merge with the below
        private function make_new_reply($data)
        {
            return Write::posts()->add_reply($data['tid'],$data['user'],$data['message']);
        }
    public function forum_edit($data)
      {

        Write::forums()->edit($data);
        return $this->conf('Forum edited');

      }
      public function document_add($data)
        {
          $fid = $data['fid'];
          $title = $data['title'];
          $message = $data['message'];

          if ($data['docid'])
          {
            Write::documents()->edit($data['docid'],$title,$message);
          }
          else
          {
            Write::documents()->add($fid,$title,$message);
          }

          return $this->conf('Document added');

        }

        public function document_edit($data)
          {


            foreach ($data['delete'] as $docid)
            {

                Write::documents()->delete($docid);
            }

            return $this->conf('Document deleted');

          }

    private function f33($entity,$id,$data)
    {
          $f33 = Read::posting_filters()->get_f33();
          if (Engine::sherlock()->filter($f33,$data) && get_var('autotagger'))
          {
              $secs = rand(get_var('autotagger_min'),get_var('autotagger_max'));
              Write::events()->add('tag_'.$entity,time()+$secs,Array($id));
          }
    }

    public function new_reply($data)
    {
        $thread = Read::threads()->by_tid($data['tid']);
        $user = $this->render_userpass($data);
        $this->check_last_post();
        $data['user'] = $user;
        $this->post_common($data);

        if ($this->error)
        {
            return $this->page_error($this->error);
        }

        Write::drafts()->remove(my('uid'),$data['draft_type'],$data['draft_id']);

        $pid = Write::posts()->add_reply($data['tid'],$user,$data['message']);
        $this->set_mature('Posts',$pid,$data);

        $this->post_process($pid,$data['message']);

        if ($thread['quirk'] != 'thread' && $thread['quirk'] != '')
        {
            $func = 'submit_post_'.$thread['quirk'];
            Engine::quirks()->$func($pid,$data);
        }

        $this->f33('post',$pid,$data);

        Engine::interaction()->render($pid);

        $_POST = Array();
        return $this->page_conf('Reply posted!');
    }

    public function set_mature($table,$id,$data)
    {
        $mature = $data['mature'] ?: 0;
        $list = Array(
            0 => 'remove',
            1 => 'add'
        );

        $func = $list[$mature].'_mature';

        Write::$table()->$func($id);

    }

    public function post_process($pid,$message)
    {
        $changed = Engine::process()->message($pid,$message);
        if ($changed != $message)
        {
            Write::posts()->straight_edit_message($pid,$changed);
        }
        return $changed;
    }

        // TODO: Merge with the below
        private function make_new_thread($data)
        {
            $arr = Write::threads()->add($data['fid'],$data['title'],$data['user']);
            $tid = $arr['tid'];
            $slug = $arr['slug'];

            $pid = Write::posts()->add_op($tid,$data['user'],$data['message']);

            $this->post_process($pid,$data['message']);

            return Array('tid' => $tid, 'slug' => $slug);
        }

    public function new_thread($data)
    {
        $user = $this->render_userpass($data);
        $this->check_last_post();
        $data['user'] = $user;
        $this->post_common($data);
        if ($this->error)
        {
            return $this->page_error($this->error);
        }

        Write::drafts()->remove(my('uid'),$data['draft_type'],$data['draft_id']);

        $arr = Write::threads()->add($data['fid'],$data['title'],$user);
        $tid = $arr['tid'];
        $slug = $arr['slug'];

        $this->set_mature('Threads',$tid,$data);
        Write::threads()->edit_link_color($tid,$data['link_color']);

        $pid = Write::posts()->add_op($tid,$user,$data['message']);

        $this->post_process($pid,$data['message']);

        if ($data['quirk'] != 'thread')
        {
            $func = 'submit_thread_'.$data['quirk'];
            ZXC::up('threads')->set('quirk',$data['quirk'])->where('tid',$tid)->go();
            Engine::quirks()->$func($tid,$data);
        }

        $this->f33('thread',$tid,$data);

        $_POST = Array();
        //TODO: and redirect to the new slug.
        return $this->redir('/thread/'.$slug);
    }

    public function moderate($data)
    {
        $func = 'mode_'.$data['modmode'];
        return Engine::moderate()->$func($data);
    }

    public function sign_disclaimer($data)
    {
        $type = $data['type'];
        if ($type == 'ip')
        {
            $value = my('ip');
        }
        elseif ($type == 'uid')
        {
            $value = my('uid');
        }

        Write::signed()->sign($data['fid'],$type,$value);
        return $this->none();
    }

    // ---

    public function mod_ban_updates($data)
    {
      foreach ($data['ban_until']?:Array() as $banid => $value)
      {

        if ($data['unban'][$banid])
        {
          Write::bans()->remove($banid);
        }

        if (!$value) { continue; }

        $value=strtotime($value);

        if ($value <= time())
        {
          return $this->error('The new expiration date is in the past.');
        }

        Write::bans()->set_end_time($banid,$value);


      }

      return $this->conf('Success!');

    }

    public function admin_permabans($data)
    {
        if (!iam('white')) { return $this->error('You do not have access to this panel.'); }
        foreach ($data['remove']?:Array() AS $banid)
        {
            Write::permabans()->delete($banid);
        }
        return $this->conf('Success!');
    }

    public function admin_accounts($data)
    {
        if (!iam('white')) { return $this->error('You do not have access to this panel.'); }
        foreach ($data['ban'] as $uid)
        {
            //if ($uid == -73) { continue; }
            if (Read::users()->is_banned($uid))
            {
                Write::users()->unban($uid);
            }
            else
            {
                Write::users()->ban($uid);
            }
        }
        return $this->conf('Success!');
    }

    public function admin_vars($data)
    {
        if (!iam('white')) { return $this->error('You do not have access to this panel.'); }
        foreach ($data as $name => $value)
        {
            //if ($name == 'reply_freeze' && $value < 30) { $value = 30; }
            Write::vars()->set($name,$value);
        }
        return $this->conf('Success!');
    }

    public function admin_create_filter($data)
    {
        if (!iam('white')) { return $this->error('You do not have access to this panel.'); }
        Write::posting_filters()->add(my('uid'),$data['field'],$data['type'],$data['value']);
        return $this->conf('Success!');
    }


    public function admin_update_filters($data)
    {
        if (!iam('white')) { return $this->error('You do not have access to this panel.'); }
        foreach ($data['field']?:Array() AS $id => $field)
        {
            Write::posting_filters()->update($id,$data['field'][$id],$data['type'][$id],$data['value'][$id]);
        }

        foreach ($data['remove']?:Array() AS $id)
        {
            Write::posting_filters()->remove($id);
        }
        return $this->conf('Success!');
    }

    // --

    public function admin_f30_add_thread($data)
    {
        if (!iam('white')) { return $this->error('You do not have access to this panel.'); }
        // link
        $slug = str_replace('https://gtforall.com/thread/','',$data['link']);
        $slug = str_replace('http://gtforall.com/thread/','',$slug);
        $slug = str_replace('https://www.gtforall.com/thread/','',$slug);
        $slug = str_replace('http://www.gtforall.com/thread/','',$slug);

        $thread = Read::threads()->by_slug($slug);

        Write::posting_filters()->add_f30_thread($thread['tid']);
        return $this->conf('Success!');
    }

    public function admin_f30_remove_threads($data)
    {
        if (!iam('white')) { return $this->error('You do not have access to this panel.'); }
        foreach ($data['tids']?:Array() AS $tid)
        {
            Write::posting_filters()->remove_f30_thread($tid);
        }
        return $this->conf('Success!');
    }

    public function admin_f30_add_whitelist($data)
    {
        if (!iam('white')) { return $this->error('You do not have access to this panel.'); }
        Write::posting_filters()->add_f30_whitelist($data['type'],$data['value']);
        return $this->conf('Success!');
    }

    public function admin_f30_remove_whitelists($data)
    {
        if (!iam('white')) { return $this->error('You do not have access to this panel.'); }
        foreach ($data['users']?:Array() AS $user)
        {
            Write::posting_filters()->remove_f30_whitelist('user',$user);
        }
        foreach ($data['ips']?:Array() AS $ip)
        {
            Write::posting_filters()->remove_f30_whitelist('ip',$ip);
        }
        return $this->conf('Success!');
    }

    // --

    // TODO: TODO: Really really need to generalize these behemothic hegemons (hegemoths?)

    public function admin_f31_add($data)
    {
        if (!iam('white')) { return $this->error('You do not have access to this panel.'); }
        Write::posting_filters()->add_f31($data['field'],$data['type'],$data['value']);
        return $this->conf('Success!');
    }

    public function admin_f31_edit($data)
    {
        if (!iam('white')) { return $this->error('You do not have access to this panel.'); }
        foreach ($data['remove']?:Array() AS $id)
        {
            Write::posting_filters()->remove_f31($id);
        }
        return $this->conf('Success!');
    }

    public function admin_f33_add($data)
    {
        if (!iam('white')) { return $this->error('You do not have access to this panel.'); }
        Write::posting_filters()->add_f33($data['field'],$data['type'],$data['value']);
        return $this->conf('Success!');
    }

    public function admin_f33_edit($data)
    {
        if (!iam('white')) { return $this->error('You do not have access to this panel.'); }
        foreach ($data['remove']?:Array() AS $id)
        {
            Write::posting_filters()->remove_f33($id);
        }
        return $this->conf('Success!');
    }

    public function admin_f31_whitelist_add($data)
    {
        if (!iam('white')) { return $this->error('You do not have access to this panel.'); }
        Write::posting_filters()->add_f31_whitelist($data['field'],$data['type'],$data['value']);
        return $this->conf('Success!');
    }

    public function admin_f31_whitelist_edit($data)
    {
        if (!iam('white')) { return $this->error('You do not have access to this panel.'); }
        foreach ($data['remove']?:Array() AS $id)
        {
            Write::posting_filters()->remove_f31_whitelist($id);
        }
        return $this->conf('Success!');
    }

    // --

    public function admin_filter_queue($data)
    {
        if (!iam('white')) { return $this->error('You do not have access to this panel.'); }
        foreach ($data['approve']?:Array() AS $logid)
        {
            $log = Read::posting_filters()->log_by_logid($logid);
            if ($log['fid']) // New thread
            {
                $this->make_new_thread($log);
            }
            elseif ($log['tid']) // New reply
            {
                $this->make_new_reply($log);
            }
            Write::posting_filters()->remove_log($logid);
        }
        foreach ($data['reject']?:Array() AS $logid)
        {
            Write::posting_filters()->remove_log($logid);
        }
        return $this->conf('Success!');
    }

    // ----

    public function search($data)
    {
        $_SESSION['search'] = $data;
        return $this->none();
    }

    public function new_search()
    {
        unset($_SESSION['search']);
        return $this->redir('/search');
    }
}
