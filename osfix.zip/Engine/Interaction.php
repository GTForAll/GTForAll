<?php
Class Engine_Interaction
{
    private $messages = Array();
    
    public function add_message($message)
    {
        $this->messages[] = $message;
    }
    
    public function render($pid) 
    {
        if (!count($this->messages)) { return; }
        
        $html = '<ul class="interaction">';
        foreach ($this->messages as $message)
        {
            $html .= '<li>'.$message.'</li>';
        }
        $html .= '</ul>';
        
        ZXC::up('posts')->set('interaction',$html)->where('pid',$pid)->go();
    }
}