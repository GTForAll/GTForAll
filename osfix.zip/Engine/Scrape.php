<?php
Class Engine_Scrape
{
    public function url($url)
    {
        $ch=curl_init();
        
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
        
        $data = curl_exec($ch);
 
        curl_close($ch);
        
        return $data;
    }
    
    public function get_meta($url)
    {
        $data = $this->url($url);
        
        $doc = new DomDocument();
        libxml_use_internal_errors(true);
        $doc->loadHTML($data);
        $xpath = new DOMXPath($doc);
        $query = '//*/meta';
        $metas = $xpath->query($query);
        $arr = Array();
        foreach ($metas as $meta) {
            $property = $meta->getAttribute('property');
            $content = $meta->getAttribute('content');
            $arr[$property] = $content;
        }
        return $arr;
    }
}