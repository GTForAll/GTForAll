<?php
Class Engine_Auth
{
    public $user_settings = Array('show_mature_content');

    public function get_session() {

        $sess = Read::sessions()->mine();

        if ($sess['sessid'])
        {
            my('uid',$sess['uid'],true);
            my('account_user',$sess['username']);
            my('user',$sess['primary_username']?:$sess['username']);
            my('is_invisible',$sess['invisible']);
        }
        if ($sess['is_admin'])
        {
            my('is_admin',true);
            my('is_mod',true);
        }
        if ($sess['is_mod'])
        {
            my('is_mod',true);
            $fids = ZXC::sel('fid/forum_mods')->where('uid',my('uid'))->col();
            my('fids',$fids);
        }
    }

    public function can_mod($fid)
    {
        if (iam('admin')) { return true; }

        if (iam('mod'))
        {
            return true;
            if (has(my('fids'),$fid)) { return true; }
        }
        return false;
    }

    // TODO: When this changes, make sure you update the whitelisting tool as well.
    public function hashify($branchid,$pass) {

        // Should probably eventually have some special flag for these so I can use "branchid" instead -- will review if there's another
        // merge.
        if (substr($pass,0,1) == '#')
        {
            $pass = substr($pass,1);
            return md5($pass);
        }
        else
        {
            return md5($pass.'%@)jS7$#){}<@!>^@)D$)6');
        }
    }

    public function logout() {
        Write::sessions()->sweep(my('uid'));
        session_regenerate_id();
    }

    // ----

    public function check_name($username,$pass)
    {
        if (!$username) { return false; }
        $user = Read::users()->name_by_username($username);

        if (!$user['nameid'])
        {
            Write::users()->add_name($username,$pass);
            return true;
        }

        if ($user['password'] != $pass)
        {
            return false;
        }
        return true;
    }
}
