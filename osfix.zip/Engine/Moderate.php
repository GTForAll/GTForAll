<?php
Class Engine_Moderate
{
      private function moderate_mature($type,$id,$id_string)
      {

            if ($type == 'threads')
            {

              $mature_type = 'thread_mature';

            }

            elseif ($type == 'posts')

            {
                $mature_type = 'mature';

            }

            $func = 'by_'.$id_string;
            $value = Read::$type()->$func($id);
            $value = $value[$mature_type];
            $value = 1-$value;
            $mature_data=Array('mature' => $value);
            Engine::submit()->set_mature($type,$id,$mature_data);
        }


        private function check_password($data)
        {
            if (!get_var('mod_lockdown')) { return true; }

            $hash = Engine::auth()->hashify(1,$data['password']);
            $user = Read::users()->by_uid(my('uid'));
            if ($user['hash'] != $hash)
            {
                return false;
            }
            return true;
        }

    public function mode_forum($data)
    {
        if (!$this->check_password($data))
        {
            return Array('action' => 'page_error', 'var1' => 'With Moderator Lockdown mode on, you must enter your password in order to moderate.');
        }

        foreach ($data['marked'] as $tid)
        {
            $thread = Read::threads()->by_tid($tid);

            if ($data['tag_mode'] == 'tag' || $data['tag_mode'] == 'recycle')
            {
                // Write::posts()->tag_op($tid);
                Write::posts()->tag_by_tid($tid);

                if ($data['tag_mode'] == 'recycle')
                {
                    Write::threads()->recycle($tid);
                    Write::posts()->recycle_thread($tid);
                }
            }
            elseif ($data['tag_mode'] == 'untag')
            {
                //Write::posts()->untag_op($tid);
                Write::posts()->untag_by_tid($tid);
            }

            if ($data['mature_toggle'])
            {

              $this->moderate_mature('threads',$tid,'tid');

            }

            if ($data['link_color'] && ($data['link_color'] != 'FFFFAA' || $thread['link_color']) )
            {
                Write::threads()->edit_link_color($tid,$data['link_color']);
            }

            if ($data['sticky'])
            {
                if ($thread['sticky'])
                {
                    Write::threads()->unsticky($tid);
                }
                else
                {
                    Write::threads()->sticky($tid);
                }
            }

            if ($data['lock'])
            {
                if ($thread['locked'])
                {
                    Write::threads()->unlock($tid);
                }
                else
                {
                    Write::threads()->lock($tid);
                }
            }

            if ($data['kick_OP'])
            {
                Write::kicks()->add(my('uid'),$thread['ip']);
            }

            if ($data['ban_op'])
            {

              Engine::bans()->thread($tid,$data['ban_data']);

            }

            if ($data['permaban_OP'])
            {
                Write::permabans()->add(my('uid'),$thread['ip']);
            }
        }

        return Array(
            'action' => 'page_conf',
            'var1' => count($data['marked']).' threads moderated.'
        );
    }

    public function mode_thread($data)
    {
        if (!$this->check_password($data))
        {
            return Array('action' => 'error', 'var1' => 'With Moderator Lockdown mode on, you must enter your password in order to moderate.');
        }

        $first = false;

        foreach ($data['marked'] as $pid)
        {
            $post = Read::posts()->by_pid($pid);
            if (!$first) { $first = $post; }

            if ($data['tag_mode'] == 'tag' || $data['tag_mode'] == 'recycle')
            {
                Write::posts()->tag($pid);

                if ($data['tag_mode'] == 'recycle')
                {
                    Write::posts()->recycle($pid);
                }
            }
            elseif ($data['tag_mode'] == 'untag')
            {
                Write::posts()->untag($pid);
            }

            if ($data['mature_toggle'])
            {

                $this->moderate_mature('posts',$pid,'pid');

            }

            if ($data['kick'])
            {
                Write::kicks()->add(my('uid'),$post['ip']);
            }

            if ($data['ban'])
            {

              Engine::bans()->post($pid,$data['ban_data']);

            }

            if ($data['permaban'])
            {
                Write::permabans()->add(my('uid'),$post['ip']);
            }

        }

        if ($data['split'] && count($data['marked']))
        {
            $fid = Read::threads()->get_fid($first['tid']);
            $title = 'Split: '.substr(strip_tags(parse($first['message'])),0,10);
            $tid = Write::threads()->add($fid,$title,$first['user'],$first['ip']);
            $tid = $tid['tid'];
            Write::posts()->make_op($tid,$first['pid']);
            Write::posts()->move_batch($data['marked'],$tid);
            Write::threads()->refresh($tid);
        }

        if ($data['move_posts'])
        {
            $slug = explode('/',$data['move_posts']);
            $slug = array_pop($slug);
            $tid = Read::threads()->by_slug($slug);
            $tid = $tid['tid'];
            Write::posts()->move_batch($data['marked'],$tid);
            Write::threads()->refresh($tid);
        }

        Write::threads()->refresh($data['tid']);

        return Array(
            'action' => 'page_conf',
            'var1' => count($data['marked']).' posts moderated.'
        );
    }
}
