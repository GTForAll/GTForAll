<?php
Class Engine_Stats
{
    public function forums()
    {
        return ZXC::sel('=fid/forums')->the();
    }
    
    public function threads()
    {
        return ZXC::sel('=tid/threads')->the();
    }
    
        private function post()
        {
            return ZXC::sel('=pid/posts');
        }
    
    public function posts()
    {
        return $this->post()->the();
    }
    
    public function accounts()
    {
        return ZXC::sel('=uid/users')->the();
    }
    
    public function users()
    {
        return ZXC::sel('=nameid/names')->the();
    }
    
    // ----
    
        private function pdays($amt,$rel)
        {
            $num = $this->post()->where('dateline>=',time()-(86400*$amt))->the();
            if (!$rel) { return $num; }
            
            $last = $this->post()->where('dateline>=',time()-(86400*$amt*2),'dateline<=',time()-(86400*$amt))->the();
            $diff = $num-$last;
            if ($diff < 0)
            {
                return '<span class="font-red">'.$diff.'</span>';
            }
            elseif ($diff > 0)
            {
                return '<span class="font-emerald">+'.$diff.'</span>';
            }
            return $diff;
        }
    
    public function posts_today($rel=false)
    {
        return $this->pdays(1,$rel);    
    }
    
    public function posts_this_week($rel=false)
    {
        return $this->pdays(7,$rel);
    }
    
    public function posts_this_month($rel=false)
    {
        return $this->pdays(30,$rel);
    }
    
    public function posts_this_year($rel=false)
    {
        return $this->pdays(365,$rel);
    }
}
