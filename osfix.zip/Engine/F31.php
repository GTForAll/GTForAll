<?php
class Engine_F31
{
    public function init()
    {
        $filter = Read::posting_filters()->get_f31();
        if ($this->evaluate($filter) && get_var('filter_31'))
        {
            my('sban',1);
        }
        else
        {
            my('sban',0);
        }

        if ($this->evaluate(array_merge($filter,Read::posting_filters()->get_f31_whitelist())))
        {
            my('sban_white',1);
        }
        else
        {
            my('sban_white',0);
        }
    }

    // TODO: Strip all instances of this and replace with sherlock
    private function evaluate($filters)
    {
        return Engine::sherlock()->filter($filters);
    }
}
