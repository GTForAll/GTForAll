<?php
Class Engine_Ajax_Html_Routing
{
    public function alerts()
    {
        $alerts = Read::alerts()->my_unarchived();
        if (!$alerts)
        {
            echo '<em>No Alerts</em>';
            return;
        }

        Write::alerts()->i_saw();

        echo '<table class="tm"><tr><th>When</th><th>What</th><th>Archive</th></tr>';
        foreach ($alerts as $alert)
        {
            echo '<tr id="alert-'.$alert['alertid'].'">';
            echo '<td>'.dinpago($alert['dateline']).'</td>';
            echo '<td><a href="'.$alert['link'].'">'.$alert['message'].'</a></td>';
            echo '<td>'.button(Array(
                'name' => 'Archive',
                'obj' => 'alerts',
                'func' => 'archive',
                'var1' => $alert['alertid']
            )).'</td>';
            echo '</tr>';
        }
        echo '</table>';
    }

    public function people($discord=true)
    {
        $ips = Read::users()->recent_ips();
        $accounts = Array();
        $linked = Array();
        $free = 0;
        $spiders = 0;

        foreach ($ips as $row)
        {

            if ($row['uid'])
            {
                $row['name'] = $row['primary_user']?:$row['account_name'];
                $accounts[$row['name']] = $row;
            }
            elseif ($row['ip_user'])
            {
                $row['name'] = $row['ip_user'];
                $linked[$row['name']] = $row;
            }
            elseif ($row['is_spider'])
            {
                 $spiders++;
                 continue;
            }
            else
            {
                $free++;
            }
        }

        ?>
        <style type="text/css">
            #people-tables > table, #people-tables > div {
                display: inline-block;
                width: auto !important;
                vertical-align: top;
            }

            .people-you {
                font-style: italic;
                color: #fc0 !important;
            }
        </style>
        <div id="people-tables">
        <table class="tm">
        <?php if ($accounts) { ?>
        <tr><th colspan="2">Accounts</th></tr>

        <?php foreach ($accounts as $data) {
            $td_class = '';
            if ($data['uid'] == my('uid'))
            {
                $data['name'] = 'You';
                $td_class = 'people-you';
            }
        ?>
            <tr>
            <td class="<?=$td_class?>"><?=safe($data['name'])?></td>
            <td><?=dinpago($data['dateline'])?></td>
            </tr>
        <?php } ?>
        <?php } ?>
        </table>

        <table class="tm">
        <?php if ($linked) { ?>
        <tr><th colspan="2">Other Users</th></tr>

        <?php foreach ($linked as $data) {
            $td_class = '';
            if ($data['uid'] == my('uid'))
            {
                $data['name'] = 'You';
                $td_class = 'people-you';
            }
        ?>
            <tr>
            <td class="<?=$td_class?>"><?=safe($data['name'])?></td>
            <td><?=dinpago($data['dateline'])?></td>
            </tr>
        <?php } ?>
        <?php } ?>

        <tr><th colspan="2"><?=$spiders?> Spiders, <?=$free?> Unknowns</th></tr>
        </table>


        </div>

        <?php
    }

    public function mod($data)
    { ?>
        <div class="list">
          <?php if (iam('mod') && $data['my_fid']) {
            $forum = Read::forums()->by_fid($data['my_fid']);?>
            <a href="/mod/<?=$forum['slug']?>/bans">Bans</a>
            <a href="/mod/<?=$forum['slug']?>/forum_settings">Edit Forum</a>
            <a href="/mod/<?=$forum['slug']?>/documents">Edit Documents</a>
          <?php } ?>
            <a href="/forum/sax0phone">Mod Forum</a>
            <?php if (iam('admin')) { ?>
                <a href="/forum/thecabal">Admin Forum</a>
            <?php } ?>
            <?php if (my('uid') == -73) { //TODO: Remove once custom quicklinks are in place ?>
                <a href="/forum/gtforall">GT For All</a>
            <?php } ?>
        </div>
        <?php
    }

    public function edit_post($data)
    {
       $post = Read::posts()->by_pid($data['pid']);

       if (!$post['pid']) { echo '<em class="error">Invalid post!</em>'; die; }

       if (!Engine::auth()->can_mod($post['fid']))
       {
           $user = Read::users()->name_by_username($post['user']);
           if ($user['password'] != $data['pass'])
           {
                if ($user['username'] != my('user'))
                {
                   ?>
                   <em class="error">The password you entered did not match!</em><br /><br />
                   <input type="hidden" value="<?=$data['message']?>" class="edit-passbad" />
                   <input type="button" obj="edit" func="try_again" var1="#self" value=" Try Again " />
                   <?php
                   die;
                }
           }
       }

       if ($data['edit_title'])
       {
            $data['tid'] = intval($data['tid']);
            Write::threads()->update_title($data['tid'],$data['title']);
       }

       Write::posts()->edit_message($data['pid'],$data['message']);

       $data['message'] = Engine::submit()->post_process($data['pid'],$data['message']);

       echo parse($data['message']);
    }

}
