<?php
Class Engine_Events
{
    public function render()
    {
        $events = Read::events()->get_ready();
        foreach ($events?:Array() AS $event)
        {
            $func = 'event_'.$event['func'];
            $this->$func($event['var1'],$event['var2'],$event['var3'],$event['var4']);
            Write::events()->remove($event['eventid']);
        }
    }

    // ---- For now, until this list gets enormous

    public function event_tag_post($pid)
    {
        $post = Read::posts()->by_pid($pid);
        Write::posts()->tag($pid);
        //Write::posts()->recycle($pid);
        Write::threads()->refresh($post['tid']);
    }

    public function event_tag_thread($tid)
    {
        Write::posts()->tag_op($tid);
        //Write::threads()->recycle($tid);
        //Write::posts()->recycle_thread($tid);
    }
}
