<?php
Class Engine_Media
{
        private function invalid($num,$name,$ourl)
        {
            $name = str_replace('_','.',$name);
            return 'Invalid media format #'.$num.': <em style="color: #ba856b;">'.$name.'</em> URL used: <em style="color: #a7bf96;">'.$ourl.'</em>';
        }
    
    public function translate($url)
    {
        $ourl = $url;
        
        $url = str_replace('https://','',$url);
        $url = str_replace('http://','',$url);
        $url = str_replace('www.','',$url);
        
        $REQ = explode('/',$url);
        $name = array_shift($REQ);
        $name = str_replace('.','_',$name);
        
        $driver = Engine::media_drivers()->drivers[$name];
        
        if (!$driver['format'])
        {
            $driver['format'] = 'html';    
        }
                
        $obj = Array(
            'driver' => $driver,
            'url' => $url,
            'full_url' => $ourl,
            'req' => $REQ,
            'name' => $name,
            'data' => ''
        );
        
        $func = 'tool_'.$driver['tool'];
        
        if (!method_exists('Engine_Media',$func)) { return $this->invalid(1,$name,$ourl); }
        
        $obj['data'] = $this->$func($obj);
        
        $func = 'format_'.$driver['format'];
        
        if (!method_exists('Engine_Media',$func)) { return $this->invalid(2,$name,$ourl); }
        
        $html = $this->$func($obj);
        
        return $html;
    }
    
    private function tool_url($obj)
    {
        $func = $obj['name'];
        return Engine::media_drivers()->$func($obj['url']);
    }
    
    private function tool_only_uri($obj)
    {
        $func = $obj['name'];
        $req = implode('/',$obj['req']);
        return Engine::media_drivers()->$func($req);
    }
    
    private function tool_req($obj)
    {
        $func = $obj['name'];
        return Engine::media_drivers()->$func($obj['req'][$obj['driver']['req']]);
    }
    
    private function tool_full_url($obj)
    {
        $func = $obj['name'];
        return Engine::media_drivers()->$func($obj['full_url']);
    }
    
    // ---------
    
    private function format_html($obj)
    {
        return $obj['data'];    
    }
}