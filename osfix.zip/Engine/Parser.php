<?php
Class Engine_Parser
{
    
    private function tag($tag,$replace,$message)
    {
        $message = preg_replace("#\[".$tag."\]([^\[]*)\[/".$tag."\]#im",$replace,$message);
        return $message;
    }
    
    public function linecode($arg1,$arg2,$message)
    {
    
        if (stristr($message,$arg1) == TRUE)
        {
            $message = str_replace("<br>".$arg1,"<br>".$arg2,$message);
            
            $mey = substr($message,0,(strlen($arg1)));
            
            if ($mey == $arg1)
            {
                $message = "\n".$message;
                $message = str_replace("\n".$arg1,$arg2,$message);
            }
        }
        
        return $message;
    }
    
    public function fade($line,$code,$red,$green,$blue)
    {
    
    if (stristr($red,'_') == TRUE) 
    {
    $red = str_replace('_','',$red);
    // find bottom values
    $arr = explode(',',$red.','.$green.','.$blue);
    for ($i = 0; $i < count($arr); $i++)
    {
    $arr[$i] = str_replace('AA','110',$arr[$i]);
    $arr[$i] = str_replace('BB','121',$arr[$i]);
    $arr[$i] = str_replace('CC','132',$arr[$i]);
    $arr[$i] = str_replace('DD','143',$arr[$i]);
    $arr[$i] = str_replace('EE','154',$arr[$i]);
    $arr[$i] = str_replace('FF','165',$arr[$i]);
    $arr[$i] = str_replace('RR','200',$arr[$i]);
    $arr[$i] = str_replace('*','',$arr[$i]);
    }
    $min = (min($arr))/11;
    }
    if ($code == '!mono') { $min = 2; }
    
    if (stristr($red,'*') == TRUE) { $red = str_replace('*','',$red); $flip = 1; }
    
    $line = str_replace($code,'',$line);
    
    $colinc = intval(strlen($line)/(15-$min));
    
    if ($colinc == 0)
    {
    $colinc = 1;
    }
    
    if (strlen($min) == 0) { $min = 0; }
    
    // okay now do the magic
    for ($i = $min; $i <= 15; $i++)
    {
    
    if ($flip == 1) { $randcol = (15+$min)-$i; } else { $randcol = $i; }
    
    if ($randcol > 9)
    {
    $randcol = str_replace('10','aa',$randcol);
    $randcol = str_replace('11','bb',$randcol);
    $randcol = str_replace('12','cc',$randcol);
    $randcol = str_replace('13','dd',$randcol);
    $randcol = str_replace('14','ee',$randcol);
    $randcol = str_replace('15','ff',$randcol);
    }
    else
    {
    $randcol = $randcol.$randcol;
    }
    
    $lcolors = $red.$green.$blue;
    $lcolors = str_replace('RR',$randcol,$lcolors);
    
    $la = substr($line,0,$colinc);
    
    if ($i == 15 && strlen($line) > $colinc)
    {
    $la = $line;
    }
    
    $nuline .= '<span style="color: #'.$lcolors.'; background-color: #000000;">'.$la.'</span>';
    $line = substr($line,$colinc);
    }
    
    $line = $nuline;
    
    return $line;
    
    }
    
    public function parse($message)
    {
        $message = str_ireplace('miguel','(doxxname)',$message);
        $message = trim($message);
        $omessage = $message;
          
        
        // TODO: 
        /*
        if ($branchid == 2)
        {
            $message = parse_phpbb($message);
        }*/
        
        $q = genhash(4);
        // Autoimage 
        $message = preg_replace("#^(https?://.*[.](png|jpeg|jpg|gif|tff|bmp|svg))#im",
            '<div style="display:inline-block;" class="show-media show-picture givepic" link="$1"><a href="javascript:return;"><img src="$1" /></a></div>'
        ,$message);
        
        $message = str_replace('Cerberus','<img src="/images/cerberus.png" style="height: 20px; position: relative; top: 4px;" />',$message);
        
        if (strpos($message,'[doc') !== false && strpos($message,'[/doc]') !== false)
        {
            $chek = explode('[doc',$message);
            array_shift($chek);
            foreach ($chek?:Array() AS $row)
            {
                $row = explode('[/doc]',$row);
                $row = $row[0];
                $head = explode(']',$row);
                $txt = $head[1];
                $oldtxt = $txt;
                $head = $head[0];
                $oldhead = $head;
                
                $delim_left = '\\';
                $delim_right = '\\';
                $tags = Array('y');
                
                if ($head)        
                {
                    $head = explode(':',$head);
                    array_shift($head);
                    if ($head[0])
                    {
                        $tags = explode(',',$head[0]);
                    }
        
                    $delim = $head[1];
                    
                    if ($delim)
                    {
                        $delim_left = substr($delim,0,1);
                        $delim_right = substr($delim,1,1);
                        if (!$delim_right) { $delim_right = $delim_left; }
                    }
                }
        
                $start_tags = '';
                $end_tags = '';
                // parse tags
                foreach ($tags?:Array() AS $tag)
                {
                    $start_tags = '['.str_replace('+','][',$tag).']';
                    
                    $rev = array_reverse(explode('+',$tag));
                    $rev = implode('+',$rev);
                    
                    $end_tags = '[/'.str_replace('+','][/',$rev).']';
                }
                
                if ($delim_left != $delim_right)
                {
                    $txt = str_replace($delim_left,$start_tags,$txt);
                    $txt = str_replace($delim_right,$end_tags,$txt);
                }
                else
                {
                    $txt = explode($delim_left,$txt);
                    for ($i = 1; $i < count($txt); $i++)
                    {
                        if ($i % 2 == 1)
                        {
                            $txt[$i] = $start_tags.$txt[$i];
                        }
                        else
                        {
                            $txt[$i] = $end_tags.$txt[$i];
                        }
                    }
                    $txt = implode('',$txt);
                }
                
                $rep = '[doc'.$oldhead.']'.$oldtxt.'[/doc]';
                
                $message = str_replace($rep,$txt,$message);
            }
        }
        
        if (strpos($message,'[table') !== false && strpos($message,'[/table]') !== false)
        {
            $row = explode('[table',$message);
            array_shift($row);
            foreach ($row?:Array() AS $unit)
            {
                $table = explode('[/table]',$unit);
                $table = $table[0];
                $repl = $table;
                
                $table = explode(']',$table);
                
                $head = array_shift($table);
                
                $head = explode(' ',$head);
                
                $tclass = Array();
                
                if (in_array('full',$head))
                {
                    $tclass[] = 'full-table';   
                }
                if (in_array('center',$head))
                {
                    $tclass[] = 'table-center';
                }
                
                $tclass = implode(' ',$tclass);
                
                $table = implode(']',$table);
                
                $html = '<table class="message-table '.$tclass.'" cellspacing="0">';
                $table = explode("\n",$table);
                array_shift($table);
                
                if (!count($table)) { continue; }
                
                $i = 0;
                foreach ($table?:Array() AS $tr)
                {
                    if (!$tr) { continue; } 
                    $tag = 'td';
                    if (!$i && in_array('top',$head))
                    {
                        $tag = 'th';
                    }
                    
                    $html .= '<tr>';
                    
                    $tr = explode('|',$tr);
                    $xind = 0;
                    foreach ($tr AS $tre)
                    {
                        $celltags = Array();
                        
                        if (substr($tre,0,1) == '(')
                        {
                            $tre = explode(')',$tre);
                            $comm = str_replace('(','',array_shift($tre));
                            $tre = implode(')',$tre);
                            
                            $comm = explode(' ',$comm);
                            foreach ($comm?:Array() AS $thing)
                            {
                                $thing = explode('=',$thing);
                                
                                $celltags[$thing[0]] = $thing[1];
                            }
                        }
                        
                        $ltag = $tag;
                        if (in_array('left',$head) && !$xind)
                        {
                            $ltag = 'th';
                        }
                
                        $props = '';
                    
                        if ($celltags['cols'])
                        {
                            $props .= ' colspan="'.$celltags['cols'].'"';
                        }
               
                        $html .= '<'.$ltag.$props.' style="'.$style.'">'.$tre.'</'.$ltag.'>';
                        $xind++;
                    }
                    $html .= '</tr>';
                    
                    $i++;
                }
                $html .= '</table>';
                
                $r = '[table'.$repl.'[/table]';
        
                $message = str_replace($r,$html,$message);
            }
        }

        $message = $this->newtag($message,Array(
            'tag' => 'color',
            'format' => '<span class="color-tag" style="$style">$text</span>',
            'default' => 'color',
            'style' => Array(
                'color' => Array('color','color'),
                'bg' => Array('background-color','color')
            )
        ));
            
        $message = preg_replace("#^&gt;(.*)#m",'<div class="quote">$1</div>',$message);
        $message = preg_replace("#^>(.*)#m",'<div class="quote">$1</div>',$message);
         
        // Autolink
        $message = str_replace('&','&amp;',$message);
        $message = preg_replace("#(\n|^)(https?://.*)(\n|$)#im",'<a href="$2" class="xurl">$2</a>',$message);
        $message = str_replace('&amp;','&',$message);
             
        $message = explode("\n",$message);
        
        for ($a = 0; $a < count($message); $a++)
        {
        
            if (substr($message[$a],0,strlen('!flame')) == '!flame') { $message[$a] = $this->fade($message[$a],'!flame','FF','RR','22'); }
            if (substr($message[$a],0,strlen('!flare')) == '!flare') { $message[$a] = $this->fade($message[$a],'!flare','*FF','RR','22'); }
            if (substr($message[$a],0,strlen('!love')) == '!love') { $message[$a] = $this->fade($message[$a],'!love','DD','00','RR'); }
        
        }
        
        $message = implode("\n",$message);
        
        $message = str_replace('[done]','<div class="xhin-done"><i class="material-icons">done</i><span>Done!</span></div><br />',$message);
        $message = str_replace('[fixed]','<div class="xhin-done"><i class="material-icons">done</i><span>Fixed!</span></div><br />',$message);
        
        $message = str_replace("\n\n\n","\n\n",$message);
        $message = str_replace("\n\n\n","\n\n",$message);
        
        if (strpos($message,'[**]') !== false && strpos($message,'[/**]') !== false)
        {
            $message = explode('[**]',$message);
            foreach ($message AS $i => $bit)
            {
                if ($i == 0) { continue; }
                $row = explode('[/**]',$bit);
                $lookfor = $row[0];
                $text = '';
                for ($x = 0; $x < strlen($lookfor); $x++)
                {
                    if ($lookfor[$x] == ' ') { $text .= ' '; continue; }
                    $text .= '[*]'.$lookfor[$x].'[/*]';
                }
                $message[$i] = $text.$row[1];
            }
            $message = implode('',$message);
        }
        
        
        
        $message = str_replace("\n","</center></b></i></font></u></del></span><br>",$message);
        
        $message = str_ireplace("[b]","<b>",$message);
        
        $message = str_ireplace("[/b]","</b>",$message);
        $message = str_ireplace("[i]","<i>",$message);
        $message = str_ireplace("[/i]","</i>",$message);
        $message = str_ireplace("[u]","<u>",$message);
        $message = str_ireplace("[/u]","</u>",$message);
        
        $message = str_ireplace("[s]","<del>",$message);
        $message = str_ireplace("[/s]","</del>",$message); 
        $message = str_ireplace("[ha]","<span class=\"comic\">",$message);
        $message = str_ireplace("[no]","<span class=\"deadpan\">",$message);
        $message = str_ireplace("[w]","<span class=\"inline-spoiler\">",$message);
        
        $message = str_ireplace("[/ha]","</span>",$message); 
        $message = str_ireplace("[/no]","</span>",$message);
        $message = str_ireplace("[/w]","</span>",$message);
        
        $message = str_replace("[#]",'<span style="text-shadow: 1px 1px #000, 1px -1px #000, -1px 1px #000, -1px -1px #000;">',$message);
        $message = str_replace("[/#]",'</span>',$message);
        
        $message = str_ireplace("[sub]","<span style=\"position: relative; top: 0.3em; font-size: 0.9em;\">",$message);
        $message = str_ireplace("[/sub]","</span>",$message);
        
        $message = str_ireplace("[sup]","<span style=\"position: relative; bottom: 0.5em; font-size: 0.9em;\">",$message);
        $message = str_ireplace("[/sup]","</span>",$message);
        
        //flow('mod',$GLOBALS);
        
        $message = explode('[*]',$message);
        $modulo = count($GLOBALS['color_sequence']);
        foreach ($message AS $i => &$block)
        {
            if ($i == 0) { continue; } 
            $block = '['.$GLOBALS['color_sequence'][($i-1)%$modulo].']'.$block;
        }
        $message = implode('',$message);
        
        $message = str_replace('[*]','['.$GLOBALS['color_sequence'][$seq].']',$message);
        
        // inline colors
        
        $message = str_ireplace("[o]","<span class='font-orange'>",$message);
        $message = str_ireplace("[y]","<span class='font-yellow'>",$message);
        $message = str_ireplace("[c]","<span class='font-cyan'>",$message);
        $message = str_ireplace("[r]","<span class='font-red'>",$message);
        $message = str_ireplace("[g]","<span class='font-green'>",$message);
        $message = str_ireplace("[p]","<span class='font-purple'>",$message);
        $message = str_ireplace("[k]","<span class='font-pink'>",$message);
        $message = str_ireplace("[e]","<span class='font-blue'>",$message);
        $message = str_ireplace("[br]","<span class='font-bloodred'>",$message);
        $message = str_ireplace("[jo]","<span class='font-jackorange'>",$message);
        $message = str_ireplace("[sh]","<span class='font-shadow'>",$message);
        $message = str_ireplace("[hi]","<span class='font-hi'>",$message);
        
        $message = str_ireplace("[xo]","<span class='font-xo'>",$message);
        $message = str_ireplace("[ox]","<span class='font-ox'>",$message);
        
        
        $message = str_ireplace("[em]","<span class='font-emerald'>",$message);
        $message = str_ireplace("[sa]","<span class='font-sapphire'>",$message);
        $message = str_ireplace("[bw]","<span class='font-brown'>",$message);
        $message = str_ireplace("[si]","<span class='font-silver'>",$message);
        $message = str_ireplace("[go]","<span class='font-gold'>",$message);
        $message = str_ireplace("[ru]","<span class='font-ruby'>",$message);
        $message = str_ireplace("[ov]","<span class='font-olive'>",$message);
        
        $message = str_ireplace("[/o]","</span>",$message);
        $message = str_ireplace("[/y]","</span>",$message);
        $message = str_ireplace("[/c]","</span>",$message);
        $message = str_ireplace("[/r]","</span>",$message);
        $message = str_ireplace("[/g]","</span>",$message);
        $message = str_ireplace("[/p]","</span>",$message);
        $message = str_ireplace("[/k]","</span>",$message);
        $message = str_ireplace("[/e]","</span>",$message);
        $message = str_ireplace("[/br]","</span>",$message);
        $message = str_ireplace("[/jo]","</span>",$message);
        $message = str_ireplace("[/sh]","</span>",$message);
        $message = str_ireplace("[/hi]","</span>",$message);
        
        $message = str_ireplace("[/em]","</span>",$message);
        $message = str_ireplace("[/sa]","</span>",$message);
        $message = str_ireplace("[/bw]","</span>",$message);
        $message = str_ireplace("[/si]","</span>",$message);
        $message = str_ireplace("[/go]","</span>",$message);
        $message = str_ireplace("[/ru]","</span>",$message);
        $message = str_ireplace("[/xo]","</span>",$message);
        $message = str_ireplace("[/ox]","</span>",$message);
        $message = str_ireplace("[/ov]","</span>",$message);
        
        
        $message = str_replace("[/*]",'</span>',$message);
        
        $message = str_replace("\%%","%%",$message);
        
        $message = str_ireplace("house of leaves","<font color=#7777ff>House</font> of Leaves",$message);
        
        $message = $this->linecode('=>','<b>',$message);
        $message = $this->linecode('=','<b>',$message);
        $message = $this->linecode('//','<i>',$message);
        $message = $this->linecode('**','<li>',$message);
        $message = $this->linecode('* ','<li>',$message);
        $message = $this->linecode('*-','<li type=square>',$message);
        $message = $this->linecode('*=','<li type=circle>',$message);
        
        $message = $this->linecode('!ice','<font color=cyan>',$message);
        
        // color codes
        $message = explode('<br>',$message);
        for ($i = 0; $i < count($message); $i++)
        {
        if (substr($message[$i],0,1) != '!') { continue; }
        unset($x);
        $head = explode(' ',$message[$i]); $head = $head[0]; $old_head = $head;
        
        $x[0] = '';
        $xclass = Array();
        
      
        if (substr($head,0,3) == '!!!') { $x[count($x)] = 'font-size: 1.8em;'; $head = str_replace('!!!','',$head); }
        else { if (substr($head,0,2) == '!!') { $x[count($x)] = 'font-size: 1.4em;'; $head = str_replace('!!','',$head); } } 
        
        $head = str_replace('!','',$head);
        $head = str_replace('?','',$head);
        if (stristr($head,'=') == TRUE) { $x[count($x)] = 'font-weight: bold;'; $head = str_replace('=','',$head);}
        if (stristr($head,'&gt;') == TRUE) { $xclass[] = 'quote'; $head = str_replace('&gt;','',$head); }
        if (stristr($head,'//') == TRUE) { $x[count($x)] = 'font-style: italic;'; $head = str_replace('//','',$head);}
        if (stristr($head,'_') == TRUE) { $x[count($x)] = 'text-decoration: underline;'; $head = str_replace('_','',$head); }
        if (stristr($head,'&') == TRUE) { $x[count($x)] = 'font-family: Comic Sans MS,Verdana,Helvetica,sans-serif'; $head = str_replace('&','',$head); }
        if (stristr($head,'#') == TRUE) { $x[count($x)] = '  text-shadow:
           -1px -1px 0 #600,  
            1px -1px 0 #600,
            -1px 1px 0 #600,
             1px 1px 0 #600;'; $head = str_replace('#','',$head); }
        if (stristr($head,'~') == TRUE) { $x[count($x)] = 'font-family: Courier New, Courier, monospace;'; $head = str_replace('~','',$head); }
        if ($head == 'orange') { $x[count($x)] = 'color: #FF6910;'; }
        if ($head == 'yellow') { $x[count($x)] = 'color: yellow;'; }
        if ($head == 'cyan') { $x[count($x)] = 'color: cyan;'; }
        if ($head == 'red') { $x[count($x)] = 'color: #d44;'; }
        if ($head == 'green') { $x[count($x)] = 'color: #4f4;'; }
        if (substr($head,0,2) == 'xo' || substr($head,0,2) == 'ox' && str_replace(Array('x','o'),'',$head) == '') {
            $seed = bindec(intval(str_replace('x','1',str_replace('o','0',$head))));
            srand($seed);
            $red = str_pad(dechex(rand(130,255)),2,'0',STR_PAD_LEFT);
            $green = str_pad(dechex(rand(0,80)),2,'0',STR_PAD_LEFT);
            $blue = str_pad(dechex(rand(60,210)),2,'0',STR_PAD_LEFT);
            
            
            $color = $red.$green.$blue;
            $head_length = strlen($head)+1;
            $message[$i] = '<span style="color: #'.$color.';">'.substr($message[$i],$head_length,strlen($message[$i])-$head_length).'</span>';
            continue;
        }
        
        if ($head == 'emerald') { $x[count($x)] = 'color: #4f9;'; }
        if ($head == 'sapphire') { $x[count($x)] = 'color: #269CFF;'; }
        if ($head == 'olive') { $x[count($x)] = 'color: #808000;'; }
        if ($head == 'brown') { $x[count($x)] = 'color: #97572A;'; }
        if ($head == 'silver') { $x[count($x)] = 'color: #999;'; }
        if ($head == 'gold') { $x[count($x)] = 'color: #ffc800;'; }
        if ($head == 'ruby') { $x[count($x)] = 'color: #ad1c44;'; }
        
        if (substr($head,0,3) == 'val')
        {
            $hex = Array(10 => 'a', 11 => 'b', 12 => 'c', 13 => 'd', 14 => 'e', 15 => 'f');
            $val = substr($head,3);
            $val = $val*2;
            if ($val >= 10 ) { $val = $hex[$val]; }
            $x[count($x)] = 'color: #'.$val.'00080;';
        }
        
        if ($head == 'purple') { $x[count($x)] = 'color: #A6D;'; }
        if ($head == 'pink') { $x[count($x)] = 'color: #f99;'; }
        if ($head == 'shadow') { $x[count($x)] = 'color: #fff; background-color: #444'; }
        
        if ($head == 'blue') { $x[count($x)] = 'color: #77f;'; }
        if ($head == 'bloodred') { $x[count($x)] = 'color: #760202;'; }
        if ($head == 'jackorange') { $x[count($x)] = 'color: #E58400;'; }
        if ($head == 'frog') { $x[count($x)] = 'color: #7f4; font-family: \'Bonbon\', cursive; font-size: 2em; text-shadow: 0px 2px green; line-height: 1.3em;'; }
        $message[$i] = str_replace($old_head,'',$message[$i]); 
        $x = implode(' ',$x);
        $xclass = implode(' ',$xclass);
        $message[$i] = '<span style="'.$x.'" class="'.$xclass.'">'.$message[$i].'</span>';
        }
        $message = implode('<br>',$message); 
        
        if (has($message,'[bitchute]') && has($message,'[/bitchute]'))
        {
            $message = explode('[bitchute]',$message);
            $mi = 0;
            foreach ($message AS &$line)
            {
                if ($mi == 0) { $mi++; continue; }
                $line = explode('[/bitchute]',$line);
                $inside = $line[0];
                $outside = $line[1];
                $url = str_replace('/video/','/embed/',$inside);
                $line = '<div id="bitchute"><a href="" id="bitchute-fullscreen">Toggle Fullscreen</a><iframe src="'.$url.'"></iframe></div>'.$outside;
                $mi++;
            }   
            $message = implode($message);
        }
        
        if (has($message,'[media]') && has($message,'[/media]'))
        {
            $om = explode('[media]',$message);
            array_shift($om);

            foreach ($om AS $line)
            {
                $line = explode('[/media]',$line);
                $inside = $line[0];
                $done = Engine::media()->translate($inside);
                $message = str_replace('[media]'.$inside.'[/media]',$done,$message);
            }   
        }
        
        if (has($message,'[font center]') && has($message,'[/font]'))
        {
            $message = explode('[font center]',$message);
            $mi = 0;
            foreach ($message AS &$line)
            {
                if ($mi == 0) { $mi++; continue; }
                $line = explode('[/font]',$line);
                $inside = $line[0];
                $outside = $line[1];
                $line = '<div style="text-align: center;">'.$inside.'</div>'.$outside;
                $mi++;
            }   
            $message = implode($message);
        }
        
        // youtube tags
        if (stristr($message,'[youtube') == TRUE && stristr($message,'[/youtube]') == TRUE)
        {
        // PIMG
        $message = explode('[youtube',$message);
        for ($i = 1; $i < count($message); $i++)
        {
        $message[$i] = explode('[/youtube]',$message[$i]);
        $stuff = $message[$i][0];
        switch (substr($stuff,0,2))
        {
        case '="':
        $stuff = substr($stuff,2);
        $findval = explode('"]',$stuff);
        $location = $findval[0];
        $caption = $findval[1];
        $with = '[youtube="'.$location.'"]'.$caption;
        break;
        
        default:
        $location = substr($stuff,1);
        $caption = 'Show Youtube';
        $with = '[youtube]'.$location;
        break;
        }
        
        $q = genhash(4);
        
        $vid = explode('=',$location);
        array_shift($vid);
        $vid = implode('=',$vid);
        $vid = explode('&',$vid);
        $vid = $vid[0];
        $vid = explode('#',$vid);
        $time = $vid[1];
        $vid = $vid[0];
        $location = $vid;
        
        if ($time)
        {
            $time = explode('m',$time);
            $min = str_replace('t=','',$time[0]); 
            $sec = str_replace('s','',$time[1]);
            $time = ($min*60)+$sec;
        }
            
        $full_location = 'https://www.youtube.com/v/'.$location;
        
        if ($time)
        {
            $full_location .= '&version=3&start='.$time;
        }
        
        if ($_COOKIE['o10'] == '0' || !$_COOKIE['o10']) {
        $message[$i][0] = '<div id="yt'.$q.'" class="show-youtube show-media">
        
        
        
        <img src="https://i3.ytimg.com/vi/'.$vid.'/default.jpg" onclick="showtube(\''.$full_location.'\',\''.$q.'\');" /></div>';
        }
        else
        {
        $message[$i][0] = '<div style="text-align: center;" id="yt'.$q.'"><input type="button" onclick="hidetube(\''.$full_location.'\',\''.$q.'\');" value="Hide Youtube" /><br /><object width="640" height="385"><param name="movie" value="'.$full_location.'&hl=en_US&fs=1"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="'.$full_location.'&hl=en_US&fs=1" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="640" height="385"></embed></object></div>';
        }
        
        $message[$i] = implode('',$message[$i]);
        }
        $message = implode('',$message);
        }
        
        
        if (strpos($message,'[url') !== false && strpos($message,'[/url]') !== false)
        {
            $arr = explode('[url',$message);
            array_shift($arr);
            foreach ($arr?:array() AS $row)
            {
                $row = explode('[/url]',$row);
                $row = $row[0];
                $row = explode(']',$row);
                $head = $row[0];
                $head = substr($head,1);
                
                if (!$head)
                {
                    $body = $row[1];
                    $head = $body;
                    $rep = '[url]'.$body.'[/url]';
                }
                elseif (has($head,'"'))
                {
                    $head = str_replace('"','',$head);
                    $body = $row[1];
                    if (!$head) { $head = $body; }
                    $rep = '[url="'.$head.'"]'.$body.'[/url]';
                }
                else
                {
                    $body = $head;      
                    $head = $row[1];
                    $rep = '[url='.$body.']'.$head.'[/url]';
                }
                
                $message = str_replace($rep,'<a href="'.$body.'" class="xurl">'.$head.'</a>',$message);
            }
        }
        
        
        
        if (has($message,'[size ') && has($message,'[/size]'))
        {
            $arr = explode('[size ',$message);
            array_shift($arr);
            foreach ($arr?:Array() AS $row)
            {
                $row = explode('[/size]',$row);
                $row = $row[0];
                $row = explode(']',$row);
                $head = array_shift($row);
                $body = implode(']',$row);
        
                $rep = '[size '.$head.']'.$body.'[/size]';
                
                $head = trim($head);
                
                if ($head == 0) { $head = 1; }
                if ($head < 0.5) { $head = 0.5; }
                if ($head > 1.5) { $head = 1.5; }
                
                $message = str_replace($rep,'<span style="font-size: '.$head.'em;">'.$body.'</span>',$message);
            }
        }
        
        // kill off bad tags
        $message = str_replace('[/size]','',$message);
       
        // img tags
        if (stristr($message,'[img') == TRUE && stristr($message,'[/img]') == TRUE)
        {
        // PIMG
        $message = explode('[img',$message);
        for ($i = 1; $i < count($message); $i++)
        {
        $message[$i] = explode('[/img]',$message[$i]);
        $stuff = $message[$i][0];
        switch (substr($stuff,0,2))
        {
        case '="':
        $stuff = substr($stuff,2);
        $findval = explode('"]',$stuff);
        $location = $findval[0];
        $caption = $findval[1];
        $with = '[img="'.$location.'"]'.$caption;
        break;
        
        default:
        $location = substr($stuff,1);
        $caption = 'Show Image';
        $with = '[img]'.$location;
        break;
        }
        //$location = 'https://3.bp.blogspot.com/-JxzY1ppQUKo/UUL8Mp7sv5I/AAAAAAAADIc/-M4wMvarEmo/s400/funny7.jpg';
        
        if (substr($location,0,4) == 'www.') { $location = 'https://'.$location; }
        $q = genhash(4);
        if ($fid != 170)
        {
            if ($_COOKIE['o11'] || $auto_image)
            {
                $message[$i][0] = '<div id="givepic'.$q.'" style=""><img id="tpic'.$q.'" title="'.$caption.'" ondblclick="hidepic(\''.$location.'\',\''.$q.'\');" style="border: 1px solid #fff;" src="'.$location.'"/></div>';
            }
            else
            {
                $message[$i][0] = '<div style="display:inline-block;" class="show-media show-picture" id="givepic'.$q.'"><a href="javascript:showpic(\''.$location.'\',\''.$q.'\',\''.addslashes($caption).'\');"><img src="'.$location.'" /></a></div>';
            }
        }
        else 
        {
        $message[$i][0] = '<div style="" id="givepic'.$q.'"><img src="'.$location.'" style="border: 1px solid rgb(255, 255, 255);" ondblclick="hidepic(\''.$location.'\',\''.$q.'\');" title="'.$caption.'" id="tpic[object HTMLDivElement]"></div>';
        }
        
        $message[$i] = implode('',$message[$i]);
        }
        $message = implode('',$message);
        }
        
        
        if (stristr($message,'[joke') == TRUE && stristr($message,'[/joke]') == TRUE)
        {
            $message = explode('[joke',$message);
            foreach ($message AS &$meme)
            {
                if (strpos($meme,'[/joke]') === FALSE) { continue; }
                $x = explode('[/joke]',$meme);
                $restoftext = $x[1];
                $x = $x[0]; 
                $x = explode('="',$x); $x = $x[1];
                $x = explode('"',$x);
                $caption = strtoupper($x[0]); $img = str_replace(']','',$x[1]);
                $meme = '<p><div class="meme-wrapper">{ <a class="meme" img="'.$img.'" caption="'.$caption.'" href="javascript:return;">Show Joke</a> }</div></p>'.$restoftext; 
            }
            $message = implode('',$message);
        }
        
        if (strpos($message,'[quote]') !== FALSE || strpos($message,'[/quote]') !== FALSE)
        {    
            $q = substr_count($message,'[quote]');
            $qc = substr_count($message,'[/quote]');
            for ($i = 0; $i < ($qc-$q); $i++)
            {
                $message = '[quote]'.$message;
            }
            for ($i = 0; $i < ($q-$qc); $i++)
            {
                $message .= '[/quote]'; 
            }
            
            $message = str_replace('[quote]','<div class="quote">',$message);
            $message = str_replace('[/quote]','</div>',$message);
        }
        
        // Code Tag (yeah this section really needs some work...)
        if (stristr($message,'[code]') == TRUE && stristr($message,'[/code]') == TRUE)
        {
        // PIMG
        $message = explode('[code]',$message);
        for ($i = 1; $i < count($message); $i++)
        {
        $message[$i] = explode('[/code]',$message[$i]);
        $quote = $message[$i][0];
        
        $message[$i][0] = '<pre><code class="language-java">'.$quote.'</code></pre>';
        $message[$i] = implode('',$message[$i]);
        }
        $message = implode('',$message);
        }
        
        // spoiler tags
        if (stristr($message,'[hide') == TRUE && stristr($message,'[/hide]') == TRUE)
        {
        // PIMG
        $message = explode('[hide',$message);
        for ($i = 1; $i < count($message); $i++)
        {
        $message[$i] = explode('[/hide]',$message[$i]);
        $stuff = $message[$i][0];
        switch (substr($stuff,0,2))
        {
        case '="':
        $stuff = substr($stuff,2);
        $findval = explode('"]',$stuff);
        $caption = 'Toggle '.$findval[0];
        $location = $findval[1];
        $with = '[hide="'.$caption.'"]'.$location;
        break;
        
        default:
        $location = substr($stuff,1);
        $caption = 'Show Spoiler';
        $with = '[hide]'.$location;
        break;
        }
        $q = genhash(4);
        
        $message[$i][0] = '<div class="spoiltop"><a href="javascript:showspoiler(\''.$q.'\');" id="spoilclick'.$q.'">'.$caption.'</a></div><div id="spoil'.$q.'" class="quote spoil" style="display: none;">'.$location.'</div>';
        $message[$i] = implode('',$message[$i]);
        }
        $message = implode('',$message);
        }

        
        // close tags and whatnot
        
        if (!$soft_parse)
        {
            $message = '<br>'.$message;
        }
        
        $message .= '</b></i></u></span></font></center></del>';
        
        if (!$soft_parse)
        {
            $message .= '<br><br>';
        }
        
        $message = str_replace('``','<em></em>',$message);
        
        
        return $message;
    }

    /*
    $test = Array(
        'tag' => 'color',
        'format' => '<span class="color-tag" style="$style">$text</span>',
        'style' => Array(
            'color' => Array('color','color'),
            'bg' => Array('background-color','color')
        )
    );*/
        
    public function newtag($message,$obj)
    {
        $tag = $obj['tag'];
        
        $open = '['.$tag;
        $close = '[/'.$tag.']';
        
        if (!has($message,$open) || !has($message,$close))
        {
            return $message;
        }

        $units = explode($open,$message);
        array_shift($units);
        foreach ($units as $unit)
        {
            $unit = explode(']',$unit);
            $otags = array_shift($unit);
            $tags = $otags;
            $unit = implode(']',$unit);

            $unit = explode($close,$unit);
            $inside = $unit[0];
            
            $style = '';
            if ($obj['style'])
            {
                $tags = explode(' ',$tags);
                array_shift($tags);
                $arr = Array();
                foreach ($tags as $tag)
                {
                    if (!has($tag,':'))
                    {
                        $arr[$obj['default']] = $tag;
                        continue;
                    }
                    
                    $tag = explode(':',$tag);
                    $arr[$tag[0]] = $tag[1];
                }

                foreach ($obj['style'] as $key => $val)
                {
                    if (!$arr[$key]) { continue; }
                    if ($val[1] == 'color')
                    {
                        if (is_numeric($arr[$key]))
                        {
                            $arr[$key] = '#'.$arr[$key];
                        }
                    }
                    $arr[$key] = safe($arr[$key]);
                    $arr[$key] = str_replace('"','',$arr[$key]);
                    $style .= $val[0].': '.$arr[$key].'; ';                        
                }
            }
            
            $replacement = $obj['format'];
            $replacement = str_replace('$text',$inside,$replacement);
            $replacement = str_replace('$style',$style,$replacement);
            
            $original = $open.$otags.']'.$inside.$close;
            
            // flow($original,$replacement);
            
            $message = str_replace($original,$replacement,$message);
        }
        
        return $message;
    }
}