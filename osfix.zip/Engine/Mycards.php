<?php
// Will be deprecated when the new avatars feature launches, so no point in developing it any past this.
Class Engine_Mycards
{
    public function thread($tid) 
    {
        Engine::view()->add_css('mycard');
        $mycards = ZXC::sel('1user,3data/posts<1user=2username>names<2nameid=3uid>mycards')->where('1tid',$tid)->go();
        $arr = Array();
        foreach ($mycards as $row)
        {
            $arr[$row['user']] = $row['data'];
        }
        return $arr;
    }
    
    public function all()
    {
        $mycards = ZXC::sel('1username,2data/names<1nameid=2uid>mycards')->go();
        return $mycards;
    }
}