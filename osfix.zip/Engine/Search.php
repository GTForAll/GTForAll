<?php
Class Engine_Search
{
    public function threads($data,$page=1)
    {
        if (!$page) { $page = 1; }
        
        $ZXC = Read::threads()->feed($page);
        
        $title = $data['title'];
        
        $first_poster = $data['first_poster'];
        $last_poster = $data['last_poster'];
        
        $date_type = $data['date_type'];
        $date = $data['date'];
        $date_search = $data['date_search'];
        $date_range = $data['date_range'];
        
        $forums = $data['forums'];
        $feed_type = $data['feed_type'];
        $feed_sort = $data['feed_sort'];
        
        $length_min = $data['length_min'];
        $length_max = $data['length_max'];
        
        $pit = $data['people_in_thread'];
        $message = $data['message'];
        
        $say = Array();
        
        if ($title)
        {
            $say['title'] = $title;
            $title = str_replace('*','%',$title);
            $ZXC->like('1title',$title);
        }
        
        if ($first_poster)
        {
            $say['first poster'] = $first_poster;
            $user = str_replace('*','%',$first_poster);
            $q = '1user';
            if ($data['first_poster_not']) { $q .= '!='; }
            $ZXC->like($q,$user);
        }
        
        if ($last_poster)
        {
            $say['last_poster'] = $last_poster;
            $user = str_replace('*','%',$last_poster);
            $q = '3user';
            if ($data['last_poster_not']) { $q .= '!='; }
            $ZXC->like($q,$user);
        }
        
        if ($pit[0])
        {
            // Could generalize, but this is already hard to wrap my head around
            /*
            if ($pit[2])
            {
                $ZXC->whin('1tid',
                    ZXC::sel('tid/posts')->whin('1tid',
                        ZXC::sel('tid/posts')->whin('1tid',
                            ZXC::sel('tid/posts')->where('user',$pit[0])
                        )->where('user',$pit[1])
                    )->where('user',$pit[2])
                );
            }*/
            if ($pit[1])
            {
                $ZXC->whin('1tid',
                    ZXC::sel('tid/posts')->whin('1tid',
                        ZXC::sel('tid/posts')->where('user',$pit[0])->sort('#tid')
                    )->where('user',$pit[1])->sort('#tid')
                );
            }
            else
            {
                $ZXC->whin('1tid',
                    ZXC::sel('tid/posts')->where('user',$pit[0])->sort('#tid')
                );
            }
        }
        
        $say['last_length'] = '';
        
        if ($length_min)
        {
            $ZXC->where('~3message>',$length_min);
            $say['last_length'] = ' > '.$length_min;
        }
        
        if ($length_max)
        {
            $ZXC->where('~3message<',$length_max);
            if ($length_min)
            {
                $say['last_length'] .= ', ';
            }
            $say['last_length'] .= ' < '.$length_max;
        }
        
        if (!$say['last_length'])
        {
            unset($say['last_length']);
        }
        
        
        if ($date_type && $date)
        {
            $dd = '3';
            if ($date_search == 'last_post')
            {
                $dd = '3';
            }
            else
            {
                $dd = '4';
            }
            
            $date = strtotime($date);
            if ($date_type == 'before')
            {
                $ZXC->where($dd.'dateline<',$date);
                $say['date before'] = $date;
            }
            elseif ($date_type == 'after')
            {
                $ZXC->where($dd.'dateline>',$date);
                $say['date after'] = $date;
            }
            elseif ($date_type == 'between')
            {
                $date_range = strtotime($date_range);
                
                $min = $date;
                $max = $date_range;
                if ($date > $date_range)
                {
                    $min = $date_range;
                    $max = $date;
                }
                $say['date_range'] = date('n/j/Y',$min).' - '.date('n/j/Y',$max);
                $ZXC->where($dd.'dateline>',$min,$dd.'dateline<',$max);
            }
        }
        
        if (count($forums) && !(count($forums) == 1 && !$forums[0]))
        {
            $ZXC->iter('1fid',$forums);
            $say['in forums'] = implode(',',$forums);
        }
        
        $sort = '';
        if ($feed_type == 'newest')
        {
            $sort = 'tid';
            $say['sort'] = 'newest';
        }
        elseif ($feed_type == 'most_replies')
        {
            $sort = 'replies';
            $say['sort'] = 'most replies';
        }
        else // hottest
        {
            $sort = 'lastpid';
            $say['sort'] = 'hottest';
        }
        
        // feed type
        if ($feed_sort == 'first')
        {
            $sort .= '--';
            $say['sort'] .= ' first';
        }
        else // last
        {
            $sort .= '++';
            $say['sort'] .= 'last';
        }
        
        $ZXC->sort($sort);
        
        $arr = $ZXC->go();
        
        return Array('data' => $arr, 'say' => $say);
    }
}