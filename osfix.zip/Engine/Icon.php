<?php
Class Engine_Icon
{
    public function format($el,$url)
    {
        $class = '';
        $style = '';
        if (!$url)
        {
            $icon = '/images/1blue.gif';
        }
        else
        {
            $icon = $url;
            if (!has($icon,'https'))
            {
                $icon = str_replace('http','https',$icon);
            }
            $icon = str_replace('"','&quot;',$icon);
            $class = 'icon-url';
            $style = "background-image: url('".$icon."');";
            $icon = '';
        }
        
        ?>
        <<?=$el?> class="<?=$class?>" style="<?=$style?>">
            <img src="<?=$icon?>" />
        </<?=$el?>>
        <?php 
    }
}
