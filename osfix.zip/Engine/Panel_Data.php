<?php
Class Engine_Panel_Data
{
    public function panel_blocklist()
    {
        return Array(
            'blocks' => Read::blocks()->by_uid(my('uid'))
        );
    }

    public function panel_permabans()
    {
        return Array(
            'bans' => Read::permabans()->get_all()
        );
    }

    public function panel_posting_filters()
    {
        return Array(
            'filters' => Read::posting_filters()->get_all()
        );
    }

    public function panel_accounts()
    {
        $route = Engine::routes()->get();
        $index = $route['index'];
        if (!$index)
        {
            $index = 'newest_50';
        }

        if ($index == 'newest_50')
        {
            $accounts = Read::users()->user()->sort('1uid--')->lim(50)->go();
        }
        else
        {
            $accounts = Read::users()->user()->like('1username',$index.'%')->sort('username++')->go();
        }

        return Array('accounts' => $accounts);
    }

    public function panel_lockdown()
    {
        return Array('vars' => Read::vars()->by_cat('lockdown'));
    }

    public function panel_filter_30()
    {
        $whitelist = Read::posting_filters()->get_f30_whitelist();
        $arr = Array();
        foreach ($whitelist as $white)
        {
            $arr[$white['type']][] = $white['value'];
        }

        return Array(
            'filter_threads' => Read::posting_filters()->get_f30_threads(),
            'filter_whitelist' => $arr
        );
    }


    public function panel_filter_31()
    {
        return Array(
            'filters' => Read::posting_filters()->get_f31(),
            'whitelist' => Read::posting_filters()->get_f31_whitelist()
        );
    }

    public function panel_filter_33()
    {
        return Read::posting_filters()->get_f33();
    }

    public function panel_filter_queue()
    {
        $queue = Read::posting_filters()->get_queue();
        foreach ($queue as $key => $val)
        {
            if ($val['fid'])
            {
                 $queue[$key]['net_type'] = 'New Thread';
                 $queue[$key]['loc'] = Array(
                    'url' => '/forum/'.$val['forum_slug'],
                    'name' => $val['forum_name']
                );
            }
            elseif ($val['tid'])
            {
                $queue[$key]['net_type'] = 'New Reply';
                $queue[$key]['loc'] = Array(
                    'url' => '/thread/'.$val['thread_slug'],
                    'name' => $val['thread_title']
                );
            }

            if ($val['filterid'] == 30)
            {
                $queue[$key]['desc'] = 'Filter #30';
                continue;
            }
            $queue[$key]['desc'] = deslug($val['field']).' '.deslug($val['type']).' '.$val['value'];
        }

        return Array('queue' => $queue);
    }
}
