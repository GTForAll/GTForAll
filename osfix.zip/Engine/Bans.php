<?php
Class Engine_Bans
{

  public function am_banned($data)
  {
    if ($data['tid'])
    {
      $data['fid'] = Read::threads()->get_fid($data['tid']);
    }

    $local_ip_bans = ZXC::sel('banid/bans')->where('type','ip','value',my('ip'),'fid',$data['fid'])->the();
    $global_ip_bans = ZXC::sel('banid/bans')->where('type','ip','value',my('ip'),'fid',-1)->the();
    $local_name_bans = ZXC::sel('banid/bans')->where('type','user','value',$data['user'],'fid',$data['fid'])->the();
    $global_name_bans = ZXC::sel('banid/bans')->where('type','user','value',$data['user'],'fid',-1)->the();

    if($local_ip_bans)
    {
      return $this->banned($local_ip_bans);
    }


    else if ($global_ip_bans)
    {
      if($data['fid']!=290)
      {
        return $this->banned($global_ip_bans);
      }
    }

    else if ($local_name_bans)
    {
      return $this->banned($local_name_bans);
    }

    else if ($global_name_bans)
    {
      if($data['fid']!=290)
      {
      return $this->banned($global_name_bans);
      }
    }

      return false;

    }

  private function banned ($banid)
  {

    $ban = Read::bans()->by_banid($banid);

    if($ban['fid'] == -1)
    {
      $where = 'all forums';
    }

    else {
      $where = 'this forum';
    }

    $end = $ban['end_time'];
    $when = date('m/d/y', $end);

    $reason = $ban['reason'];
    $moderator = $ban['username'];

    $this->banned_error = 'You have been  banned in '.$where.' by '.$moderator.' for '.$reason.' until '.$when.'.';

    return true;
  }

  public function post($id, $data)
  {

    $post = Read::posts()->by_pid($id);
    $this->ban($post,$data);

  }

  public function thread($id, $data)
  {

    $thread = Read::threads()->by_tid($id);
    $this->ban($thread,$data);

  }

  private function ban($data, $ban_data)
  {
    $end_time = strtotime($ban_data['end_time']);

    if ($ban_data['fid'] == 'local')
    {

      $ban_data['fid'] = $data['fid'];
    }
    else if ($ban_data['fid'] == 'global')
    {
      $ban_data['fid'] = -1;
    }

    $write_data = Array(
      'fid' => $ban_data['fid'],
      'type' => $ban_data['type'],
      'value' => $data[$ban_data['type']],
      'reason' => $ban_data['reason'],
      'end_time' => $end_time,
      'ban_user' => $data['user']
    );

    Write::bans()->add($write_data);
  }

}
