<?php
Class Engine_Slugs
{
    public function create($tid,$title)
    {
        $slug = slug($title);
        $groupslug = $slug;
        if (Read::threads()->by_slug($slug))
        {
            $amt = ZXC::sel('=slug/threads')->where('groupslug',$slug)->the();
            $slug = $groupslug.'-'.($amt+1);
        }
        
        ZXC::up('threads')->set('slug',$slug,'groupslug',$groupslug)->where('tid',$tid)->go();
        
        return $slug;
    }
}