<?php

Class Read
{
    static $obj;
    
    public static function __callStatic($func,$args)
    {
        $func = ucfirst($func);
     
        if (!self::$obj)
        {
            self::$obj = new stdClass();
        }
        
        if (!self::$obj->$func)
        {
            require_once "../Read/".$func.'.php';
            $class = 'Read_'.$func;
            self::$obj->$func = new $class($args);
        }
        
        return self::$obj->$func;
    }
}

Class Write
{
    static $obj;
    
    public static function __callStatic($func,$args)
    {
        $func = ucfirst($func);
        
        if (!self::$obj)
        {
            self::$obj = new stdClass();
        }
        
        if (!self::$obj->$func)
        {
            require_once "../Write/".$func.'.php';
            $class = 'Write_'.$func;
            self::$obj->$func = new $class($args);
        }
        
        return self::$obj->$func;
    }
}

Class Engine
{
    static $obj;
    
    public static function __callStatic($func,$args)
    {
        $func = ucwords($func,'_');
        
        if (!self::$obj)
        {
            self::$obj = new stdClass();
        }
        
        if (!self::$obj->$func)
        {
            require_once "../Engine/".$func.'.php';
            $class = 'Engine_'.$func;
            self::$obj->$func = new $class($args);
        }
        
        return self::$obj->$func;
    }
}