<?php

$GLOBALS['color_sequence'] = Array('y','g','c','sa','e','p','r','o','jo');

function set_vars($h2,$fields,$buttons=Array())
{
    $buttons_render = '';

    foreach ($buttons AS $button)
    {
        $buttons_render .= button($button);
    }

    ?>
    <h2><?=$h2?></h2>
    <?=f('admin_vars')?>
    <table class="cp">
        <?php foreach ($fields as $key => $val) { ?>
            <tr>
              <td><?=$val?></td>
              <td><input name="<?=$key?>" value="<?=get_var($key)?>" /><?=$buttons_render?></td>
            </tr>
        <?php } ?>
    </table>
    <?=uf()?>
    <?php
}

function enable_var($var)
{
    ?>
    <h2>Enable/Disable</h2>
    <?=f('admin_vars')?>
    <?php if (!get_var($var)) {
        $name = 'Enable';
        $status = '<span style="color: #faa;">DISABLED</span>';
    ?>
    <input type="hidden" name="<?=$var?>" value="1" />
    <?php } else {
        $name = 'Disable';
        $status = '<span style="color: #afa;">ENABLED</span>';
    ?>
    <input type="hidden" name="<?=$var?>" value="0" />
    <?php } ?>

    <table class="cp">
    <tr><td>Status</td>
    <td><?=$status?></td>
    </tr>
    </table>
    <?=uf($name)?>
    <?php
}

function checkbox($name,$field,$value)
{
    $sel = '';
    $chek = '';
    if ($value)
    {
        $sel = 'labelsel';
        $chek = 'checked="checked"';
    }

    $html = '<label class="'.$sel.'">';
    $html .= '<input type="checkbox" '.$chek.' name="'.$field.'" />';
    $html .= $name;
    $html .= '</label>';
    return $html;
}

function get_setting($name)
{
    $data = my('settings');
    if (!$data) { return false; }
    return $data[$name];
}

function installed($slug)
{
    if ($GLOBALS['my']['plugins'][$slug]) { return true; }
}

function ic($name,$margin=0)
{
    if ($margin) { $style = 'margin-right: '.$margin.'px;'; }
    return '<i class="material-icons mat-text" style="'.$style.'">'.$name.'</i>';
}

function unsafe($str)
{
    $str = str_replace('&gt;','>',$str);
    $str = str_replace('&lt;','<',$str);
    return $str;
}

function wdie()
{
    if (!iam('soft_white')) { return; }
    die;
}


function get_coin_data($seed,$offset)
{
    $interval = 60*5;
    $clock = time()-$offset;
    $clock /= $interval;

    $seed = intval($seed);

    srand($seed+$clock+7273);

    // Just to make this algorithm harder to figure out
    $s = rand(5,10);
    for ($i = 0; $i < $s; $i++)
    {
        $r = rand(1,100);
    }

    // Makes things a little trickier
    $rows = rand(7,9);
    $cols = $rows;

    $chance = 10;
    $locs = Array();
    for ($x = 0; $x < $rows; $x++)
    {
        for ($y = 0; $y < $cols; $y++)
        {
            if (rand(1,100) >= $chance)
            {
                continue;
            }
            $locs[$x][$y] = true;
        }
    }

    $css = Array();

    srand();

    $amt = rand(5,9);
    $real = Array();
    for ($i = 0; $i < $amt; $i++)
    {
        $hash = genhash(rand(6,10),true);
        $real[] = $hash;
        if (rand(1,2) == 1)
        {
            $css[$hash] = spacer('display').':'.ds().'none;'.ds();
        }
        else
        {
            $css[$hash] = 'display:'.ds().spacer('none').';'.ds();
        }
    }

    $amt = rand(5,9);
    $fake = Array();
    for ($i = 0; $i < $amt; $i++)
    {
        $hash = genhash(rand(6,10),true);
        $fake[] = $hash;
        $css[$hash] = 'display:'.ds().'none;';
    }

    shuffle_assoc($css);

    return Array(
        'rows' => $rows,
        'cols' => $cols,
        'locs' => $locs,
        'real' => $real,
        'fake' => $fake,
        'css' => $css
    );
}


function spacer($str)
{
    $index = rand(1,strlen($str)-2);
    $str = substr($str,0,$index).' '.substr($str,$index);
    return $str;
}

function ds()
{
    $amt = rand(0,3);
    $str = '';
    for ($i = 0; $i < $amt; $i++)
    {
        $str .= ' ';
    }
    return $str;
}


function get_var($name)
{
    return Read::vars()->by_name($name);
}

function sidepage() {
    $GLOBALS['dont_save_page'] = true;
}

function shuffle_assoc(&$array) {
        $keys = array_keys($array);

        shuffle($keys);

        foreach($keys as $key) {
            $new[$key] = $array[$key];
        }

        $array = $new;

        return true;
    }

function button($obj) {

    $attr = '';
    foreach ($obj as $key => $val)
    {
        if ($key == 'name') { $key = 'value'; }
        $attr .= ' '.$key.'="'.$val.'"';
    }

    return '<input type="button" '.$attr.' />';
}

function genhash($len,$no_num=false)
{
    $of = 'abcdefghijklmnopqrstuvwxyz';
    if (!$no_num) { $of .= '1234567890'; }

    for ($i = 0; $i < $len; $i++)
    {
        $hash .= substr($of,mt_rand(0,strlen($of)),1);
    }
    return $hash;
}

function parse($str)
{
    return Engine::parser()->parse($str);
}

function safe($str)
{
    return str_replace('>','&gt;',str_replace('<','&lt;',$str));
}

function last_page()
{
    redir_to($_SESSION['last_page']);
}

function iam($var)
{
    if (my('is_'.$var)) { return true; }
}

function page($var,$value='')
{
    if (!$value)
    {
        return $GLOBALS['this_page'][$var];
    }
    else
    {
        $GLOBALS['this_page'][$var] = $value;
    }
}


function my($var,$value='',$set_js=false)
{
    if (!$value)
    {
        $val = $GLOBALS['my'][$var];
        $val = safe($val);
        return $val;
    }
    else
    {
        $GLOBALS['my'][$var] = $value;
        if ($set_js)
        {
            Engine::view()->set_js('my_'.$var,$value);
        }
    }
}

function f($mode='')
{
    echo '<form action="" method="POST"><input type="hidden" name="__mode" value="'.$mode.'" />';
}

function uf($val=' Submit ')
{
    echo '<input type="submit" value=" '.$val.' " /></form>';
}

function d($backticks=false)
{
    if (!iam('soft_white')) { return; }
    ZXC::CONF('debug_all',true);
    if ($backticks)
    {
        ZXC::CONF('debug_backticks',true);
    }
}

function ddie($backticks=false)
{
    d($backticks);
    die;
}

function ud()
{
    ZXC::CONF('debug_all',false);
}

function flow()
{
    //if (!iam('soft_white')) { return; }
    $args = func_get_args();
    $i = 1;
    $imax = count($args);
    echo '<pre>';
    foreach($args AS $arg)
    {
        if (is_array($arg) || is_object($arg))
        {
            print_r($arg);
        }
        else
        {
            echo $arg;
        }

        if ($i != $imax)
        {
            echo ' -- ';
        }
        $i++;
    }
    echo '</pre>';
}

function print_x($x) { echo '<pre>'; print_r($x); echo '</pre>'; }

// --

function redir_to($url)
{
    ?><script type="text/JavaScript">window.location.href = '<?=$url?>';</script><?php
    die;
}

function has($haystack,$needle,$i=false)
{
    // if the needle is an array
    if (is_array($needle))
    {
        foreach ($needle?:Array() AS $unit)
        {
            if (has($haystack,$unit,$i))
            {
                return true;
            }
        }
        return false;
    }

    // if the haystack is an array
    if (is_array($haystack))
    {
        return in_array($needle,$haystack);
    }

    // if the haystack is a string
    else
    {
        // case-insensitivity
        if ($i)
        {
            if (stripos($haystack,$needle) !== false)
            {
                return true;
            }
        }
        // case-sensitive (default)
        else
        {
            if (strpos($haystack,$needle) !== false)
            {
                return true;
            }
        }
    }
}

function slug($var,$space='_')
{
    $var = strtolower(str_replace(' ',$space,$var));
    $var = preg_replace("/[^A-Za-z0-9".$space."]/", '', $var);
    return $var;
}

function deslug($var)
{
    return ucwords(str_replace(Array('_','-'),' ',$var));
}

function pick($arr)
{
    $key = array_rand($arr);
    return $arr[$key];
}

function pair($arr,$id,$name='')
{
    if (!$arr) { return Array(); }
    $new_arr = Array();
    foreach ($arr?:Array() AS $row)
    {
        $row['id'] = $row[$id];
        $new_arr[$row[$id]] = $row;
        // For the CP's select functionality
        if ($name)
        {
            $new_arr[$row[$id]]['name'] = $row[$name];
        }
    }
    return $new_arr;
}

function map_deep( $value, $callback ) {
        if ( is_array( $value ) ) {
                foreach ( $value as $index => $item ) {
                        $value[ $index ] = map_deep( $item, $callback );
                }
        } elseif ( is_object( $value ) ) {
                $object_vars = get_object_vars( $value );
                foreach ( $object_vars as $property_name => $property_value ) {
                        $value->$property_name = map_deep( $property_value, $callback );
                }
        } else {
                $value = call_user_func( $callback, $value );
        }

        return $value;
}

function stripslashes_from_strings_only( $value ) {
        return is_string( $value ) ? stripslashes( $value ) : $value;
}

function deepslash( $value ) {
        return map_deep( $value, 'stripslashes_from_strings_only' );
}

function conf($message)
{
    echo '<div class="conf">'.$message.'</div>';
}

function fill_select($name,$options,$value='',$blank=false,$class='',$style='',$attrs=Array())
{
    if (!$options) { $options = Array(); }
    if ($blank)
    {
         $blank_opt = Array('' => '');
         if (is_array($blank)) { $blank_opt = Array('' => '--- '.$blank[0].' ---'); }
         $options = $blank_opt + $options;
    }

    foreach ($attrs?:Array() AS $key => $val)
    {
        $attml = $key.'="'.$val.'" ';
    }

    $html .= '<select name="'.$name.'" class="'.$class.'" style="'.$style.'" '.$attml.'>';

    foreach ($options?:Array() AS $key => $val)
    {
        if (is_array($val)) { $val = $val['name']; }
        $select = '';
        if ($value == $key) { $select = 'selected="selected"'; }
        $html .= '<option value="'.$key.'" '.$select.'>'.$val.'</option>';
    }
    $html .= '</select>';
    return $html;
}

function dago($dateline,$editline=0)
{

// Run date ago function for replies

$now = time();

if ($editline != 0)
{
$pdate = $editline;
$dmode = 'Edited';
$which = $editline;
}
else
{
$dmode = 'Posted';
$which = $dateline;
}

$ago = $now-$which;

$sec = $ago;

$min = (int) $ago / 60;
if ($min < 1)
{
$rshow = 'sec';
$done = 1;
}

$hr = (int) $min / 60;
if ($hr < 1 && $done != 1)
{
$rshow = 'min';
$done = 1;
}

$day = (int) $hr / 24;
if ($day < 1 && $done != 1)
{
$rshow = 'hr';
$done = 1;
}

$week = (int) $day / 7;
if ($week < 1 && $done != 1)
{
$rshow = 'day';
$done = 1;
}

$month = (int) $week / 4;
if ($month < 1)
{

if ($done != 1)
{
$rshow = 'week';
$done = 1;
}

}

$year = (int) $month / 12;

if ($year < 1)
{
if ($done != 1)
{
$rshow = 'month';
$done = 1;
}
}
else
{

if ($done != 1)
{
$rshow = 'year';
}

}

// Format properly

$sec = intval($sec);
$min = intval($min);
$hr = intval($hr);
$day = intval($day);
$week = intval($week);
$month = intval($month);
$year = intval($year);
$done = 0;

$plu = 's';

if ($sec == 1 || $min == 1 || $hr == 1 || $day == 1 || $week == 1 || $month == 1 || $year == 1)
{
$plu = '';
}

// Create message
switch($rshow)
{

case 'sec':
$rshow = '<i>('.$dmode.' '.$sec.' Second'.$plu.' ago)</i>';
break;

case 'min':
$rshow = '<i>('.$dmode.' '.$min.' Minute'.$plu.' ago)</i>';
break;

case 'hr':
$rshow = '<i>('.$dmode.' '.$hr.' Hour'.$plu.' ago)</i>';
break;

case 'day':
$rshow = '<i>('.$dmode.' '.$day.' Day'.$plu.' ago)</i>';
break;

case 'week':
$rshow = '<i>('.$dmode.' '.$week.' Week'.$plu.' ago)</i>';
break;

case 'month':
$rshow = '<i>('.$dmode.' '.$month.' Month'.$plu.' ago)</i>';
break;

case 'year':
$rshow = '<i>('.$dmode.' Over '.$year.' Year'.$plu.' ago)</i>';
break;
}

return '<span class="dago" time="'.$dateline.'">'.$rshow.'</span>';

}

// Obviously a hack
function dinpago($message)
{
    $message = dago($message);
    $message = str_replace(Array('(',')','Posted','Edited'),'',$message);
    return $message;
}

function deslug_all($arr)
{
    $data = Array();
    foreach ($arr as $unit)
    {
        $data[$unit] = deslug($unit);
    }
    return $data;
}
