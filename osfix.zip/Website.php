<?php
Class Website
{
    public function __construct()
    {
        //if ($_SERVER['REMOTE_ADDR'] != '24.99.114.187') { echo 'Temporary shutdown Again: ~20 minutes'; die; }
        require "../Core/ZXC.php";
        require "../Core/boot.php";
        require "../Core/functions.php";

        $GLOBALS['branchid'] = 1;

        my('ip',$_SERVER['REMOTE_ADDR']);

        /*
        if (my('ip') == '24.99.114.187')
        {
            my('ip','45.24.12.125');
        }*/

        my('host',gethostbyaddr(my('ip')));

        my('sessid',$_COOKIE['sessid']);

        $db_user='os';
        $db_pass= 'LhZAvQy5Xs46eLc8';

        ZXC::INIT('localhost',$db_user, $db_pass, 'os','main');

        Engine::f31()->init();

        ZXC::$parser['field']['~'] = 'LENGTH($)';

        if (ZXC::sel('uid/whitelist')->where('ip',my('ip'))->the())
        {
            my('is_soft_white',true);
        }

        Engine::events()->render();

        // Authenticate
        Engine::auth()->get_session();

        ZXC::del('bans')->where('end_time<',time())->go();
        // Handle kicks and bans.

        if (Read::kicks()->am_kicked())
        {
            $this->hard_error('You have been kicked from the site for an hour. Check back later.');
        }

        if (Read::permabans()->am_banned())
        {
            $this->hard_error('You have been banned. This is likely not permanent.');
        }

        // Whitelist management

        ZXC::del('whitelist')->where('dateline<=',time()-(60*60*24))->go();

        $whid = ZXC::sel('whid/whitelist')->where('uid',my('uid'),'ip',my('ip'))->the();

        if ($whid && iam('admin'))
        {
            Engine::auth()->user_settings[] = 'debug_mode';
            my('is_white',true);
            my('whid',$whid);
        }




        if (!iam('white') && get_var('the_nuclear_option'))
        {
            $this->hard_error('The entire site is locked down temporarily.');
        }

        // Plugins and settings

        if (my('uid'))
        {
            my('plugins',Read::plugins()->get_installed(my('uid')));
            my('settings',Read::users()->settings_by_uid(my('uid')));
            if (iam('white') && get_setting('debug_mode')) { d(); };
        }

        // Navs

        Engine::nav()->uptop();
    }

    public function log_user()
    {
        $req = $_SERVER['REQUEST_URI'];
        $host = gethostbyaddr(my('ip'));

        if (ZXC::sel('ip/bots')->where('ip',my('ip'))->the())
        {
            $bot = 1;
        }
        else if ($req == '/robots.txt')
        {
            ZXC::ins('bots')->set('ip',my('ip'),'host',$host)->go();
            $bot = 1;
        }

        /*
        if (has($req, '/ajax') && has($req,'/block_thread'))
        {
            echo 'https://www.youtube.com/watch?v=ItZloH0XLHc'; die;
        }*/

        if (has($req,'?qaz') || my('ip') == '194.59.248.202' || has($host,'static.quadranet.com') || has(json_encode($_POST),'<script')) {
                ZXC::ins('log_nopower')->set(
                'ip',my('ip'),
                'uid',my('uid'),
                'dateline',time(),
                'request',$req,
                'post',json_encode($_POST),
                'sid',my('sessid'),
                'whid',my('whid'),
                'host',$host,
                'bot',$bot
            )->go();
         echo 'https://www.youtube.com/watch?v=ItZloH0XLHc'; die;
        }
        else
        {

            ZXC::ins('log')->set(
                'ip',my('ip'),
                'uid',my('uid'),
                'dateline',time(),
                'request',$req,
                'post',json_encode($_POST),
                'sid',my('sessid'),
                'whid',my('whid'),
                'host',$host,
                'bot',$bot
            )->go();
        }

        /*
        if ($req != '/login' && $req != '/register' && !my('uid'))
        {
            redir_to('/login');
            die;
        }*/


        if (!iam('invisible'))
        {
            ZXC::alt('activity')->set('page',$req,'dateline',time(),'uid',my('uid'))->key('ip',my('ip'))->go();
        }
    }

    public function route()
    {
        Engine::view()->init_scripts();

        $route = Engine::routes()->get();

        $func = 'route_'.$route['type'];

        if (!method_exists(Engine::routes(),$func) && !file_exists('../views/'.$route['type'].'.php'))
        {
            redir_to('/');
        }
        Engine::routes()->$func($route['id'],$route['index']);

        // Account Bans
        if (my('uid'))
        {
            if (Read::users()->is_banned(my('uid')))
            {
                $this->hard_error('Your account has been banned. You must <a href="/logout">logout</a> to view the site.');
            }
        }

        Engine::view()->render($route);
    }

    public function post()
    {
        if ($_POST['ajax']) { return; }

        $post = deepslash($_POST);
        $func = $post['__mode'];

        if (!method_exists(Engine::submit(),$func))
        {
            redir_to('/');
        }

        $action = Engine::submit()->$func($_POST);
        $func = 'action_'.$action['action'];
        $this->$func($action['var1']);
    }

    // --

    private function error($message)
    {
        $GLOBALS['page_error'] = $message;
        Engine::view()->render();
        die;
    }

    private function hard_error($message)
    {
        require "views/hard_error.php";
        die;
    }

    private function action_last_page()
    {
        last_page();
    }

    private function action_redirect($to)
    {
        redir_to($to);
    }

    private function action_conf($arr)
    {
        $html = '<ul class="conf">';
        foreach ($arr as $message)
        {
            $html .= '<li>'.$message.'</li>';
        }
        $html .= '</ul>';

        echo $html;
    }

    // TODO: Should be reintegrated with $globals['page_error'] when you get a minute
    private function action_error($message)
    {
        echo '<div class="error">Error: '.$message.'</div>';
    }

    private function action_page_error($message)
    {
        $GLOBALS['page_error'] = $message;
    }

    private function action_page_conf($message)
    {
        $GLOBALS['page_conf'] = $message;
    }

    private function action_none() { }
}
