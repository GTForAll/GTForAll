<?php
Class Read_Vars
{
        private function vars()
        {
            return ZXC::sel('name,value,cat/vars');
        }
        
    public function by_name($name)
    {
        $row = $this->vars()->where('name',$name)->row();
        return $row['value'];
    }
    
    public function by_cat($cat)
    {
        $vars = $this->vars()->where('cat',$cat)->sort('name++')->go();
        $data = Array();
        foreach ($vars as $var)   
        {
            $data[$var['name']] = $var['value'];
        }
        return $data;
    }
}