<?php
Class Read_Posts
{
    public function count_by_fids($fids)
    {
        return ZXC::sel('fid,=pid|amt/posts')->sort('#fid')->iter('fid',$fids)->go();
    }

    public function count_replies($tid)
    {
        $amt = ZXC::sel('=pid/posts')->where('tid',$tid)->the();
        $amt--;
        return $amt;
    }

        private function post()
        {
            $obj = ZXC::sel('pid,tid,fid,user,dateline,message,interaction,ip,tag_reason,tag_nameid,editline,branchid,unblockable,~message|length,mature/posts');
            if (!my('sban_white'))
            {
                $obj->where('1sban',0);
            }
            return $obj;
        }

    public function by_pid($pid)
    {
        return $this->post()->where('pid',$pid)->row();
    }

    public function OP($tid) {
        return $this->post()->where('tid',$tid)->sort('dateline++')->lim(1)->row();
    }

    public function replies($tid) {
        $arr = $this->post()->where('tid',$tid);

        if (!iam('mod'))
        {
            $arr->where('tag_nameid','');
        }

        $arr = $arr->sort('dateline++')->go();
        array_shift($arr);
        return $arr;
    }

    public function count_from($tid,$from)
    {
        return ZXC::sel('=pid/posts')->where('tid',$tid,'pid<=',$from)->the();
    }

}
