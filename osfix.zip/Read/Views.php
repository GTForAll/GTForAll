<?php
Class Read_Views
{
        private function thread()
        {
            return ZXC::sel('tid,uid,dateline,pid,read_pid/thread_views');
        }
    
    public function get_read_tid($uid,$tid)
    {
        $row = $this->thread()->where('uid',$uid,'tid',$tid)->row();
        return $row['read_pid'];
    }
}