<?php
Class Read_Bans
{

  public function ban()
  {
    return ZXC::sel('1banid,1fid,1uid,1type,1value,1reason,1start_time,1end_time,1ban_user,2username/bans<uid>users');
  }


  public function by_fid($fid)
  {
    return $this->ban()->where('fid',$fid)->go();
  }

  public function by_banid($banid)
  {
    return $this->ban()->where('banid',$banid)->row();
  }

}
