<?php
Class Read_Blocks
{
        private function block() {
            return ZXC::sel('blockid,uid,user,tid,type/blocks');
        }
    
    public function by_uid($uid) {
        if (!$uid) { return Array(); }
        $blocks =  $this->block()->where('uid',$uid)->go();
        $arr = Array();
        // TODO: Not the best way to do this, but w/e, don't feel like rewriting everything now.
        foreach ($blocks as $block)
        {
            if ($block['user'])
            {
                $arr[$block['user']] = true;
            }
            else if ($block['tid'])
            {
                $arr['thread_'.$block['tid']] = true;
            }
        }
        return $arr;
    }
}