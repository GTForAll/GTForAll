<?php
Class Read_Permabans
{
        private function ban()
        {
            return ZXC::sel('1banid,1ip,1uid,1dateline,2username/permabans<uid>users');
        }
        
    public function am_banned()
    {
        $row = $this->ban()->where('ip',my('ip'))->row();
        if ($row['banid']) { return true; }
        return false;
    }
    
    public function get_all()
    {
        return $this->ban()->sort('1dateline--')->go();
    }
    
}