<?php
Class Read_Forums
{
        private function forum()
        {
            return ZXC::sel('fid,slug,name,disclaimer,linkname,on_ql,description/forums');
        }

    public function on_ql()
    {
        return $this->forum()->where('on_ql',1)->go();
    }

    public function by_slug($slug)
    {
        return $this->forum()->where('slug',$slug)->row();
    }

    public function by_fid($fid)
    {
        return $this->forum()->where('fid',$fid)->row();
    }

        private function mods()
        {
            return ZXC::sel('1fid,1uid,2username/forum_mods<uid>users');
        }

    public function mods_by_fid($fid)
    {
        return $this->mods()->where('fid',$fid)->go();
    }

    public function mods_by_uids($uids)
    {
      // TODO: Heavily kludged
      return $this->mods()->iter('uid',$uids)->where('fid',-1)->go();
    }
}
