<?php
Class Read_Surveys
{
        private function survey()
        {
            return ZXC::sel('survid,tid/surveys');
        }
        
    public function by_tid($tid)
    {
        return $this->survey()->where('tid',$tid)->row();
    }
        
        // ---
        
        private function question()
        {
            return ZXC::sel('quid,survid,name,type/survey_questions');
        }
        
    public function questions_by_survid($survid)
    {
        return $this->question()->where('survid',$survid)->go();
    }
    
    public function question_by_quid($quid)
    {
        return $this->question()->where('quid',$quid)->row();
    }
        
        // ---
        
        private function answer()
        {
            return ZXC::sel('answerid,quid,value/survey_answers');
        }
        
    public function answers_by_survid($survid)
    {
        return $this->answer()->whin('quid',ZXC::sel('quid/survey_questions')->where('survid',$survid))->go();
    }
    
    public function get_answer_by_answerid($answerid)
    {
        $answer = $this->answer()->where('answerid',$answerid)->row();
        return $answer['value'];    
    }
    
        private function response()
        {
            return ZXC::sel('1survid,1user,1quid,1answer,1text_answer,2type|question_type,3value|answer_value/survey_responses<quid>survey_questions<1answer=3answerid<survey_answers');
        }
        
    public function responses_by_user($user)
    {
        if (!$user) { return; }
        $responses = $this->response()->where('user',$user)->go();
        $arr = Array();
        foreach ($responses as $response)
        {
            $response['canon'] = $response['answer'];
            
            if (($response['question_type'] == 'poll' || $response['question_type'] == 'free_poll') && !$response['answer'])
            {
                $response['answer'] = 'custom';
            }
            
            $arr[$response['quid']] = $response;
        }
        return $arr;
    }
    
    public function survey_responses($survid)
    {
        $responses = $this->response()->where('1survid',$survid)->go();
        $arr = Array();
        foreach ($responses as $response)
        {
            $answer = ( $response['answer_value'] ?: $response['text_answer'] ) ?: $response['answer'];
            $arr[$response['quid']][$answer][] = $response['user'];
        }
        return $arr;
    }
}
