<?php
Class Read_Signed
{
        private function sign()
        {
            return ZXC::sel('type,value,fid/signed');
        }

    public function by_uid($fid,$uid)
    {
        return $this->sign()->where('fid',$fid,'type','uid','value',$uid)->row();
    }

    public function by_ip($fid,$ip)
    {
        return $this->sign()->where('fid',$fid,'type','ip','value',$ip)->row();
    }

    public function mine()
    {
      $data = ZXC::sel('fid/signed')->where('type','ip','value',my('ip'))->col();
      if (my('uid'))
      {
        $extra_data = ZXC::sel('fid/signed')->where('type','uid','value',my('uid'))->col();
        foreach ($extra_data?:Array() as $row)
        {
          $data[] = $row;
        }
      }
      return $data;
    }
}
