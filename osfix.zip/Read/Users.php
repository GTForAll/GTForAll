<?php
Class Read_Users
{
        public function user() {
            return ZXC::sel('1uid,1branchid,1username,1hash,1email,1is_mod,1is_admin,1banned,1invisible,2nameid,2username|primary_username/users<1primary_nameid=2nameid>names');    
        }
        
    public function by_username($user) 
    {
        return $this->user()->where('1username',$user)->row();
    }
    
    public function by_uid($uid)
    {
        return $this->user()->where('1uid',$uid)->row();
    }
    
    public function get_branchid($uid)
    {
        $row = $this->by_uid($uid);
        return $row['branchid'];
    }
    
    public function is_banned($uid)
    {
        $user = $this->by_uid($uid);
        if ($user['banned']) { return true; }
        return false;
    }
    
        private function name()
        {
            return ZXC::sel('nameid,username,password,claimed/names');
        }
    
    public function name_by_username($username)
    {
        return $this->name()->where('username',$username)->row();
    }
    
    public function name_by_nameid($nameid)
    {
        return $this->name()->where('nameid',$nameid)->row();
    }
    
    // ---
    
    public function get_login_attempts($uid,$ip)
    {
        $time = time()-(60*15);
        return ZXC::sel('=uid/login_attempts')->where('uid',$uid,'ip',$ip,'dateline>=',$time)->the();
    }
    
    // ----
    
        private function act()
        {
            return ZXC::sel('1ip,1dateline,1page,1uid,2user|ip_user,3username|account_name,4username|primary_user,5ip|is_spider/activity<ip<ips<uid<users<3primary_nameid=4nameid<names<1ip=5ip<bots');
        }
        
    public function recent_ips()
    {
        $mins = 60;
        return $this->act()->where('1dateline>=',time()-($mins*60))->sort('#1ip,dateline--')->go();
    }
    
        private function setting()
        {
            return ZXC::sel('uid,name,value/user_data');
        }
        
    public function settings_by_uid($uid)
    {
        $rows = $this->setting()->where('uid',$uid)->go();
        $arr = Array();
        foreach ($rows as $row)
        {
            $arr[$row['name']] = $row['value'];
        }
        return $arr;
    }
}