<?php
Class Read_Threads
{
        private function thread()
        {
            $obj = ZXC::sel('1tid,1fid,1quirk,1title,1user,1firstpost,1lastposter,1dateline,1replies,1sticky,1cement,1locked,1ip,1lastpid,1slug,1groupslug,1icon,1link_color'.
            ',1dupeslug,1branchid,1mature|thread_mature,2name|forum_name,3dateline|post_dateline,~3message|last_length,4tag_reason,4tag_nameid/threads<fid<forums<1lastpid=3pid>posts|last_post'.
            '<1firstpost=4pid>posts|first_post');
            if (!my('sban_white'))
            {
                $obj->where('4sban',0);
            }
            return $obj;
        }

    public function common()
    {
        $ZXC = $this->thread();

        if (!iam('mod'))
        {
            $ZXC->where('4tag_nameid','');
        }

        return $ZXC;
    }

    public function by_fid_and_page($fid,$page)
    {
        return $this->common()->where('1fid',$fid)->page($page,20)->sort('sticky--,lastpid--')->go();
    }

    public function cemented()
    {
      return $this->common()->where('cement',1)->go();
    }

    public function feed($page)
    {
        $ZXC = $this->common()->where('1fid!=',186)->page($page,20);

        if (!iam('mod'))
        {
            $ZXC->where('1fid!=',7);
        }

        if (!iam('admin'))
        {
            $ZXC->where('1fid!=',171);
        }

        $ZXC->where('1fid!=',277);

        // disclaimer system stuff (pretty straight import here)
        $disc = ZXC::sel('fid/forums')->where('disclaimer',1)->col();
        $signed = Read::signed()->mine();

        foreach ($disc?:Array() AS $for)
        {
            if (!has($signed,$for))
            {
                $ZXC->where('1fid!=',$for);
            }
        }

        return $ZXC;
    }

    public function feed_hottest($page)
    {
        return $this->feed($page)->sort('1lastpid--')->go();
    }

    public function feed_newest($page)
    {
        return $this->feed($page)->sort('1dateline--')->go();
    }

    public function feed_mine($page)
    {
        if (!my('user')) { redir_to('/login'); }
        return $this->feed($page)->where('1user',my('user'))->sort('1lastpid--')->go();
    }

    // ----

    public function by_slug($slug)
    {
        return $this->thread()->where('1slug',$slug)->row();
    }

    public function by_tid($tid)
    {
        return $this->thread()->where('1tid',$tid)->row();
    }

    // --

    public function get_fid($tid)
    {
        $thread = $this->thread()->where('1tid',$tid)->row();
        return $thread['fid'];
    }

    // -----

    public function most_recent_by_fids($fids)
    {
        // TODO: Have forgotten how to do having() clauses without slowing things down, so I'll do this for now since the list is
        // so small.
        $tids = Array();
        foreach ($fids as $fid)
        {
            $tids[] = ZXC::sel('tid/posts')->where('pid',ZXC::sel('>lastpid/threads')->where('fid',$fid))->the();
        }
        return $this->thread()->iter('1tid',$tids)->sort('lastpid--')->go();
    }

    public function count_by_fids($fids)
    {
        return ZXC::sel('fid,=tid|amt/threads')->sort('#fid')->iter('fid',$fids)->go();
    }

}
