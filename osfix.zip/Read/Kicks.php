<?php
Class Read_Kicks
{
        private function kick()
        {
            return ZXC::sel('kickid,uid,ip,dateline/kicks');
        }
        
        
    public function am_kicked()
    {
        $kick = $this->kick()->where('ip',my('ip'),'dateline>=',time()-(60*60))->row();
        if ($kick['kickid']) { return true; }
        return false;
    }
}