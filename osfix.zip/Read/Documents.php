<?php
Class Read_Documents
{
    private function doc()
    {
        return ZXC::sel('docid,fid,title,message/documents');
    }

    public function by_docid($docid)
    {
        return $this->doc()->where('docid',$docid)->row();
    }

    public function by_fid($fid)
    {
        return $this->doc()->where('fid',$fid)->go();
    }
}
