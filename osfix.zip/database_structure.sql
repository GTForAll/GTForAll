-- MySQL dump 10.13  Distrib 5.7.33, for Linux (x86_64)
--
-- Host: localhost    Database: os
-- ------------------------------------------------------
-- Server version	5.7.33-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity`
--

DROP TABLE IF EXISTS `activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity` (
  `ip` varchar(20) NOT NULL,
  `dateline` int(20) NOT NULL,
  `page` text NOT NULL,
  `uid` int(10) NOT NULL,
  PRIMARY KEY (`ip`),
  KEY `dateline` (`dateline`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity`
--

LOCK TABLES `activity` WRITE;
/*!40000 ALTER TABLE `activity` DISABLE KEYS */;
/*!40000 ALTER TABLE `activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `alerts`
--

DROP TABLE IF EXISTS `alerts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alerts` (
  `alertid` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `dateline` int(20) NOT NULL,
  `status` enum('new','seen','archived') DEFAULT NULL,
  `message` text,
  `link` text,
  PRIMARY KEY (`alertid`),
  KEY `status` (`status`),
  KEY `dateline` (`dateline`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alerts`
--

LOCK TABLES `alerts` WRITE;
/*!40000 ALTER TABLE `alerts` DISABLE KEYS */;
/*!40000 ALTER TABLE `alerts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `altnames`
--

DROP TABLE IF EXISTS `altnames`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `altnames` (
  `uid` int(10) NOT NULL,
  `nameid` int(10) NOT NULL,
  PRIMARY KEY (`uid`,`nameid`),
  KEY `uid` (`uid`),
  KEY `nameid` (`nameid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `altnames`
--

LOCK TABLES `altnames` WRITE;
/*!40000 ALTER TABLE `altnames` DISABLE KEYS */;
/*!40000 ALTER TABLE `altnames` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `autotagger`
--

DROP TABLE IF EXISTS `autotagger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `autotagger` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `field` enum('user','message','title') DEFAULT NULL,
  `type` enum('is','contains') DEFAULT NULL,
  `value` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `field` (`field`,`type`,`value`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `autotagger`
--

LOCK TABLES `autotagger` WRITE;
/*!40000 ALTER TABLE `autotagger` DISABLE KEYS */;
/*!40000 ALTER TABLE `autotagger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `badslugs`
--

DROP TABLE IF EXISTS `badslugs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `badslugs` (
  `slug` varchar(110) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `badslugs`
--

LOCK TABLES `badslugs` WRITE;
/*!40000 ALTER TABLE `badslugs` DISABLE KEYS */;
/*!40000 ALTER TABLE `badslugs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `badtids`
--

DROP TABLE IF EXISTS `badtids`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `badtids` (
  `tid` int(10) DEFAULT NULL,
  KEY `tid` (`tid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `badtids`
--

LOCK TABLES `badtids` WRITE;
/*!40000 ALTER TABLE `badtids` DISABLE KEYS */;
/*!40000 ALTER TABLE `badtids` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bans`
--

DROP TABLE IF EXISTS `bans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bans` (
  `banid` int(10) NOT NULL AUTO_INCREMENT,
  `fid` int(10) DEFAULT NULL,
  `uid` int(10) DEFAULT NULL,
  `type` enum('ip','user') DEFAULT NULL,
  `value` varchar(50) DEFAULT NULL,
  `reason` text,
  `start_time` int(20) DEFAULT NULL,
  `end_time` int(20) DEFAULT NULL,
  `ban_user` varchar(50) NOT NULL,
  PRIMARY KEY (`banid`),
  UNIQUE KEY `fid` (`fid`,`type`,`value`),
  KEY `uid` (`uid`),
  KEY `type` (`type`),
  KEY `value` (`value`),
  KEY `start_time` (`start_time`),
  KEY `end_time` (`end_time`),
  KEY `fid_2` (`fid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bans`
--

LOCK TABLES `bans` WRITE;
/*!40000 ALTER TABLE `bans` DISABLE KEYS */;
/*!40000 ALTER TABLE `bans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bans_log`
--

DROP TABLE IF EXISTS `bans_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bans_log` (
  `banid` int(10) NOT NULL AUTO_INCREMENT,
  `fid` int(10) DEFAULT NULL,
  `uid` int(10) DEFAULT NULL,
  `type` enum('ip','user') DEFAULT NULL,
  `value` varchar(50) DEFAULT NULL,
  `reason` text,
  `start_time` int(20) DEFAULT NULL,
  `end_time` int(20) DEFAULT NULL,
  `ban_user` varchar(50) NOT NULL,
  PRIMARY KEY (`banid`),
  UNIQUE KEY `fid` (`fid`,`type`,`value`),
  KEY `uid` (`uid`),
  KEY `type` (`type`),
  KEY `value` (`value`),
  KEY `start_time` (`start_time`),
  KEY `end_time` (`end_time`),
  KEY `fid_2` (`fid`),
  KEY `ban_user` (`ban_user`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bans_log`
--

LOCK TABLES `bans_log` WRITE;
/*!40000 ALTER TABLE `bans_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `bans_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blocks`
--

DROP TABLE IF EXISTS `blocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blocks` (
  `blockid` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) DEFAULT NULL,
  `tid` int(10) DEFAULT NULL,
  `user` varchar(50) DEFAULT NULL,
  `time_end` int(20) DEFAULT NULL,
  `type` enum('collapse','hide') NOT NULL DEFAULT 'collapse',
  PRIMARY KEY (`blockid`),
  UNIQUE KEY `uid` (`uid`,`tid`,`user`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blocks`
--

LOCK TABLES `blocks` WRITE;
/*!40000 ALTER TABLE `blocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `blocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bots`
--

DROP TABLE IF EXISTS `bots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bots` (
  `ip` varchar(15) NOT NULL,
  `host` text,
  PRIMARY KEY (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bots`
--

LOCK TABLES `bots` WRITE;
/*!40000 ALTER TABLE `bots` DISABLE KEYS */;
INSERT INTO `bots` VALUES ('100.21.218.158','ec2-100-21-218-158.us-west-2.compute.amazonaws.com'),('103.212.32.97','103.212.32.97'),('104.143.93.157','svc157.mailer.ceburekai.net'),('104.197.255.168','168.255.197.104.bc.googleusercontent.com'),('104.198.67.206','206.67.198.104.bc.googleusercontent.com'),('104.45.194.225','104.45.194.225'),('107.189.13.23','107.189.13.23'),('108.5.183.203','pool-108-5-183-203.nwrknj.fios.verizon.net'),('108.59.8.70','crawl-8u9h1v.mj12bot.com'),('108.59.8.80','CRAWL-Z9KTR3.mj12bot.com'),('109.74.204.123','li151-123.members.linode.com'),('110.249.201.136','110.249.201.136'),('110.249.201.16','110.249.201.16'),('110.249.201.233','110.249.201.233'),('110.249.201.249','110.249.201.249'),('110.249.202.236','110.249.202.236'),('111.225.148.117','bytespider-111-225-148-117.crawl.bytedance.com'),('111.225.149.211','bytespider-111-225-149-211.crawl.bytedance.com'),('111.225.149.62','bytespider-111-225-149-62.crawl.bytedance.com'),('111.225.149.77','bytespider-111-225-149-77.crawl.bytedance.com'),('111.225.149.81','bytespider-111-225-149-81.crawl.bytedance.com'),('114.119.128.102','petalbot-114-119-128-102.petalsearch.com'),('114.119.128.127','petalbot-114-119-128-127.petalsearch.com'),('114.119.128.132','petalbot-114-119-128-132.petalsearch.com'),('114.119.128.154','petalbot-114-119-128-154.petalsearch.com'),('114.119.128.158','petalbot-114-119-128-158.petalsearch.com'),('114.119.128.253','petalbot-114-119-128-253.petalsearch.com'),('114.119.128.35','petalbot-114-119-128-35.petalsearch.com'),('114.119.128.37','petalbot-114-119-128-37.petalsearch.com'),('114.119.128.57','petalbot-114-119-128-57.petalsearch.com'),('114.119.129.128','petalbot-114-119-129-128.petalsearch.com'),('114.119.129.143','petalbot-114-119-129-143.petalsearch.com'),('114.119.129.200','petalbot-114-119-129-200.petalsearch.com'),('114.119.129.218','petalbot-114-119-129-218.petalsearch.com'),('114.119.129.229','ecs-114-119-129-229.compute.hwclouds-dns.com'),('114.119.129.74','petalbot-114-119-129-74.petalsearch.com'),('114.119.129.81','petalbot-114-119-129-81.petalsearch.com'),('114.119.129.92','petalbot-114-119-129-92.petalsearch.com'),('114.119.130.104','petalbot-114-119-130-104.petalsearch.com'),('114.119.130.12','petalbot-114-119-130-12.petalsearch.com'),('114.119.130.13','petalbot-114-119-130-13.petalsearch.com'),('114.119.130.169','petalbot-114-119-130-169.petalsearch.com'),('114.119.130.213','petalbot-114-119-130-213.petalsearch.com'),('114.119.130.217','petalbot-114-119-130-217.petalsearch.com'),('114.119.130.251','petalbot-114-119-130-251.petalsearch.com'),('114.119.130.253','petalbot-114-119-130-253.petalsearch.com'),('114.119.130.27','petalbot-114-119-130-27.petalsearch.com'),('114.119.130.31','petalbot-114-119-130-31.petalsearch.com'),('114.119.130.32','petalbot-114-119-130-32.petalsearch.com'),('114.119.130.54','petalbot-114-119-130-54.petalsearch.com'),('114.119.130.60','petalbot-114-119-130-60.petalsearch.com'),('114.119.130.61','petalbot-114-119-130-61.petalsearch.com'),('114.119.130.96','petalbot-114-119-130-96.petalsearch.com'),('114.119.130.99','petalbot-114-119-130-99.petalsearch.com'),('114.119.131.151','petalbot-114-119-131-151.petalsearch.com'),('114.119.131.181','petalbot-114-119-131-181.petalsearch.com'),('114.119.131.206','petalbot-114-119-131-206.petalsearch.com'),('114.119.131.235','petalbot-114-119-131-235.petalsearch.com'),('114.119.131.90','petalbot-114-119-131-90.petalsearch.com'),('114.119.132.11','petalbot-114-119-132-11.petalsearch.com'),('114.119.132.116','petalbot-114-119-132-116.petalsearch.com'),('114.119.132.18','petalbot-114-119-132-18.petalsearch.com'),('114.119.132.207','petalbot-114-119-132-207.petalsearch.com'),('114.119.132.211','petalbot-114-119-132-211.petalsearch.com'),('114.119.132.28','petalbot-114-119-132-28.petalsearch.com'),('114.119.132.34','petalbot-114-119-132-34.petalsearch.com'),('114.119.132.88','petalbot-114-119-132-88.petalsearch.com'),('114.119.132.89','petalbot-114-119-132-89.petalsearch.com'),('114.119.133.103','petalbot-114-119-133-103.petalsearch.com'),('114.119.133.116','petalbot-114-119-133-116.petalsearch.com'),('114.119.133.12','petalbot-114-119-133-12.petalsearch.com'),('114.119.133.130','petalbot-114-119-133-130.petalsearch.com'),('114.119.133.14','petalbot-114-119-133-14.petalsearch.com'),('114.119.133.142','petalbot-114-119-133-142.petalsearch.com'),('114.119.133.182','petalbot-114-119-133-182.petalsearch.com'),('114.119.133.192','petalbot-114-119-133-192.petalsearch.com'),('114.119.133.211','petalbot-114-119-133-211.petalsearch.com'),('114.119.133.98','petalbot-114-119-133-98.petalsearch.com'),('114.119.134.10','petalbot-114-119-134-10.petalsearch.com'),('114.119.134.107','petalbot-114-119-134-107.petalsearch.com'),('114.119.134.148','petalbot-114-119-134-148.petalsearch.com'),('114.119.134.204','petalbot-114-119-134-204.petalsearch.com'),('114.119.134.216','petalbot-114-119-134-216.petalsearch.com'),('114.119.134.230','petalbot-114-119-134-230.petalsearch.com'),('114.119.134.231','petalbot-114-119-134-231.petalsearch.com'),('114.119.134.48','petalbot-114-119-134-48.petalsearch.com'),('114.119.134.6','petalbot-114-119-134-6.petalsearch.com'),('114.119.135.121','petalbot-114-119-135-121.petalsearch.com'),('114.119.135.136','petalbot-114-119-135-136.petalsearch.com'),('114.119.135.139','petalbot-114-119-135-139.petalsearch.com'),('114.119.135.159','petalbot-114-119-135-159.petalsearch.com'),('114.119.135.174','petalbot-114-119-135-174.petalsearch.com'),('114.119.135.212','petalbot-114-119-135-212.petalsearch.com'),('114.119.135.223','petalbot-114-119-135-223.petalsearch.com'),('114.119.135.237','petalbot-114-119-135-237.petalsearch.com'),('114.119.135.245','petalbot-114-119-135-245.petalsearch.com'),('114.119.135.251','petalbot-114-119-135-251.petalsearch.com'),('114.119.135.32','petalbot-114-119-135-32.petalsearch.com'),('114.119.135.34','petalbot-114-119-135-34.petalsearch.com'),('114.119.135.36','petalbot-114-119-135-36.petalsearch.com'),('114.119.135.37','petalbot-114-119-135-37.petalsearch.com'),('114.119.135.42','petalbot-114-119-135-42.petalsearch.com'),('114.119.135.83','petalbot-114-119-135-83.petalsearch.com'),('114.119.135.96','petalbot-114-119-135-96.petalsearch.com'),('114.119.135.98','petalbot-114-119-135-98.petalsearch.com'),('114.119.136.128','petalbot-114-119-136-128.petalsearch.com'),('114.119.136.141','petalbot-114-119-136-141.petalsearch.com'),('114.119.136.146','petalbot-114-119-136-146.petalsearch.com'),('114.119.136.174','petalbot-114-119-136-174.petalsearch.com'),('114.119.136.175','petalbot-114-119-136-175.petalsearch.com'),('114.119.136.238','petalbot-114-119-136-238.petalsearch.com'),('114.119.136.251','petalbot-114-119-136-251.petalsearch.com'),('114.119.136.254','petalbot-114-119-136-254.petalsearch.com'),('114.119.136.86','petalbot-114-119-136-86.petalsearch.com'),('114.119.136.92','petalbot-114-119-136-92.petalsearch.com'),('114.119.136.99','petalbot-114-119-136-99.petalsearch.com'),('114.119.137.143','petalbot-114-119-137-143.petalsearch.com'),('114.119.137.156','petalbot-114-119-137-156.petalsearch.com'),('114.119.137.195','petalbot-114-119-137-195.petalsearch.com'),('114.119.137.204','petalbot-114-119-137-204.petalsearch.com'),('114.119.137.224','petalbot-114-119-137-224.petalsearch.com'),('114.119.137.237','petalbot-114-119-137-237.petalsearch.com'),('114.119.137.3','petalbot-114-119-137-3.petalsearch.com'),('114.119.137.54','ecs-114-119-137-54.compute.hwclouds-dns.com'),('114.119.137.64','petalbot-114-119-137-64.petalsearch.com'),('114.119.137.68','petalbot-114-119-137-68.petalsearch.com'),('114.119.137.70','petalbot-114-119-137-70.petalsearch.com'),('114.119.138.155','petalbot-114-119-138-155.petalsearch.com'),('114.119.138.172','petalbot-114-119-138-172.petalsearch.com'),('114.119.138.177','petalbot-114-119-138-177.petalsearch.com'),('114.119.138.235','petalbot-114-119-138-235.petalsearch.com'),('114.119.138.239','petalbot-114-119-138-239.petalsearch.com'),('114.119.138.33','petalbot-114-119-138-33.petalsearch.com'),('114.119.138.5','petalbot-114-119-138-5.petalsearch.com'),('114.119.139.201','petalbot-114-119-139-201.petalsearch.com'),('114.119.139.246','petalbot-114-119-139-246.petalsearch.com'),('114.119.139.247','petalbot-114-119-139-247.petalsearch.com'),('114.119.139.59','petalbot-114-119-139-59.petalsearch.com'),('114.119.139.86','petalbot-114-119-139-86.petalsearch.com'),('114.119.139.88','petalbot-114-119-139-88.petalsearch.com'),('114.119.140.122','petalbot-114-119-140-122.petalsearch.com'),('114.119.140.161','petalbot-114-119-140-161.petalsearch.com'),('114.119.140.175','petalbot-114-119-140-175.petalsearch.com'),('114.119.140.196','petalbot-114-119-140-196.petalsearch.com'),('114.119.140.234','petalbot-114-119-140-234.petalsearch.com'),('114.119.140.73','petalbot-114-119-140-73.petalsearch.com'),('114.119.140.85','petalbot-114-119-140-85.petalsearch.com'),('114.119.141.103','petalbot-114-119-141-103.petalsearch.com'),('114.119.141.139','petalbot-114-119-141-139.petalsearch.com'),('114.119.141.186','petalbot-114-119-141-186.petalsearch.com'),('114.119.141.194','petalbot-114-119-141-194.petalsearch.com'),('114.119.141.200','petalbot-114-119-141-200.petalsearch.com'),('114.119.141.232','petalbot-114-119-141-232.petalsearch.com'),('114.119.141.30','petalbot-114-119-141-30.petalsearch.com'),('114.119.141.34','petalbot-114-119-141-34.petalsearch.com'),('114.119.141.79','petalbot-114-119-141-79.petalsearch.com'),('114.119.142.132','petalbot-114-119-142-132.petalsearch.com'),('114.119.142.14','petalbot-114-119-142-14.petalsearch.com'),('114.119.142.188','petalbot-114-119-142-188.petalsearch.com'),('114.119.142.212','petalbot-114-119-142-212.petalsearch.com'),('114.119.142.243','petalbot-114-119-142-243.petalsearch.com'),('114.119.142.84','petalbot-114-119-142-84.petalsearch.com'),('114.119.142.93','petalbot-114-119-142-93.petalsearch.com'),('114.119.143.114','petalbot-114-119-143-114.petalsearch.com'),('114.119.143.119','petalbot-114-119-143-119.petalsearch.com'),('114.119.143.130','petalbot-114-119-143-130.petalsearch.com'),('114.119.143.187','petalbot-114-119-143-187.petalsearch.com'),('114.119.143.233','petalbot-114-119-143-233.petalsearch.com'),('114.119.143.25','petalbot-114-119-143-25.petalsearch.com'),('114.119.143.250','petalbot-114-119-143-250.petalsearch.com'),('114.119.143.5','petalbot-114-119-143-5.petalsearch.com'),('114.119.143.51','petalbot-114-119-143-51.petalsearch.com'),('114.119.143.55','petalbot-114-119-143-55.petalsearch.com'),('114.119.143.75','petalbot-114-119-143-75.petalsearch.com'),('114.119.144.17','petalbot-114-119-144-17.petalsearch.com'),('114.119.144.188','petalbot-114-119-144-188.petalsearch.com'),('114.119.144.202','petalbot-114-119-144-202.petalsearch.com'),('114.119.144.212','petalbot-114-119-144-212.petalsearch.com'),('114.119.144.233','petalbot-114-119-144-233.petalsearch.com'),('114.119.144.36','petalbot-114-119-144-36.petalsearch.com'),('114.119.144.55','petalbot-114-119-144-55.petalsearch.com'),('114.119.144.80','petalbot-114-119-144-80.petalsearch.com'),('114.119.145.115','petalbot-114-119-145-115.petalsearch.com'),('114.119.145.125','petalbot-114-119-145-125.petalsearch.com'),('114.119.145.192','petalbot-114-119-145-192.petalsearch.com'),('114.119.145.205','petalbot-114-119-145-205.petalsearch.com'),('114.119.145.212','petalbot-114-119-145-212.petalsearch.com'),('114.119.145.22','petalbot-114-119-145-22.petalsearch.com'),('114.119.145.3','petalbot-114-119-145-3.petalsearch.com'),('114.119.146.100','petalbot-114-119-146-100.petalsearch.com'),('114.119.146.158','petalbot-114-119-146-158.petalsearch.com'),('114.119.146.179','petalbot-114-119-146-179.petalsearch.com'),('114.119.146.18','petalbot-114-119-146-18.petalsearch.com'),('114.119.146.195','petalbot-114-119-146-195.petalsearch.com'),('114.119.146.215','petalbot-114-119-146-215.petalsearch.com'),('114.119.146.40','petalbot-114-119-146-40.petalsearch.com'),('114.119.147.0','petalbot-114-119-147-0.petalsearch.com'),('114.119.147.129','petalbot-114-119-147-129.petalsearch.com'),('114.119.147.137','petalbot-114-119-147-137.petalsearch.com'),('114.119.147.184','petalbot-114-119-147-184.petalsearch.com'),('114.119.147.209','petalbot-114-119-147-209.petalsearch.com'),('114.119.147.246','petalbot-114-119-147-246.petalsearch.com'),('114.119.147.47','petalbot-114-119-147-47.petalsearch.com'),('114.119.147.75','petalbot-114-119-147-75.petalsearch.com'),('114.119.148.160','petalbot-114-119-148-160.petalsearch.com'),('114.119.148.165','petalbot-114-119-148-165.petalsearch.com'),('114.119.148.197','petalbot-114-119-148-197.petalsearch.com'),('114.119.148.208','petalbot-114-119-148-208.petalsearch.com'),('114.119.148.242','petalbot-114-119-148-242.petalsearch.com'),('114.119.148.33','petalbot-114-119-148-33.petalsearch.com'),('114.119.148.34','petalbot-114-119-148-34.petalsearch.com'),('114.119.148.47','petalbot-114-119-148-47.petalsearch.com'),('114.119.148.64','petalbot-114-119-148-64.petalsearch.com'),('114.119.149.159','petalbot-114-119-149-159.petalsearch.com'),('114.119.149.168','petalbot-114-119-149-168.petalsearch.com'),('114.119.149.205','petalbot-114-119-149-205.petalsearch.com'),('114.119.149.218','petalbot-114-119-149-218.petalsearch.com'),('114.119.149.23','petalbot-114-119-149-23.petalsearch.com'),('114.119.149.232','petalbot-114-119-149-232.petalsearch.com'),('114.119.149.247','petalbot-114-119-149-247.petalsearch.com'),('114.119.150.120','petalbot-114-119-150-120.petalsearch.com'),('114.119.150.15','petalbot-114-119-150-15.petalsearch.com'),('114.119.150.16','petalbot-114-119-150-16.petalsearch.com'),('114.119.150.168','petalbot-114-119-150-168.petalsearch.com'),('114.119.150.173','petalbot-114-119-150-173.petalsearch.com'),('114.119.150.196','petalbot-114-119-150-196.petalsearch.com'),('114.119.150.226','petalbot-114-119-150-226.petalsearch.com'),('114.119.150.32','petalbot-114-119-150-32.petalsearch.com'),('114.119.150.34','petalbot-114-119-150-34.petalsearch.com'),('114.119.150.57','petalbot-114-119-150-57.petalsearch.com'),('114.119.150.86','ecs-114-119-150-86.compute.hwclouds-dns.com'),('114.119.151.0','petalbot-114-119-151-0.petalsearch.com'),('114.119.151.103','petalbot-114-119-151-103.petalsearch.com'),('114.119.151.126','petalbot-114-119-151-126.petalsearch.com'),('114.119.151.170','petalbot-114-119-151-170.petalsearch.com'),('114.119.151.184','petalbot-114-119-151-184.petalsearch.com'),('114.119.151.197','petalbot-114-119-151-197.petalsearch.com'),('114.119.151.208','petalbot-114-119-151-208.petalsearch.com'),('114.119.151.233','petalbot-114-119-151-233.petalsearch.com'),('114.119.151.93','petalbot-114-119-151-93.petalsearch.com'),('114.119.152.12','petalbot-114-119-152-12.petalsearch.com'),('114.119.152.27','petalbot-114-119-152-27.petalsearch.com'),('114.119.153.158','petalbot-114-119-153-158.petalsearch.com'),('114.119.153.49','petalbot-114-119-153-49.petalsearch.com'),('114.119.154.166','petalbot-114-119-154-166.petalsearch.com'),('114.119.154.77','petalbot-114-119-154-77.petalsearch.com'),('114.119.155.180','petalbot-114-119-155-180.petalsearch.com'),('114.119.156.133','petalbot-114-119-156-133.petalsearch.com'),('114.119.159.226','petalbot-114-119-159-226.petalsearch.com'),('118.123.105.67','118.123.105.67'),('118.123.105.68','118.123.105.68'),('123.125.67.159','123.125.67.159'),('125.64.94.138','125.64.94.138'),('125.64.94.140','125.64.94.140'),('125.64.94.144','125.64.94.144'),('125.64.94.214','125.64.94.214'),('13.212.111.160','ec2-13-212-111-160.ap-southeast-1.compute.amazonaws.com'),('13.66.139.1','msnbot-13-66-139-1.search.msn.com'),('130.255.166.120','130.255.166.120'),('130.255.166.26','130.255.166.26'),('130.255.166.69','mail-166-69.rch003.net'),('132.145.11.125','132.145.11.125'),('134.195.89.70','chi03.d.sb'),('135.181.213.220','static.220.213.181.135.clients.your-server.de'),('135.181.79.106','static.106.79.181.135.clients.your-server.de'),('136.243.148.178','static.178.148.243.136.clients.your-server.de'),('136.243.4.209','static.209.4.243.136.clients.your-server.de'),('137.184.42.156','137.184.42.156'),('137.220.131.97','137.220.131.97'),('137.220.233.52','137.220.233.52'),('138.201.194.252','static.252.194.201.138.clients.your-server.de'),('138.246.253.24','planetlab24.gino-research.net.in.tum.de'),('140.238.81.78','140.238.81.78'),('141.8.142.70','141-8-142-70.spider.yandex.com'),('141.8.142.72','141-8-142-72.spider.yandex.com'),('141.94.107.49','141.94.107.49'),('142.132.139.44','static.44.139.132.142.clients.your-server.de'),('142.202.240.66','142.202.240.66'),('142.202.242.162','briggitrin.com'),('142.44.166.135','142.44.166.135'),('142.93.217.59','142.93.217.59'),('144.76.118.82','linux02.r00tbase.de'),('144.76.120.197','linux11.r00tbase.de'),('144.76.137.254','linux10.r00tbase.de'),('144.76.14.153','linux07.r00tbase.de'),('144.76.176.171','linux16.r00tbase.de'),('144.76.186.38','linux12.r00tbase.de'),('144.76.200.68','linux18.r00tbase.de'),('144.76.29.148','static.148.29.76.144.clients.your-server.de'),('144.76.29.149','static.149.29.76.144.clients.your-server.de'),('144.76.3.131','static.131.3.76.144.clients.your-server.de'),('144.76.3.79','static.79.3.76.144.clients.your-server.de'),('144.76.36.146','static.146.36.76.144.clients.your-server.de'),('144.76.38.10','static.10.38.76.144.clients.your-server.de'),('144.76.38.40','static.40.38.76.144.clients.your-server.de'),('144.76.4.41','static.41.4.76.144.clients.your-server.de'),('144.76.40.222','static.222.40.76.144.clients.your-server.de'),('144.76.40.26','static.26.40.76.144.clients.your-server.de'),('144.76.6.230','static.230.6.76.144.clients.your-server.de'),('144.76.60.198','linux17.r00tbase.de'),('144.76.67.250','static.250.67.76.144.clients.your-server.de'),('144.76.7.79','static.79.7.76.144.clients.your-server.de'),('144.76.71.176','static.176.71.76.144.clients.your-server.de'),('144.76.81.229','static.229.81.76.144.clients.your-server.de'),('144.76.91.79','static.79.91.76.144.clients.your-server.de'),('144.76.96.236','linux04.r00tbase.de'),('144.91.125.96','mad05.tiss.xyz'),('144.91.91.164','mad12.tiss.xyz'),('147.182.242.131','147.182.242.131'),('148.251.120.201','linux09.r00tbase.de'),('148.251.195.14','linux13.r00tbase.de'),('148.251.244.137','linux05.r00tbase.de'),('148.251.69.139','linux06.r00tbase.de'),('148.251.8.250','linux14.r00tbase.de'),('148.251.9.145','linux15.r00tbase.de'),('149.202.82.11','ns3017681.ip-149-202-82.eu'),('149.202.86.61','ns3017818.ip-149-202-86.eu'),('152.228.208.156','152.228.208.156'),('152.67.138.180','152.67.138.180'),('154.54.249.18','crawl-dev-4.babbar.eu'),('154.54.249.208','crawl-prodd4-16.babbar.eu'),('154.88.26.232','154.88.26.232'),('157.55.39.115','msnbot-157-55-39-115.search.msn.com'),('157.55.39.130','msnbot-157-55-39-130.search.msn.com'),('157.55.39.132','msnbot-157-55-39-132.search.msn.com'),('157.55.39.148','msnbot-157-55-39-148.search.msn.com'),('157.55.39.200','msnbot-157-55-39-200.search.msn.com'),('157.55.39.216','msnbot-157-55-39-216.search.msn.com'),('157.55.39.62','msnbot-157-55-39-62.search.msn.com'),('157.90.182.23','ninja-crawler94.webmeup.com'),('158.69.124.236','ns521924.ip-158-69-124.net'),('158.69.243.115','ns528817.ip-158-69-243.net'),('158.69.243.138','ns528840.ip-158-69-243.net'),('158.69.243.140','ns528842.ip-158-69-243.net'),('158.69.243.99','ns528801.ip-158-69-243.net'),('158.69.245.214','ns535233.ip-158-69-245.net'),('158.69.252.225','ns546529.ip-158-69-252.net'),('160.116.22.18','visit.keznews.com'),('160.116.22.22','visit.keznews.com'),('161.156.29.33','gateway01.x-force-threat-intelligence.cloud'),('161.97.136.234','mad51.tiss.xyz'),('161.97.157.176','vmi652176.contaboserver.net'),('161.97.92.73','mad63.tiss.xyz'),('162.210.196.100','crawl-vfyrb9.mj12bot.com'),('162.210.196.129','crawl-pm06ty.mj12bot.com'),('162.210.196.130','crawl-mwx5un.mj12bot.com'),('162.210.196.97','crawl-j8n83z.mj12bot.com'),('162.210.196.98','crawl-cpjqn4.mj12bot.com'),('164.68.119.249','mad33.tiss.xyz'),('164.68.121.239','mad45.tiss.xyz'),('164.68.96.117','mad50.tiss.xyz'),('167.114.100.201','ns509853.ip-167-114-100.net'),('167.114.101.65','ns509814.ip-167-114-101.net'),('167.114.101.80','ns509841.ip-167-114-101.net'),('167.114.103.160','ns511172.ip-167-114-103.net'),('167.114.116.25','ns511179.ip-167-114-116.net'),('167.114.116.38','ns511192.ip-167-114-116.net'),('167.114.157.181','ns513244.ip-167-114-157.net'),('167.114.158.215','ns513881.ip-167-114-158.net'),('167.114.158.241','ns513764.ip-167-114-158.net'),('167.114.159.183','ns514058.ip-167-114-159.net'),('167.114.159.99','ns514021.ip-167-114-159.net'),('167.114.173.115','ns514734.ip-167-114-173.net'),('167.114.209.104','ns515774.ip-167-114-209.net'),('167.114.211.237','ns516525.ip-167-114-211.net'),('167.114.64.97','ns508289.ip-167-114-64.net'),('167.86.70.217','mad36.tiss.xyz'),('167.86.71.242','mad35.tiss.xyz'),('167.86.79.150','mad37.tiss.xyz'),('168.119.140.243','static.243.140.119.168.clients.your-server.de'),('168.119.140.246','static.246.140.119.168.clients.your-server.de'),('168.119.140.248','static.248.140.119.168.clients.your-server.de'),('17.121.113.164','17-121-113-164.applebot.apple.com'),('17.121.114.9','17-121-114-9.applebot.apple.com'),('17.121.115.238','17-121-115-238.applebot.apple.com'),('172.104.140.107','172-104-140-107.ip.linodeusercontent.com'),('173.208.130.202','back.sadproperl.net'),('173.208.206.50','vm.se-dns.com'),('173.212.202.122','mad21.tiss.xyz'),('173.212.220.26','mad07.tiss.xyz'),('173.212.220.70','mad61.tiss.xyz'),('173.212.222.108','mad28.tiss.xyz'),('173.212.229.76','mad03.tiss.xyz'),('173.212.241.58','mad30.tiss.xyz'),('173.212.242.224','mad46.tiss.xyz'),('173.212.245.225','mad00.tiss.xyz'),('173.212.246.178','mad16.tiss.xyz'),('173.212.246.91','vmi675575.contaboserver.net'),('173.212.247.190','mad39.tiss.xyz'),('173.249.16.207','mad49.tiss.xyz'),('173.249.2.13','mad04.tiss.xyz'),('173.249.30.147','mad22.tiss.xyz'),('173.249.7.244','mad18.tiss.xyz'),('173.252.83.112','fwdproxy-pnb-112.fbsv.net'),('173.252.87.112','fwdproxy-ftw-112.fbsv.net'),('173.252.87.9','fwdproxy-ftw-009.fbsv.net'),('173.252.95.20','fwdproxy-atn-020.fbsv.net'),('173.252.95.23','fwdproxy-atn-023.fbsv.net'),('173.252.95.25','fwdproxy-atn-025.fbsv.net'),('173.252.95.30','fwdproxy-atn-030.fbsv.net'),('176.123.4.115','parted.myline.org.uk'),('176.31.104.153','ns391652.ip-176-31-104.eu'),('176.31.125.95','ns398269.ip-176-31-125.eu'),('176.74.192.85','176.74.192.85'),('176.9.25.107','static.107.25.9.176.clients.your-server.de'),('176.9.25.75','pot25.webmeup.com'),('178.150.14.250','250.14.150.178.triolan.net'),('178.151.245.174','174.245.151.178.triolan.net'),('178.18.246.128','vmi654818.contaboserver.net'),('178.63.26.114','static.114.26.63.178.clients.your-server.de'),('178.63.34.189','static.189.34.63.178.clients.your-server.de'),('178.63.87.197','static.197.87.63.178.clients.your-server.de'),('18.119.164.237','ec2-18-119-164-237.us-east-2.compute.amazonaws.com'),('18.207.135.216','ec2-18-207-135-216.compute-1.amazonaws.com'),('180.215.192.168','180.215.192.168'),('183.136.225.14','183.136.225.14'),('183.136.225.9','183.136.225.9'),('183.136.226.3','183.136.226.3'),('183.136.226.4','183.136.226.4'),('185.142.236.34','hat.census.shodan.io'),('185.142.236.35','wine.census.shodan.io'),('185.142.236.36','green.census.shodan.io'),('185.142.236.41','185.142.236.41'),('185.142.236.43','blue2.census.shodan.io'),('185.163.109.66','goldfish.census.shodan.io'),('185.165.190.34','red.census.shodan.io'),('185.184.157.102','185.184.157.102'),('185.184.157.90','185.184.157.90'),('185.184.157.91','185.184.157.91'),('185.184.157.94','185.184.157.94'),('185.184.157.95','185.184.157.95'),('185.191.171.1','1.bl.bot.semrush.com'),('185.191.171.10','10.bl.bot.semrush.com'),('185.191.171.11','11.bl.bot.semrush.com'),('185.191.171.12','12.bl.bot.semrush.com'),('185.191.171.13','13.bl.bot.semrush.com'),('185.191.171.14','14.bl.bot.semrush.com'),('185.191.171.15','15.bl.bot.semrush.com'),('185.191.171.16','16.bl.bot.semrush.com'),('185.191.171.17','17.bl.bot.semrush.com'),('185.191.171.18','18.bl.bot.semrush.com'),('185.191.171.19','19.bl.bot.semrush.com'),('185.191.171.2','2.bl.bot.semrush.com'),('185.191.171.20','20.bl.bot.semrush.com'),('185.191.171.21','21.bl.bot.semrush.com'),('185.191.171.22','22.bl.bot.semrush.com'),('185.191.171.23','23.bl.bot.semrush.com'),('185.191.171.24','24.bl.bot.semrush.com'),('185.191.171.25','25.bl.bot.semrush.com'),('185.191.171.26','26.bl.bot.semrush.com'),('185.191.171.3','3.bl.bot.semrush.com'),('185.191.171.33','33.bl.bot.semrush.com'),('185.191.171.34','34.bl.bot.semrush.com'),('185.191.171.35','35.bl.bot.semrush.com'),('185.191.171.36','36.bl.bot.semrush.com'),('185.191.171.37','37.bl.bot.semrush.com'),('185.191.171.38','38.bl.bot.semrush.com'),('185.191.171.39','39.bl.bot.semrush.com'),('185.191.171.4','4.bl.bot.semrush.com'),('185.191.171.40','40.bl.bot.semrush.com'),('185.191.171.41','41.bl.bot.semrush.com'),('185.191.171.42','42.bl.bot.semrush.com'),('185.191.171.43','43.bl.bot.semrush.com'),('185.191.171.44','44.bl.bot.semrush.com'),('185.191.171.45','45.bl.bot.semrush.com'),('185.191.171.5','5.bl.bot.semrush.com'),('185.191.171.6','6.bl.bot.semrush.com'),('185.191.171.7','7.bl.bot.semrush.com'),('185.191.171.8','8.bl.bot.semrush.com'),('185.191.171.9','9.bl.bot.semrush.com'),('185.194.216.150','vmi728049.contaboserver.net'),('185.216.203.239','vmi724524.contaboserver.net'),('185.23.181.24','185.23.181.24'),('185.234.69.215','vmi732346.contaboserver.net'),('185.234.69.220','vmi732347.contaboserver.net'),('185.27.99.127','logname-mail-constructor.rapidmms.com'),('185.27.99.130','back-chkntfs.rapidmms.com'),('185.27.99.141','bullet-enews-enews.rapidmms.com'),('188.165.217.198','ns3014677.ip-188-165-217.eu'),('188.165.227.148','ns371670.ip-188-165-227.eu'),('188.40.75.228','static.228.75.40.188.clients.your-server.de'),('192.151.157.210','192.151.157.210'),('192.36.52.37','192.36.52.37'),('192.36.71.133','192.36.71.133'),('192.71.103.173','192.71.103.173'),('192.71.126.175','192.71.126.175'),('192.71.225.127','192.71.225.127'),('192.71.42.108','192.71.42.108'),('192.99.10.170','ns507894.ip-192-99-10.net'),('192.99.101.79','ns504163.ip-192-99-101.net'),('192.99.13.133','ns510978.ip-192-99-13.net'),('192.99.13.186','ns508679.ip-192-99-13.net'),('192.99.13.228','ns500182.ip-192-99-13.net'),('192.99.13.75','ns514011.ip-192-99-13.net'),('192.99.13.88','ns519001.ip-192-99-13.net'),('192.99.14.135','ns500168.ip-192-99-14.net'),('192.99.15.29','ns570787.ip-192-99-15.net'),('192.99.15.33','ns570722.ip-192-99-15.net'),('192.99.160.200','ns503472.ip-192-99-160.net'),('192.99.161.45','ns5004757.ip-192-99-161.net'),('192.99.36.166','ns500484.ip-192-99-36.net'),('192.99.37.116','ns501998.ip-192-99-37.net'),('192.99.37.138','ns501548.ip-192-99-37.net'),('192.99.4.140','ns573072.ip-192-99-4.net'),('192.99.4.168','ns502968.ip-192-99-4.net'),('192.99.5.225','ns573199.ip-192-99-5.net'),('192.99.5.228','ns573200.ip-192-99-5.net'),('192.99.5.48','ns507858.ip-192-99-5.net'),('192.99.6.138','ns513364.ip-192-99-6.net'),('192.99.6.226','ns501934.ip-192-99-6.net'),('192.99.7.182','ns501933.ip-192-99-7.net'),('192.99.9.25','ns500999.ip-192-99-9.net'),('193.243.189.31','static.193.243.189.31.terrahost.com'),('194.163.170.74','vmi700519.contaboserver.net'),('194.163.191.72','vmi699216.contaboserver.net'),('195.144.21.56','red3.census.shodan.io'),('195.201.199.99','static.99.199.201.195.clients.your-server.de'),('198.20.69.98','census2.shodan.io'),('198.20.70.114','census3.shodan.io'),('198.20.87.98','border.census.shodan.io'),('198.27.66.59','ns5000300.ip-198-27-66.net'),('199.58.86.206','199.58.86.206'),('199.58.86.209','crawl-i7jgxj.mj12bot.com'),('199.58.86.211','crawl-w7b9ix.mj12bot.com'),('199.59.150.181','r-199-59-150-181.twttr.com'),('202.61.253.63','v220210466606148840.hotsrv.de'),('204.12.197.234','modenewly.com'),('206.189.123.235','206.189.123.235'),('207.154.212.145','207.154.212.145'),('207.180.218.247','mad01.tiss.xyz'),('207.180.221.167','mad34.tiss.xyz'),('207.180.224.141','mad09.tiss.xyz'),('207.180.226.173','mad14.tiss.xyz'),('207.180.245.134','mad25.tiss.xyz'),('207.241.231.144','crawl427.us.archive.org'),('207.241.231.145','crawl426.us.archive.org'),('207.241.231.152','crawl409.us.archive.org'),('207.241.231.45','crawl896.us.archive.org'),('207.241.233.139','crawl865.us.archive.org'),('207.241.233.159','crawl806.us.archive.org'),('207.241.234.182','crawl804.us.archive.org'),('207.241.234.20','crawl803.us.archive.org'),('207.241.234.235','crawl805.us.archive.org'),('207.46.13.0','msnbot-207-46-13-0.search.msn.com'),('207.46.13.190','msnbot-207-46-13-190.search.msn.com'),('207.46.13.231','msnbot-207-46-13-231.search.msn.com'),('207.46.13.233','msnbot-207-46-13-233.search.msn.com'),('207.46.13.234','msnbot-207-46-13-234.search.msn.com'),('207.46.13.235','msnbot-207-46-13-235.search.msn.com'),('207.46.13.237','msnbot-207-46-13-237.search.msn.com'),('207.46.13.42','msnbot-207-46-13-42.search.msn.com'),('207.46.13.44','msnbot-207-46-13-44.search.msn.com'),('207.46.13.49','msnbot-207-46-13-49.search.msn.com'),('207.46.13.6','msnbot-207-46-13-6.search.msn.com'),('207.46.13.8','msnbot-207-46-13-8.search.msn.com'),('207.46.13.9','msnbot-207-46-13-9.search.msn.com'),('213.136.92.207','mad20.tiss.xyz'),('213.180.203.184','213-180-203-184.spider.yandex.com'),('213.180.203.249','213-180-203-249.spider.yandex.com'),('213.180.203.252','213-180-203-252.spider.yandex.com'),('213.180.203.253','213-180-203-253.spider.yandex.com'),('213.180.203.84','213-180-203-84.spider.yandex.com'),('213.180.203.88','213-180-203-88.spider.yandex.com'),('213.180.203.93','213-180-203-93.spider.yandex.com'),('213.239.216.194','linux03.r00tbase.de'),('216.240.128.213','sandspy.com'),('216.244.66.236','216.244.66.236'),('220.181.51.92','220.181.51.92'),('220.181.51.93','220.181.51.93'),('220.241.60.135','220.241.60.135'),('23.236.147.154','23.236.147.154'),('23.250.19.242','23.250.19.242'),('23.94.73.215','23-94-73-215-host.colocrossing.com'),('23.95.23.46','23-95-23-46-host.colocrossing.com'),('27.115.124.10','27.115.124.10'),('27.115.124.106','27.115.124.106'),('27.115.124.36','27.115.124.36'),('27.115.124.43','27.115.124.43'),('27.115.124.75','27.115.124.75'),('27.115.124.99','27.115.124.99'),('3.120.34.172','ec2-3-120-34-172.eu-central-1.compute.amazonaws.com'),('3.129.21.222','ec2-3-129-21-222.us-east-2.compute.amazonaws.com'),('3.142.77.156','ec2-3-142-77-156.us-east-2.compute.amazonaws.com'),('3.236.95.140','ec2-3-236-95-140.compute-1.amazonaws.com'),('3.237.16.210','ec2-3-237-16-210.compute-1.amazonaws.com'),('3.250.142.77','ec2-3-250-142-77.eu-west-1.compute.amazonaws.com'),('31.13.103.4','fwdproxy-odn-004.fbsv.net'),('31.31.78.89','31.31.78.89'),('34.135.14.161','161.14.135.34.bc.googleusercontent.com'),('34.231.180.48','ec2-34-231-180-48.compute-1.amazonaws.com'),('34.245.119.127','ec2-34-245-119-127.eu-west-1.compute.amazonaws.com'),('34.253.195.24','ec2-34-253-195-24.eu-west-1.compute.amazonaws.com'),('34.72.146.195','195.146.72.34.bc.googleusercontent.com'),('34.72.173.33','33.173.72.34.bc.googleusercontent.com'),('35.173.252.9','ec2-35-173-252-9.compute-1.amazonaws.com'),('35.192.140.97','97.140.192.35.bc.googleusercontent.com'),('35.210.151.25','25.151.210.35.bc.googleusercontent.com'),('35.213.167.52','52.167.213.35.bc.googleusercontent.com'),('35.238.238.137','137.238.238.35.bc.googleusercontent.com'),('35.84.196.130','ec2-35-84-196-130.us-west-2.compute.amazonaws.com'),('37.187.139.222','ns3206373.ip-37-187-139.eu'),('37.57.218.243','243.218.57.37.triolan.net'),('40.77.167.101','msnbot-40-77-167-101.search.msn.com'),('40.77.167.103','msnbot-40-77-167-103.search.msn.com'),('40.77.167.104','msnbot-40-77-167-104.search.msn.com'),('40.77.167.105','msnbot-40-77-167-105.search.msn.com'),('40.77.167.106','msnbot-40-77-167-106.search.msn.com'),('40.77.167.40','msnbot-40-77-167-40.search.msn.com'),('40.77.167.43','msnbot-40-77-167-43.search.msn.com'),('40.77.167.44','msnbot-40-77-167-44.search.msn.com'),('40.77.167.47','msnbot-40-77-167-47.search.msn.com'),('40.77.167.49','msnbot-40-77-167-49.search.msn.com'),('40.77.167.50','msnbot-40-77-167-50.search.msn.com'),('40.77.167.51','msnbot-40-77-167-51.search.msn.com'),('40.77.167.52','msnbot-40-77-167-52.search.msn.com'),('40.77.167.53','msnbot-40-77-167-53.search.msn.com'),('40.77.167.57','msnbot-40-77-167-57.search.msn.com'),('40.77.167.60','msnbot-40-77-167-60.search.msn.com'),('40.77.167.61','msnbot-40-77-167-61.search.msn.com'),('40.77.167.83','msnbot-40-77-167-83.search.msn.com'),('40.77.167.88','msnbot-40-77-167-88.search.msn.com'),('40.77.167.89','msnbot-40-77-167-89.search.msn.com'),('40.77.167.95','msnbot-40-77-167-95.search.msn.com'),('40.77.167.96','msnbot-40-77-167-96.search.msn.com'),('40.77.167.97','msnbot-40-77-167-97.search.msn.com'),('43.128.164.73','43.128.164.73'),('45.33.65.249','45-33-65-249.ip.linodeusercontent.com'),('46.4.60.249','static.249.60.4.46.clients.your-server.de'),('47.243.182.138','47.243.182.138'),('47.252.29.8','47.252.29.8'),('47.252.3.163','47.252.3.163'),('47.252.35.61','47.252.35.61'),('47.252.37.139','47.252.37.139'),('47.252.41.140','47.252.41.140'),('47.253.197.231','47.253.197.231'),('47.253.84.177','47.253.84.177'),('47.253.84.207','47.253.84.207'),('47.90.148.172','47.90.148.172'),('47.90.217.125','47.90.217.125'),('5.188.62.214','5.188.62.214'),('5.188.62.76','5.188.62.76'),('5.189.152.91','mad27.tiss.xyz'),('5.189.159.208','mad17.tiss.xyz'),('5.189.172.182','mad15.tiss.xyz'),('5.255.231.204','5-255-231-204.spider.yandex.com'),('5.255.253.122','5-255-253-122.spider.yandex.com'),('5.255.253.134','5-255-253-134.spider.yandex.com'),('5.255.253.156','5-255-253-156.spider.yandex.com'),('5.255.253.182','5-255-253-182.spider.yandex.com'),('5.45.207.130','5-45-207-130.spider.yandex.com'),('5.45.207.139','5-45-207-139.spider.yandex.com'),('5.45.207.142','5-45-207-142.spider.yandex.com'),('5.45.207.99','5-45-207-99.spider.yandex.com'),('5.9.107.211','static.211.107.9.5.clients.your-server.de'),('5.9.108.254','linux01.r00tbase.de'),('5.9.112.210','static.210.112.9.5.clients.your-server.de'),('5.9.138.189','static.189.138.9.5.clients.your-server.de'),('5.9.140.242','static.242.140.9.5.clients.your-server.de'),('5.9.141.8','static.8.141.9.5.clients.your-server.de'),('5.9.144.234','static.234.144.9.5.clients.your-server.de'),('5.9.151.57','static.57.151.9.5.clients.your-server.de'),('5.9.154.68','static.68.154.9.5.clients.your-server.de'),('5.9.154.69','static.69.154.9.5.clients.your-server.de'),('5.9.155.226','static.226.155.9.5.clients.your-server.de'),('5.9.155.37','static.37.155.9.5.clients.your-server.de'),('5.9.156.121','static.121.156.9.5.clients.your-server.de'),('5.9.156.20','static.20.156.9.5.clients.your-server.de'),('5.9.156.30','static.30.156.9.5.clients.your-server.de'),('5.9.158.195','static.195.158.9.5.clients.your-server.de'),('5.9.61.101','static.101.61.9.5.clients.your-server.de'),('5.9.61.232','static.232.61.9.5.clients.your-server.de'),('5.9.66.153','static.153.66.9.5.clients.your-server.de'),('5.9.70.113','static.113.70.9.5.clients.your-server.de'),('5.9.70.117','static.117.70.9.5.clients.your-server.de'),('5.9.70.72','static.72.70.9.5.clients.your-server.de'),('5.9.71.213','static.213.71.9.5.clients.your-server.de'),('5.9.77.102','static.102.77.9.5.clients.your-server.de'),('5.9.88.113','static.113.88.9.5.clients.your-server.de'),('5.9.97.200','static.200.97.9.5.clients.your-server.de'),('5.9.98.234','static.234.98.9.5.clients.your-server.de'),('50.19.95.113','ec2-50-19-95-113.compute-1.amazonaws.com'),('51.140.178.74','51.140.178.74'),('51.15.20.50','crawl-prod-16.babbar.eu'),('51.222.253.1','ip1.ip-51-222-253.net'),('51.222.253.10','ip10.ip-51-222-253.net'),('51.222.253.11','ip11.ip-51-222-253.net'),('51.222.253.12','ip12.ip-51-222-253.net'),('51.222.253.13','ip13.ip-51-222-253.net'),('51.222.253.14','ip14.ip-51-222-253.net'),('51.222.253.15','ip15.ip-51-222-253.net'),('51.222.253.16','ip16.ip-51-222-253.net'),('51.222.253.17','ip17.ip-51-222-253.net'),('51.222.253.18','ip18.ip-51-222-253.net'),('51.222.253.19','ip19.ip-51-222-253.net'),('51.222.253.2','ip2.ip-51-222-253.net'),('51.222.253.20','ip20.ip-51-222-253.net'),('51.222.253.3','ip3.ip-51-222-253.net'),('51.222.253.4','ip4.ip-51-222-253.net'),('51.222.253.5','ip5.ip-51-222-253.net'),('51.222.253.6','ip6.ip-51-222-253.net'),('51.222.253.7','ip7.ip-51-222-253.net'),('51.222.253.8','ip8.ip-51-222-253.net'),('51.222.253.9','ip9.ip-51-222-253.net'),('52.168.130.210','52.168.130.210'),('52.203.18.65','ec2-52-203-18-65.compute-1.amazonaws.com'),('52.36.125.174','ec2-52-36-125-174.us-west-2.compute.amazonaws.com'),('54.144.55.253','ec2-54-144-55-253.compute-1.amazonaws.com'),('54.161.41.102','54-161-41-102.neevabot.com'),('54.174.58.254','54.174.58.254'),('54.221.206.141','ec2-54-221-206-141.compute-1.amazonaws.com'),('54.36.148.103','ip-54-36-148-103.a.ahrefs.com'),('54.36.148.105','ip-54-36-148-105.a.ahrefs.com'),('54.36.148.106','ip-54-36-148-106.a.ahrefs.com'),('54.36.148.107','ip-54-36-148-107.a.ahrefs.com'),('54.36.148.108','ip-54-36-148-108.a.ahrefs.com'),('54.36.148.109','ip-54-36-148-109.a.ahrefs.com'),('54.36.148.11','ip-54-36-148-11.a.ahrefs.com'),('54.36.148.110','ip-54-36-148-110.a.ahrefs.com'),('54.36.148.113','ip-54-36-148-113.a.ahrefs.com'),('54.36.148.117','ip-54-36-148-117.a.ahrefs.com'),('54.36.148.12','ip-54-36-148-12.a.ahrefs.com'),('54.36.148.120','ip-54-36-148-120.a.ahrefs.com'),('54.36.148.123','ip-54-36-148-123.a.ahrefs.com'),('54.36.148.125','ip-54-36-148-125.a.ahrefs.com'),('54.36.148.126','ip-54-36-148-126.a.ahrefs.com'),('54.36.148.128','ip-54-36-148-128.a.ahrefs.com'),('54.36.148.131','ip-54-36-148-131.a.ahrefs.com'),('54.36.148.132','ip-54-36-148-132.a.ahrefs.com'),('54.36.148.137','ip-54-36-148-137.a.ahrefs.com'),('54.36.148.138','ip-54-36-148-138.a.ahrefs.com'),('54.36.148.143','ip-54-36-148-143.a.ahrefs.com'),('54.36.148.144','ip-54-36-148-144.a.ahrefs.com'),('54.36.148.145','ip-54-36-148-145.a.ahrefs.com'),('54.36.148.148','ip-54-36-148-148.a.ahrefs.com'),('54.36.148.15','ip-54-36-148-15.a.ahrefs.com'),('54.36.148.150','ip-54-36-148-150.a.ahrefs.com'),('54.36.148.151','ip-54-36-148-151.a.ahrefs.com'),('54.36.148.153','ip-54-36-148-153.a.ahrefs.com'),('54.36.148.154','ip-54-36-148-154.a.ahrefs.com'),('54.36.148.16','ip-54-36-148-16.a.ahrefs.com'),('54.36.148.160','ip-54-36-148-160.a.ahrefs.com'),('54.36.148.161','ip-54-36-148-161.a.ahrefs.com'),('54.36.148.163','ip-54-36-148-163.a.ahrefs.com'),('54.36.148.165','ip-54-36-148-165.a.ahrefs.com'),('54.36.148.167','ip-54-36-148-167.a.ahrefs.com'),('54.36.148.170','ip-54-36-148-170.a.ahrefs.com'),('54.36.148.173','ip-54-36-148-173.a.ahrefs.com'),('54.36.148.178','ip-54-36-148-178.a.ahrefs.com'),('54.36.148.179','ip-54-36-148-179.a.ahrefs.com'),('54.36.148.180','ip-54-36-148-180.a.ahrefs.com'),('54.36.148.183','ip-54-36-148-183.a.ahrefs.com'),('54.36.148.184','ip-54-36-148-184.a.ahrefs.com'),('54.36.148.185','ip-54-36-148-185.a.ahrefs.com'),('54.36.148.187','ip-54-36-148-187.a.ahrefs.com'),('54.36.148.19','ip-54-36-148-19.a.ahrefs.com'),('54.36.148.191','ip-54-36-148-191.a.ahrefs.com'),('54.36.148.193','ip-54-36-148-193.a.ahrefs.com'),('54.36.148.195','ip-54-36-148-195.a.ahrefs.com'),('54.36.148.197','ip-54-36-148-197.a.ahrefs.com'),('54.36.148.199','ip-54-36-148-199.a.ahrefs.com'),('54.36.148.2','ip-54-36-148-2.a.ahrefs.com'),('54.36.148.20','ip-54-36-148-20.a.ahrefs.com'),('54.36.148.202','ip-54-36-148-202.a.ahrefs.com'),('54.36.148.205','ip-54-36-148-205.a.ahrefs.com'),('54.36.148.206','ip-54-36-148-206.a.ahrefs.com'),('54.36.148.208','ip-54-36-148-208.a.ahrefs.com'),('54.36.148.209','ip-54-36-148-209.a.ahrefs.com'),('54.36.148.214','ip-54-36-148-214.a.ahrefs.com'),('54.36.148.215','ip-54-36-148-215.a.ahrefs.com'),('54.36.148.216','ip-54-36-148-216.a.ahrefs.com'),('54.36.148.219','ip-54-36-148-219.a.ahrefs.com'),('54.36.148.22','ip-54-36-148-22.a.ahrefs.com'),('54.36.148.220','ip-54-36-148-220.a.ahrefs.com'),('54.36.148.223','ip-54-36-148-223.a.ahrefs.com'),('54.36.148.225','ip-54-36-148-225.a.ahrefs.com'),('54.36.148.226','ip-54-36-148-226.a.ahrefs.com'),('54.36.148.232','ip-54-36-148-232.a.ahrefs.com'),('54.36.148.233','ip-54-36-148-233.a.ahrefs.com'),('54.36.148.237','ip-54-36-148-237.a.ahrefs.com'),('54.36.148.241','ip-54-36-148-241.a.ahrefs.com'),('54.36.148.243','ip-54-36-148-243.a.ahrefs.com'),('54.36.148.245','ip-54-36-148-245.a.ahrefs.com'),('54.36.148.246','ip-54-36-148-246.a.ahrefs.com'),('54.36.148.249','ip-54-36-148-249.a.ahrefs.com'),('54.36.148.253','ip-54-36-148-253.a.ahrefs.com'),('54.36.148.255','ip-54-36-148-255.a.ahrefs.com'),('54.36.148.26','ip-54-36-148-26.a.ahrefs.com'),('54.36.148.29','ip-54-36-148-29.a.ahrefs.com'),('54.36.148.30','ip-54-36-148-30.a.ahrefs.com'),('54.36.148.31','ip-54-36-148-31.a.ahrefs.com'),('54.36.148.33','ip-54-36-148-33.a.ahrefs.com'),('54.36.148.34','ip-54-36-148-34.a.ahrefs.com'),('54.36.148.35','ip-54-36-148-35.a.ahrefs.com'),('54.36.148.37','ip-54-36-148-37.a.ahrefs.com'),('54.36.148.4','ip-54-36-148-4.a.ahrefs.com'),('54.36.148.41','ip-54-36-148-41.a.ahrefs.com'),('54.36.148.44','ip-54-36-148-44.a.ahrefs.com'),('54.36.148.5','ip-54-36-148-5.a.ahrefs.com'),('54.36.148.54','ip-54-36-148-54.a.ahrefs.com'),('54.36.148.55','ip-54-36-148-55.a.ahrefs.com'),('54.36.148.57','ip-54-36-148-57.a.ahrefs.com'),('54.36.148.59','ip-54-36-148-59.a.ahrefs.com'),('54.36.148.63','ip-54-36-148-63.a.ahrefs.com'),('54.36.148.67','ip-54-36-148-67.a.ahrefs.com'),('54.36.148.68','ip-54-36-148-68.a.ahrefs.com'),('54.36.148.7','ip-54-36-148-7.a.ahrefs.com'),('54.36.148.70','ip-54-36-148-70.a.ahrefs.com'),('54.36.148.71','ip-54-36-148-71.a.ahrefs.com'),('54.36.148.73','ip-54-36-148-73.a.ahrefs.com'),('54.36.148.77','ip-54-36-148-77.a.ahrefs.com'),('54.36.148.80','ip-54-36-148-80.a.ahrefs.com'),('54.36.148.82','ip-54-36-148-82.a.ahrefs.com'),('54.36.148.83','ip-54-36-148-83.a.ahrefs.com'),('54.36.148.86','ip-54-36-148-86.a.ahrefs.com'),('54.36.148.87','ip-54-36-148-87.a.ahrefs.com'),('54.36.148.94','ip-54-36-148-94.a.ahrefs.com'),('54.36.148.95','ip-54-36-148-95.a.ahrefs.com'),('54.36.148.99','ip-54-36-148-99.a.ahrefs.com'),('54.36.149.0','ip-54-36-149-0.a.ahrefs.com'),('54.36.149.100','ip-54-36-149-100.a.ahrefs.com'),('54.36.149.11','ip-54-36-149-11.a.ahrefs.com'),('54.36.149.13','ip-54-36-149-13.a.ahrefs.com'),('54.36.149.14','ip-54-36-149-14.a.ahrefs.com'),('54.36.149.15','ip-54-36-149-15.a.ahrefs.com'),('54.36.149.17','ip-54-36-149-17.a.ahrefs.com'),('54.36.149.18','ip-54-36-149-18.a.ahrefs.com'),('54.36.149.2','ip-54-36-149-2.a.ahrefs.com'),('54.36.149.23','ip-54-36-149-23.a.ahrefs.com'),('54.36.149.26','ip-54-36-149-26.a.ahrefs.com'),('54.36.149.28','ip-54-36-149-28.a.ahrefs.com'),('54.36.149.3','ip-54-36-149-3.a.ahrefs.com'),('54.36.149.32','ip-54-36-149-32.a.ahrefs.com'),('54.36.149.35','ip-54-36-149-35.a.ahrefs.com'),('54.36.149.37','ip-54-36-149-37.a.ahrefs.com'),('54.36.149.38','ip-54-36-149-38.a.ahrefs.com'),('54.36.149.4','ip-54-36-149-4.a.ahrefs.com'),('54.36.149.41','ip-54-36-149-41.a.ahrefs.com'),('54.36.149.43','ip-54-36-149-43.a.ahrefs.com'),('54.36.149.48','ip-54-36-149-48.a.ahrefs.com'),('54.36.149.49','ip-54-36-149-49.a.ahrefs.com'),('54.36.149.51','ip-54-36-149-51.a.ahrefs.com'),('54.36.149.52','ip-54-36-149-52.a.ahrefs.com'),('54.36.149.54','ip-54-36-149-54.a.ahrefs.com'),('54.36.149.57','ip-54-36-149-57.a.ahrefs.com'),('54.36.149.60','ip-54-36-149-60.a.ahrefs.com'),('54.36.149.63','ip-54-36-149-63.a.ahrefs.com'),('54.36.149.64','ip-54-36-149-64.a.ahrefs.com'),('54.36.149.7','ip-54-36-149-7.a.ahrefs.com'),('54.36.149.70','ip-54-36-149-70.a.ahrefs.com'),('54.36.149.73','ip-54-36-149-73.a.ahrefs.com'),('54.36.149.77','ip-54-36-149-77.a.ahrefs.com'),('54.36.149.78','ip-54-36-149-78.a.ahrefs.com'),('54.36.149.79','ip-54-36-149-79.a.ahrefs.com'),('54.36.149.80','ip-54-36-149-80.a.ahrefs.com'),('54.36.149.81','ip-54-36-149-81.a.ahrefs.com'),('54.36.149.82','ip-54-36-149-82.a.ahrefs.com'),('54.36.149.84','ip-54-36-149-84.a.ahrefs.com'),('54.36.149.86','ip-54-36-149-86.a.ahrefs.com'),('54.36.149.9','ip-54-36-149-9.a.ahrefs.com'),('54.36.149.93','ip-54-36-149-93.a.ahrefs.com'),('54.36.149.99','ip-54-36-149-99.a.ahrefs.com'),('54.84.123.136','ec2-54-84-123-136.compute-1.amazonaws.com'),('54.86.66.252','nat-service4.aws.kontera.com'),('62.138.2.243','astra4239.startdedicated.de'),('62.171.159.200','mad10.tiss.xyz'),('64.145.65.6','64.145.65.6'),('65.108.0.71','static.71.0.108.65.clients.your-server.de'),('65.108.12.98','static.98.12.108.65.clients.your-server.de'),('65.108.128.54','static.54.128.108.65.clients.your-server.de'),('65.108.43.148','static.148.43.108.65.clients.your-server.de'),('65.108.46.72','static.72.46.108.65.clients.your-server.de'),('65.108.64.210','static.210.64.108.65.clients.your-server.de'),('65.21.122.241','static.241.122.21.65.clients.your-server.de'),('65.21.206.42','static.42.206.21.65.clients.your-server.de'),('65.21.206.43','static.43.206.21.65.clients.your-server.de'),('65.21.206.46','static.46.206.21.65.clients.your-server.de'),('65.21.231.30','static.30.231.21.65.clients.your-server.de'),('65.21.232.254','static.254.232.21.65.clients.your-server.de'),('66.220.149.35','fwdproxy-prn-035.fbsv.net'),('66.249.64.191','crawl-66-249-64-191.googlebot.com'),('66.249.65.100','crawl-66-249-65-100.googlebot.com'),('66.249.65.103','crawl-66-249-65-103.googlebot.com'),('66.249.65.105','crawl-66-249-65-105.googlebot.com'),('66.249.65.107','crawl-66-249-65-107.googlebot.com'),('66.249.65.109','crawl-66-249-65-109.googlebot.com'),('66.249.65.111','crawl-66-249-65-111.googlebot.com'),('66.249.65.123','crawl-66-249-65-123.googlebot.com'),('66.249.65.125','crawl-66-249-65-125.googlebot.com'),('66.249.65.127','crawl-66-249-65-127.googlebot.com'),('66.249.65.155','crawl-66-249-65-155.googlebot.com'),('66.249.65.157','crawl-66-249-65-157.googlebot.com'),('66.249.65.159','crawl-66-249-65-159.googlebot.com'),('66.249.65.203','crawl-66-249-65-203.googlebot.com'),('66.249.65.205','crawl-66-249-65-205.googlebot.com'),('66.249.65.207','crawl-66-249-65-207.googlebot.com'),('66.249.65.209','crawl-66-249-65-209.googlebot.com'),('66.249.65.217','crawl-66-249-65-217.googlebot.com'),('66.249.65.219','crawl-66-249-65-219.googlebot.com'),('66.249.65.221','crawl-66-249-65-221.googlebot.com'),('66.249.65.222','crawl-66-249-65-222.googlebot.com'),('66.249.65.223','crawl-66-249-65-223.googlebot.com'),('66.249.66.135','crawl-66-249-66-135.googlebot.com'),('66.249.66.139','crawl-66-249-66-139.googlebot.com'),('66.249.66.219','crawl-66-249-66-219.googlebot.com'),('66.249.66.27','crawl-66-249-66-27.googlebot.com'),('66.249.66.31','crawl-66-249-66-31.googlebot.com'),('66.249.66.42','crawl-66-249-66-42.googlebot.com'),('66.249.66.45','crawl-66-249-66-45.googlebot.com'),('66.249.66.83','crawl-66-249-66-83.googlebot.com'),('66.249.68.59','crawl-66-249-68-59.googlebot.com'),('66.249.68.61','crawl-66-249-68-61.googlebot.com'),('66.249.68.63','crawl-66-249-68-63.googlebot.com'),('66.249.69.123','crawl-66-249-69-123.googlebot.com'),('66.249.69.125','crawl-66-249-69-125.googlebot.com'),('66.249.69.127','crawl-66-249-69-127.googlebot.com'),('66.249.69.157','crawl-66-249-69-157.googlebot.com'),('66.249.69.158','crawl-66-249-69-158.googlebot.com'),('66.249.69.159','crawl-66-249-69-159.googlebot.com'),('66.249.70.123','crawl-66-249-70-123.googlebot.com'),('66.249.70.125','crawl-66-249-70-125.googlebot.com'),('66.249.70.127','crawl-66-249-70-127.googlebot.com'),('66.249.70.155','crawl-66-249-70-155.googlebot.com'),('66.249.70.157','crawl-66-249-70-157.googlebot.com'),('66.249.70.159','crawl-66-249-70-159.googlebot.com'),('66.249.70.59','crawl-66-249-70-59.googlebot.com'),('66.249.73.157','crawl-66-249-73-157.googlebot.com'),('66.249.73.159','crawl-66-249-73-159.googlebot.com'),('66.249.74.100','crawl-66-249-74-100.googlebot.com'),('66.249.74.103','crawl-66-249-74-103.googlebot.com'),('66.249.74.109','crawl-66-249-74-109.googlebot.com'),('66.249.74.123','crawl-66-249-74-123.googlebot.com'),('66.249.74.125','crawl-66-249-74-125.googlebot.com'),('66.249.74.127','crawl-66-249-74-127.googlebot.com'),('66.249.75.31','crawl-66-249-75-31.googlebot.com'),('66.249.75.81','crawl-66-249-75-81.googlebot.com'),('66.249.79.50','crawl-66-249-79-50.googlebot.com'),('66.249.79.55','crawl-66-249-79-55.googlebot.com'),('66.249.79.60','crawl-66-249-79-60.googlebot.com'),('69.171.249.15','fwdproxy-ldc-015.fbsv.net'),('69.171.249.8','fwdproxy-ldc-008.fbsv.net'),('69.30.226.234','69.30.226.234'),('71.179.200.105','pool-71-179-200-105.bltmmd.fios.verizon.net'),('71.6.146.130','refrigerator.census.shodan.io'),('71.6.146.186','inspire.census.shodan.io'),('71.6.165.200','census12.shodan.io'),('77.75.76.160','fulltextrobot-77-75-76-160.seznam.cz'),('77.75.76.161','fulltextrobot-77-75-76-161.seznam.cz'),('77.75.76.162','fulltextrobot-77-75-76-162.seznam.cz'),('77.75.76.163','fulltextrobot-77-75-76-163.seznam.cz'),('77.75.76.164','fulltextrobot-77-75-76-164.seznam.cz'),('77.75.76.165','fulltextrobot-77-75-76-165.seznam.cz'),('77.75.76.168','fulltextrobot-77-75-76-168.seznam.cz'),('77.75.76.169','fulltextrobot-77-75-76-169.seznam.cz'),('77.75.76.170','fulltextrobot-77-75-76-170.seznam.cz'),('77.75.76.171','fulltextrobot-77-75-76-171.seznam.cz'),('77.75.76.172','fulltextrobot-77-75-76-172.seznam.cz'),('77.75.77.101','fulltextrobot-77-75-77-101.seznam.cz'),('77.75.77.109','fulltextrobot-77-75-77-109.seznam.cz'),('77.75.77.11','fulltextrobot-77-75-77-11.seznam.cz'),('77.75.77.119','fulltextrobot-77-75-77-119.seznam.cz'),('77.75.77.17','fulltextrobot-77-75-77-17.seznam.cz'),('77.75.77.36','fulltextrobot-77-75-77-36.seznam.cz'),('77.75.77.54','fulltextrobot-77-75-77-54.seznam.cz'),('77.75.77.62','fulltextrobot-77-75-77-62.seznam.cz'),('77.75.78.172','fulltextrobot-77-75-78-172.seznam.cz'),('77.75.79.109','fulltextrobot-77-75-79-109.seznam.cz'),('77.75.79.11','fulltextrobot-77-75-79-11.seznam.cz'),('77.75.79.17','fulltextrobot-77-75-79-17.seznam.cz'),('77.75.79.36','fulltextrobot-77-75-79-36.seznam.cz'),('77.75.79.62','fulltextrobot-77-75-79-62.seznam.cz'),('77.75.79.72','fulltextrobot-77-75-79-72.seznam.cz'),('77.88.5.160','77-88-5-160.spider.yandex.com'),('77.88.5.208','77-88-5-208.spider.yandex.com'),('77.88.5.230','77-88-5-230.spider.yandex.com'),('77.88.5.246','77-88-5-246.spider.yandex.com'),('77.88.5.54','77-88-5-54.spider.yandex.com'),('77.88.5.70','77-88-5-70.spider.yandex.com'),('78.46.149.254','static.254.149.46.78.clients.your-server.de'),('78.46.176.21','static.21.176.46.78.clients.your-server.de'),('78.46.61.245','linux08.r00tbase.de'),('78.46.63.108','static.108.63.46.78.clients.your-server.de'),('78.46.85.236','static.236.85.46.78.clients.your-server.de'),('8.217.34.213','8.217.34.213'),('8.41.221.54','8.41.221.54'),('8.41.221.56','8.41.221.56'),('8.41.221.60','8.41.221.60'),('80.82.77.139','dojo.census.shodan.io'),('81.109.86.251','cpc69046-oxfd25-2-0-cust762.4-3.cable.virginm.net'),('81.209.177.145','bardolino.netestate.de'),('82.193.102.149','82.193.102.149.cl.ipnet.ua'),('82.193.104.168','82.193.104.168.cl.ipnet.ua'),('82.221.105.6','census10.shodan.io'),('82.221.105.7','census11.shodan.io'),('85.10.199.185','static.85-10-199-185.clients.your-server.de'),('85.10.207.195','static.85-10-207-195.clients.your-server.de'),('85.208.98.23','bot.semrush.com'),('85.208.98.27','1.bat.bot.semrush.com'),('87.250.224.116','87-250-224-116.spider.yandex.com'),('87.250.224.133','87-250-224-133.spider.yandex.com'),('87.250.224.146','87-250-224-146.spider.yandex.com'),('87.250.224.174','87-250-224-174.spider.yandex.com'),('87.250.224.195','87-250-224-195.spider.yandex.com'),('87.250.224.29','87-250-224-29.spider.yandex.com'),('87.250.224.83','87-250-224-83.spider.yandex.com'),('88.144.10.146','88-144-10-146.host.pobb.as13285.net'),('88.198.33.145','static.88-198-33-145.clients.your-server.de'),('88.99.26.43','static.43.26.99.88.clients.your-server.de'),('91.121.7.147','ns37837.ip-91-121-7.eu'),('91.137.27.112','vdsl-91-137-27-112.net.encoline.de'),('91.137.27.56','vdsl-91-137-27-56.net.encoline.de'),('91.137.51.197','vdsl-91-137-51-197.net.encoline.de'),('91.219.254.100','91.219.254.100'),('91.219.254.101','91.219.254.101'),('91.219.254.102','91.219.254.102'),('91.219.254.103','91.219.254.103'),('92.169.157.140','lfbn-idf2-1-1346-140.w92-169.abo.wanadoo.fr'),('92.220.10.100','100.92-220-10.customer.lyse.net'),('93.158.161.73','93-158-161-73.spider.yandex.com'),('93.158.90.135','93.158.90.135'),('93.158.91.184','93.158.91.184'),('93.158.91.187','93.158.91.187'),('93.158.91.196','93.158.91.196'),('93.158.91.228','93.158.91.228'),('93.158.91.229','93.158.91.229'),('93.158.91.231','93.158.91.231'),('93.158.92.13','93.158.92.13'),('93.158.92.164','93.158.92.164'),('93.158.92.205','93.158.92.205'),('93.158.92.215','93.158.92.215'),('93.158.92.231','93.158.92.231'),('93.174.95.106','battery.census.shodan.io'),('93.218.126.153','p5dda7e99.dip0.t-ipconnect.de'),('94.102.49.193','cloud.census.shodan.io'),('94.154.239.69','ip-ef45.d-net.kiev.ua'),('94.250.201.221','vmi714611.contaboserver.net'),('95.108.213.37','95-108-213-37.spider.yandex.com'),('95.108.213.48','95-108-213-48.spider.yandex.com'),('95.108.213.65','95-108-213-65.spider.yandex.com'),('95.216.11.179','majestic12.hu'),('95.216.38.186','static.186.38.216.95.clients.your-server.de'),('95.91.104.21','ip5f5b6815.dynamic.kabel-deutschland.de'),('95.91.109.193','ip5f5b6dc1.dynamic.kabel-deutschland.de'),('95.91.110.97','ip5f5b6e61.dynamic.kabel-deutschland.de'),('95.91.111.1','ip5f5b6f01.dynamic.kabel-deutschland.de'),('95.91.111.85','ip5f5b6f55.dynamic.kabel-deutschland.de'),('95.91.15.103','ip5f5b0f67.dynamic.kabel-deutschland.de'),('95.91.42.9','ip5f5b2a09.dynamic.kabel-deutschland.de'),('95.91.75.28','ip5f5b4b1c.dynamic.kabel-deutschland.de'),('95.91.76.35','ip5f5b4c23.dynamic.kabel-deutschland.de');
/*!40000 ALTER TABLE `bots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents`
--

DROP TABLE IF EXISTS `documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documents` (
  `docid` int(11) NOT NULL AUTO_INCREMENT,
  `fid` int(10) DEFAULT NULL,
  `title` text,
  `message` text,
  UNIQUE KEY `docid` (`docid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents`
--

LOCK TABLES `documents` WRITE;
/*!40000 ALTER TABLE `documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drafts` (
  `uid` int(10) NOT NULL DEFAULT '0',
  `type` varchar(50) NOT NULL DEFAULT '',
  `id` int(10) NOT NULL DEFAULT '0',
  `message` text,
  PRIMARY KEY (`uid`,`type`,`id`),
  KEY `uid_2` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `events` (
  `eventid` int(10) NOT NULL AUTO_INCREMENT,
  `dateline` int(20) DEFAULT NULL,
  `func` varchar(50) DEFAULT NULL,
  `var1` text,
  `var2` text,
  `var3` text,
  `var4` text,
  PRIMARY KEY (`eventid`),
  KEY `dateline` (`dateline`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events`
--

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `f30`
--

DROP TABLE IF EXISTS `f30`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `f30` (
  `tid` int(10) NOT NULL,
  PRIMARY KEY (`tid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `f30`
--

LOCK TABLES `f30` WRITE;
/*!40000 ALTER TABLE `f30` DISABLE KEYS */;
/*!40000 ALTER TABLE `f30` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `f30_whitelist`
--

DROP TABLE IF EXISTS `f30_whitelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `f30_whitelist` (
  `type` enum('ip','user') NOT NULL,
  `value` varchar(50) NOT NULL,
  PRIMARY KEY (`type`,`value`),
  KEY `type` (`type`),
  KEY `value` (`value`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `f30_whitelist`
--

LOCK TABLES `f30_whitelist` WRITE;
/*!40000 ALTER TABLE `f30_whitelist` DISABLE KEYS */;
/*!40000 ALTER TABLE `f30_whitelist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `f31`
--

DROP TABLE IF EXISTS `f31`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `f31` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `field` enum('ip','host') DEFAULT NULL,
  `type` enum('is','contains') DEFAULT NULL,
  `value` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `field` (`field`,`type`,`value`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `f31`
--

LOCK TABLES `f31` WRITE;
/*!40000 ALTER TABLE `f31` DISABLE KEYS */;
/*!40000 ALTER TABLE `f31` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `f31_whitelist`
--

DROP TABLE IF EXISTS `f31_whitelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `f31_whitelist` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `field` enum('ip','host') DEFAULT NULL,
  `type` enum('is','contains') DEFAULT NULL,
  `value` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `f31_whitelist`
--

LOCK TABLES `f31_whitelist` WRITE;
/*!40000 ALTER TABLE `f31_whitelist` DISABLE KEYS */;
/*!40000 ALTER TABLE `f31_whitelist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `f33`
--

DROP TABLE IF EXISTS `f33`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `f33` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `field` enum('ip','host','user') DEFAULT NULL,
  `type` enum('is','contains') DEFAULT NULL,
  `value` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `field` (`field`,`type`,`value`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `f33`
--

LOCK TABLES `f33` WRITE;
/*!40000 ALTER TABLE `f33` DISABLE KEYS */;
/*!40000 ALTER TABLE `f33` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filter_log`
--

DROP TABLE IF EXISTS `filter_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `filter_log` (
  `logid` int(10) NOT NULL AUTO_INCREMENT,
  `dateline` int(10) NOT NULL,
  `tid` int(10) DEFAULT NULL,
  `fid` int(10) DEFAULT NULL,
  `user` varchar(50) DEFAULT NULL,
  `title` text,
  `message` text,
  `filterid` int(10) DEFAULT NULL,
  PRIMARY KEY (`logid`),
  KEY `tid` (`tid`),
  KEY `fid` (`fid`),
  KEY `user` (`user`),
  KEY `filterid` (`filterid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filter_log`
--

LOCK TABLES `filter_log` WRITE;
/*!40000 ALTER TABLE `filter_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `filter_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum_mods`
--

DROP TABLE IF EXISTS `forum_mods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum_mods` (
  `fid` int(10) NOT NULL,
  `uid` int(10) NOT NULL,
  PRIMARY KEY (`fid`,`uid`),
  KEY `fid` (`fid`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum_mods`
--

LOCK TABLES `forum_mods` WRITE;
/*!40000 ALTER TABLE `forum_mods` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum_mods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forums`
--

DROP TABLE IF EXISTS `forums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forums` (
  `fid` int(10) NOT NULL AUTO_INCREMENT,
  `slug` text COLLATE latin1_general_ci NOT NULL,
  `name` text COLLATE latin1_general_ci NOT NULL,
  `disclaimer` int(1) NOT NULL,
  `linkname` text COLLATE latin1_general_ci NOT NULL,
  `on_ql` int(11) NOT NULL,
  `description` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`fid`),
  KEY `on_ql` (`on_ql`)
) ENGINE=MyISAM AUTO_INCREMENT=294 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forums`
--

LOCK TABLES `forums` WRITE;
/*!40000 ALTER TABLE `forums` DISABLE KEYS */;
INSERT INTO `forums` VALUES (1,'requests','Requests',0,'Feature Requests',1,'Feature requests and ideas, what can we do for you? '),(2,'feedback','Feedback',0,'Dispute Resolution',0,''),(3,'site-issues','Site Issues',1,'',0,''),(4,'announcements','Site Announcements',0,'',0,''),(5,'help','Help',0,'',0,''),(8,'rpg-chat','Roleplaying',0,'Roleplaying',1,'There have been too many role playing phases to list - pick one and have fun! '),(9,'badlands','RIP Badlands Forum',0,'',0,''),(7,'sax0phone','Mod forum',0,'',0,'Howdy. A place for mods... someday!'),(10,'jedi-sith','Jedi Sith / Star Wars',0,'Jedi Sith',0,''),(164,'category:-site','Category: Site',0,'',0,''),(165,'category:-games','Category: Games',0,'',0,''),(166,'category:-special-topics','Category: Special Topics',0,'',0,''),(167,'samaritan','League of Extraordinary Gentlemen',0,'League',0,''),(168,'engineering-bay','The War Room',0,'',0,''),(169,'catbird','Fat Cats & Rich Birds',0,'',0,''),(170,'hall-of-fame','Hall of Fame',0,'',0,''),(11,'middle-earth','Middle-earth (Home of the Hobbits)',0,'',0,''),(204,'tester','tester',0,'',0,''),(12,'pointless','GTX0 Lounge',0,'GTX0 Lounge',0,''),(191,'zelda-roleplay','Zelda Roleplay',0,'Zelda RP',0,''),(161,'search-for-the-secret-moderator-forum','The Search for the Secret Moderator Forum',0,'',0,''),(13,'duh','Duh!',0,'',0,''),(14,'mario','<font color=#B22222>Super Mario Universe</font>',0,'Mario World',0,''),(15,'zelda','The Kingdom of Hyrule',0,'Legend of Zelda',0,''),(16,'pokemon','The Pokémon Forum',0,'Pokémon',0,''),(17,'final-fantasy','Final Fantasy/RPGs',0,'Final Fantasy/RPGs',0,''),(18,'sonic','Sanic',0,'',0,''),(19,'general-game-forum','General Game Forum',0,'',0,''),(20,'classic-games','Classic Games',0,'',0,''),(21,'internet-games','<font color=white>Computer Help & Chat</font color>',0,'Computer Help & Chat',0,''),(231,'castraelheartscastrael','Redack <3 Castrael',0,'',0,''),(229,'countdooku','An Unremarkable Forum',0,'Count Dooku',0,''),(22,'video-games','Video Games',0,'Video Game News & Discussions ',1,'Zelda, Mario, Pokemon, Elder Scrolls, Fallout... Nintendo, Sony, Microsoft, any of the above and more! What are you playing? '),(268,'embassy','The Embassy',0,'The Embassy',0,''),(262,'nife-updates','NIFE Updates',0,'Updates',0,''),(256,'braaaaaains','Braaaaaains',0,'',0,''),(251,'venture1','NIFE',0,'NIFE',0,''),(23,'handhelds','Handheld Gaming',0,'',0,''),(24,'music','Entertainment & Media',0,'Entertainment & Media',1,'Movies, Books, TV, Tabletop RPGs... share here! '),(240,'sunshine','Sunshine',0,'',0,''),(162,'rant','The Ranting Forum',0,'',0,''),(159,'101010101','101010101',0,'',0,''),(160,'yeanogame','Mafia',0,'GTX0 Mafia',0,''),(25,'tv','TV and Films',0,'TV & Films',0,''),(171,'thecabal','The Admin Forum',0,'The Admin Forum',0,''),(26,'movies','Movies',0,'',0,''),(27,'animation','Web Design & Animation',0,'Web Design & Animation',0,''),(28,'books','Books',0,'',0,''),(29,'dueling-cards','Dueling Cards',0,'',0,''),(30,'world','Politics & World',0,'Politics & Religion',1,'Current Events and World Affairs, Government Information and News Headlines... but please leverage the Hot Takes forum for debates! '),(31,'life','General',0,'General',1,'Pointless, Duh, Miscellaneous... all synonyms for \'Anything Goes!\' (within the rules, of course ;) )'),(32,'spirituality','Spirituality & Philosophy',0,'Spirituality',1,'What is life? What happens after death? How do we live morally to become our best selves? Let\'s discuss! '),(33,'holiday','Halloween Village',0,'Happy Holidays!',0,''),(232,'happy','The Happy Forum',0,'Happy',0,''),(34,'sci-fi','Fan Fiction of GT',0,'',0,''),(35,'depression','Depression',0,'',0,''),(36,'health','fitness and lifestyle',0,'',0,''),(37,'school','School',0,'',0,''),(38,'nintendo-wii','Nintendo Wii',0,'',0,''),(39,'playstation-3','PlayStation 3',0,'',0,''),(40,'xbox-360','XBOX 360',0,'',0,''),(41,'pc-chat','PC Gaming',0,'',0,''),(42,'test','The Sandbox',0,'Sandbox',0,''),(172,'poker','Casino and Board Games',0,'Casino & Board Games',0,''),(163,'category:-roleplaying','Category: Roleplaying',0,'',0,''),(43,'comedy','Comedy',0,'',0,''),(44,'fantasy','Fantasy and Sci-Fi',0,'Fantasy and Sci-Fi',0,''),(45,'oldanime','Xhin\'s forum',0,'',0,''),(46,'fanfics','Fan  Fiction',0,'',0,''),(47,'writing','Creative Outlet',0,'Creative Outlet',0,''),(48,'mariogalaxy','Super Mario Galaxy',0,'',0,''),(49,'skywardsword','The Legend of Zelda: Skyward Sword',0,'Skyward Sword',0,''),(50,'ssb','Super Smash Bros.',0,'Super Smash Bros.',0,''),(51,'mariokart','Mario Kart',0,'Mario Kart',0,''),(52,'animalcrossing','Supreme Outer Haven ',0,'',0,''),(53,'ffxiii','Final Fantasy XIII',0,'',0,''),(54,'arkham','Batman: Arkham Asylum',0,'',0,''),(55,'fallout3','Fallout Series',0,'',0,''),(56,'skyrim','Elder Scrolls V:Skyrim',0,'ES V: Skyrim',0,''),(57,'metalgear4','Metal Gear Solid 4',0,'',0,''),(58,'halo3','Halo 3',0,'Halo',0,''),(59,'fable2','Fable II',0,'',0,''),(60,'left4dead','Left 4 Dead',0,'Left 4 Dead',0,''),(61,'rockband2','Rock Band 2',0,'',0,''),(62,'ultimatealliance2','Ultimate Alliance 2',0,'',0,''),(63,'pokemondiamond','Pokemon Diamond',0,'',0,''),(64,'pokemonpearl','Pokemon Pearl',0,'',0,''),(65,'pokemonplatinum','Pokemon Platinum',0,'',0,''),(66,'pokemonheartsoul','Pokemon HeartGold and SoulSilver',0,'',0,''),(85,'wrestling','The Wrestling Forum',0,'Wrestling',0,''),(68,'phantomhourglass','Zelda: Phantom Hourglass',0,'',0,''),(69,'spirittracks','Zelda: Spirit Tracks',0,'',0,''),(70,'newsupermario','New Super Mario Bros',0,'',0,''),(71,'chronotrigger','Chrono Trigger',0,'',0,''),(72,'dissidia','Final Fantasy: Dissidia',0,'',0,''),(73,'monsterhunteru','Monster Hunter Freedom U',0,'',0,''),(74,'smtpersona','Shin Megami Tensei: Persona',0,'',0,''),(75,'kingdomheartsbirth','Kingdom Hearts: dead zone',0,'',0,''),(76,'soulcaliberdestiny','Soul Caliber: Destiny',0,'',0,''),(77,'wow','World of Warcraft',0,'',0,''),(78,'teamfortress2','Team Fortress 2',0,'',0,''),(79,'resevil5','Resident Evil 6',0,'Resident Evil 6',0,''),(80,'sims2','The Sims 2',0,'',0,''),(81,'spore','Spore',0,'',0,''),(84,'masseffect3','Mass Effect',0,'Mass Effect',0,''),(86,'newest','Newest Posts',0,'Newest Posts',0,''),(273,'milkbone-273','milkbone 273',0,'',0,''),(274,'worldbuilding','Worldbuilding',0,'',1,'When the real world doesn\'t have enough for our stories, we invent a new one. Let\'s share cultures and ideas and create together :)'),(275,'creative','Creative Forum',0,'',1,'Poetry, short stories, song lyrics, what\'s your muse? What are you itching to share? â™¥'),(276,'journal','Journal',0,'',0,''),(272,'protests','Protests',0,'',0,''),(239,'archive:-writing','Creative Outlet Archive',0,'',0,''),(156,'forum-games','Forum Games',0,'',0,''),(87,'search','Search Results',0,'',0,''),(88,'dragonball','The Dragon Ball Universe',0,'',0,''),(89,'sports','The Sports Center',0,'Sports',1,'NFL, NHL, World Cup, MLB, Fantasy Football and more! If sports are your passion, you\'ve found your home here. '),(175,'anime','Animated/Japanese',0,'Animated/Japanese',0,''),(90,'suparsekret','Feral\'s Den',0,'Feral\'s Den',0,''),(202,'modernize','The Evervamp',0,'Evervamp',0,''),(91,'axem','Axem Forum',0,'Axems',0,''),(208,'gearsofwar','Gears of War',0,'Gears of War',0,''),(92,'kingdomhearts','Kingdom Hearts ',0,'Kingdom Hearts',0,''),(93,'runescape','Runescape',0,'',0,''),(94,'goldensun','<font color=#fdd017>Golden Sun</font>',0,'Golden Sun',0,''),(95,'shadow','Shadows Anonymous',0,'Shadows',0,''),(96,'epic','Epic Posts',0,'',0,''),(97,'vroom','Travel & Vacations',0,'Travel & Vacations',0,''),(98,'food','The Food & Drink Forum',0,'',0,''),(99,'e-fed','GTx0 Fantasy Wrestling League',0,'WWE Fantasy League',0,''),(100,'info','Important Information',0,'',0,''),(101,'halo','Halo ',0,'Halo ',0,''),(102,'yoshi','<font color=#aaffaa>Yo</font><font color=#aaaaff>shi</font>',0,'',0,''),(103,'metroid','The Metroid Forum',0,'',0,''),(104,'naruto','Naruto',0,'',0,''),(105,'adultswim','[adultswim]',0,'',0,''),(106,'mmorpg','MMORPGs (Massively Multiplayer Online Role Playing Games)',0,'',0,''),(107,'drawing','Drawing & Art 101',0,'',0,''),(108,'ninja','Ninja Washitsu',0,'',0,''),(109,'love','<3',0,'',0,''),(110,'hottest','Newest Replies',0,'',0,''),(111,'computer-tech','Computer Tech',0,'',0,''),(112,'harry-potter','Harry Potter',0,'',0,''),(113,'burningbird','<font color=\"#ff1122\">T</font><font color=\"#ff2222\">h</font><font color=\"#ff3322\">e</font><font color=\"#ff4422\"> </font><font color=\"#ff5522\">B</font><font color=\"#ff6622\">u</font><font color=\"#ff7722\">r</font><font color=\"#ff8822\">n</font><font color=\"#ff9922\">i</font><font color=\"#ffaa22\">n</font><font color=\"#ffbb22\">g</font><font color=\"#ffcc22\"> </font><font color=\"#ffdd22\">B</font><font color=\"#ffee22\">i</font><font color=\"#ffff22\">rd</font>',0,'',0,''),(114,'thisissatire','I like to fit all muslims into the category of people that blew up the WTC, and in fact I\'ll go ahead and fit all religions in there since despite thousand year differences and completely different cultures, all religions are exactly the same, and their goal is to turn everyone into a mindless slave who believes in nothing but fantasy',0,'',0,''),(115,'obsession','Obsessions, Compulsions, Fascinations, and Infatuations',0,'',0,''),(116,'rhythm','Rhythm',0,'',0,''),(117,'social','The Digiworld',0,'Digimon',0,''),(118,'sci-math','Science, Math, & Technology',0,'Science & Technology',1,'STEM_fields++;'),(119,'avatar','Avatar',0,'',0,''),(120,'rpc','RP Central',0,'RP Central',0,''),(121,'twin-lotus','Twin Lotus',0,'',0,''),(122,'h2g2','Drunjk Forum',0,'Drunjk',0,''),(123,'starfox','Planet StarFox',0,'',0,''),(124,'youtube','Youtube Videos',0,'',0,''),(135,'tekken','Tekken',0,'',0,''),(143,'comics-manga','Comics, Webcomics & Manga',0,'Comics/Manga',0,''),(136,'call-of-duty','Call of Duty',0,'',0,''),(137,'prince-of-persia','Prince of Persia',0,'',0,''),(138,'assassins-creed','Assassins Creed',0,'',0,''),(139,'grand-theft-auto','Grand Theft Auto',0,'',0,''),(140,'elder-scrolls','Bethesda Games & Fallout Series',0,'Elder Scrolls & Fallout Series',0,''),(141,'fable','Podcast Lounge',0,'Podcast',0,''),(142,'tomb-raider','Tomb Raider',0,'',0,''),(125,'fourm-of-the-typos','Fourm of the Typos',0,'',0,''),(126,'animal-crossing','Animal Crossing',0,'Animal Crossing',0,''),(127,'pikmin','Pikmin',0,'',0,''),(128,'banjo-kazooie','Banjo-Kazooie',0,'',0,''),(129,'tales-of','Tales of Symphonia',0,'',0,''),(130,'fire-emblem','Fire Emblem',0,'',0,''),(131,'fallout','Fallout',0,'',0,''),(132,'mortal-kombat','The Dojo',0,'Fighting Games',0,''),(133,'resident-evil','Resident Evil',0,'',0,''),(134,'metal-gear','Metal Gear',0,'Metal Gear Solid V: TPP ',0,''),(144,'psy-soc','Psychology and the Human Body',0,'Human Sciences',0,''),(145,'paranorm','Horror',0,'Horror',0,''),(146,'theater','The Gametalk Stage',0,'',0,''),(147,'lizards','Lizards Anonymous',0,'Lizards',0,''),(282,'mariomguy','The Mariomguy Forum',0,'',0,''),(148,'arcade','Mobile & Flash Games',0,'Mobile/Flash Games',0,''),(0,'hell','Hell',0,'Hell',0,''),(150,'introductions','Introductions',0,'Introductions',0,''),(151,'archive','Archive',0,'',0,''),(152,'villains','Covenant of Fraction-Metal Spell Casters ',0,'Covenant',0,''),(153,'outdoors','Outdoors / Nature',0,'',0,''),(154,'fashion','Fashion & Trends',0,'Fashion & Trends',0,''),(155,'mythology','Mythology',0,'',0,''),(157,'starcraft','Starcraft',0,'',0,''),(158,'minecraft','Minecraft',0,'',0,''),(173,'forum-requests','Scraped Feature (For rent)',0,'',0,''),(174,'mod-applications','Mod Applications',0,'',0,''),(185,'mylittlepony','My Little Pony',0,'My Little Pony',0,''),(176,'surge1','Fantasy SURGE',0,'',0,''),(177,'surge2','Sci-fi SURGE',0,'',0,''),(192,'lol','League of Legends',0,'MMO Forum',0,''),(190,'streams','Spectator Gaming',0,'Spectator Gaming',0,''),(180,'junction','Redackia',0,'Redackia',0,''),(181,'dungeons-&-dragons','Dungeons & Dragons',0,'',0,''),(182,'dungeons-and-dragons','Dungeons & Dragons: The Forgotten Realms',0,'Dungeons & Dragons',0,''),(183,'devices','Handheld Devices',0,'Handheld Devices',0,''),(184,'diablo','Diablo III',0,'Diablo III',0,''),(186,'recycling','The Recycling Bin',0,'',0,''),(187,'next-gen','Future Gaming',0,'Future Gaming',0,''),(188,'thenameisreallylongsoitsimpossibletolinktowithoutspendingalotoftimeonit','Da WuRsT fOrUm EvAr MaDe',0,'The worst forum ever made',0,''),(189,'guildwars2','Guild Wars 2',0,'Guild Wars 2',0,''),(193,'textadventure','GTX0 Adventure',0,'GTX0 Adventure',0,''),(213,'lionking','The Lion King',0,'',0,''),(214,'toc','Time Out Corner',0,'Time Out Corner',0,''),(194,'???','Darkness',0,'',0,''),(198,'castlevania','Castlevania',0,'Castlevania',0,''),(200,'resevil','Resident Evil',0,'Resident Evil',0,''),(195,'indie','Terraria And Other Indie Games',0,'Terraria & Indies',0,''),(196,'feral','.............',0,'',0,''),(206,'survivalhorror','Survival Horror',0,'Survival Horror',0,''),(197,'chat-settings','chat_settings',0,'',0,''),(199,'dookugame','Dooku\'s Game',0,'',0,''),(201,'deadspace','Dead Space',0,'Dead Space',0,''),(203,'null',' - ',0,'',0,''),(209,'fadedenigma','Faded Enigma',0,'Faded Enigma',0,''),(210,'smashbros','Super Smash Bros.',0,'Super Smash Bros',0,''),(205,'bossgame','bossgame',0,'',0,''),(207,'bioshock','Bioshock',0,'Bioshock',0,''),(217,'nostalgia','The Nostalgia Forum',0,'Nostalgia',1,'Because we all have fond memories of the years gone by, we might as well bond over it. â™¥'),(211,'fun','GTX0 Fun',0,'GTX0 Fun',0,''),(216,'castraelheartsredack','!',0,'ggg',0,''),(222,'heliocracy','Heliocracy',0,'',0,''),(223,'banredack','Ban Redack',0,'Ban Redack',0,''),(224,'nife','NIFE',0,'',0,''),(236,'roguelike','Roguelike',0,'Roguelike',0,''),(234,'memorial','In Remembrance',0,'memorial',0,''),(225,'titanfall','Titanfall',0,'',0,''),(242,'migrate','migrate',0,'',0,''),(226,'castraelheartsdooku','Castrael <3 Redack',0,'',0,''),(227,'tropicalfreeze','Donkey Kong Country: Tropical Freeze',0,'DKC: Tropical Freeze',0,''),(230,'dominion','dominion',0,'',0,''),(228,'darksouls','Dark Souls',0,'Dark Souls',0,''),(233,'mkgrandpre','Mario Kart Grand Prix',0,'Grand Prix',0,''),(235,'fortress','Helius\' Fortress',0,'',0,''),(241,'jo-nathan','The Jo Nathan Forum',0,'',0,''),(238,'anonymous','N/A',0,'GTers Anonymous',0,''),(237,'forum-impossible','forum-impossible',0,'Forum Impossible',0,''),(244,'overwatch','Overwatch',0,'Overwatch',0,''),(246,'strategy','Strategy Games',0,'Strategy',0,''),(245,'nomansky','No Man\'s Sky',0,'No Man\'s Sky',0,''),(250,'automafia','Automafia Testing Grounds',0,'AutoMafia',0,''),(252,'venture2','The Maze',0,'The Maze',0,''),(253,'venture3','Adventure Game Test 3',0,'',0,''),(254,'gtforall','GT For All',0,'GT For All',0,''),(255,'ghowilogame','ghowilogame',0,'',0,''),(266,'marvalo','The Marvalo Forum',0,'',0,''),(257,'lords-of-havoc','Lords of Havoc',0,'',0,''),(258,'wild-pig-island','Wild Pig Island',0,'',0,''),(259,'arena-test','Arena Test',0,'',0,''),(260,'space-war','Space War',0,'',0,''),(261,'adventure','Adventure',0,'',0,''),(263,'nife-requests','NIFE Requests',0,'Requests',0,''),(264,'nife-help','NIFE Help',0,'Help',0,''),(265,'nife-world-discussions','NIFE World Discussions',0,'Discuss Game Worlds',0,''),(267,'broomcloset','The Broom closet',0,'',0,''),(269,'staff-hq','Staff HQ',0,'',0,''),(270,'deathmatches','Deathmatches',0,'Deathmatches',0,''),(271,'nife-roadmap','NIFE Roadmap',0,'Roadmap',0,''),(283,'shrines-legacy','Shrine\'s Legacy',0,'',0,''),(278,'chew-toy','Chew Toy',0,'',0,''),(279,'milkbone','Milkbone',0,'',0,''),(6,'milkbone-6','milkbone 6',0,'',0,''),(149,'milkbone-149','milkbone 149',0,'',0,''),(221,'milkbone-221','milkbone 221',0,'',0,''),(280,'milkbone-361','milkbone 361',0,'',0,''),(281,'milkbone-382','milkbone 382',0,'',0,''),(284,'milkbone-24113','milkbone 24113',0,'',0,''),(285,'milkbone-2147483647','milkbone 2147483647',0,'',0,''),(286,'community-decisions','Community Decisions',0,'',0,''),(287,'sexuality','Sexuality',0,'',1,'Safe space for LGTBTQ and Allies, and any discussions of kinks, sexual experiences, and musings. Absolutely no shaming allowed!'),(288,'sidebar','super secret sidebar forum',0,'',0,''),(289,'hot-takes','Hot Takes',1,'Hot Takes',1,'For any opinions that will likely lead to heated debates. Please keep it civil and read at your own risk. '),(290,'complaints','Complaints',0,'Complaints',1,'What can we do better? Be honest, but please keep it civil. We\'d love to hear your feedback! '),(-1,'global','Global',0,'',0,''),(291,'awwww','Awwww',0,'Awwww',1,'Family, Friends, Pets; Photos, Stories, Memes... Nothing but good vibes here! '),(293,'hobbies','Hobbies',0,'hobbies',1,'What are you into?');
/*!40000 ALTER TABLE `forums` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ips`
--

DROP TABLE IF EXISTS `ips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ips` (
  `ip` varchar(15) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  UNIQUE KEY `ip_2` (`ip`,`user`),
  KEY `ip` (`ip`),
  KEY `user` (`user`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ips`
--

LOCK TABLES `ips` WRITE;
/*!40000 ALTER TABLE `ips` DISABLE KEYS */;
INSERT INTO `ips` VALUES ('67.83.15.146','Fire Xhin'),('67.83.15.146','hi'),('67.83.15.146','weird occurance');
/*!40000 ALTER TABLE `ips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kicks`
--

DROP TABLE IF EXISTS `kicks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kicks` (
  `kickid` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) DEFAULT NULL,
  `ip` varchar(15) DEFAULT NULL,
  `dateline` int(20) DEFAULT NULL,
  PRIMARY KEY (`kickid`),
  KEY `uid` (`uid`),
  KEY `dateline` (`dateline`),
  KEY `ip` (`ip`,`dateline`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kicks`
--

LOCK TABLES `kicks` WRITE;
/*!40000 ALTER TABLE `kicks` DISABLE KEYS */;
/*!40000 ALTER TABLE `kicks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log`
--

DROP TABLE IF EXISTS `log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log` (
  `logid` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) DEFAULT NULL,
  `ip` varchar(15) DEFAULT NULL,
  `host` text NOT NULL,
  `dateline` int(20) DEFAULT NULL,
  `request` text NOT NULL,
  `post` text NOT NULL,
  `sid` text NOT NULL,
  `whid` int(10) NOT NULL,
  `bot` int(1) NOT NULL,
  PRIMARY KEY (`logid`),
  KEY `ip` (`ip`),
  KEY `bot` (`bot`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log`
--

LOCK TABLES `log` WRITE;
/*!40000 ALTER TABLE `log` DISABLE KEYS */;
/*!40000 ALTER TABLE `log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_nopower`
--

DROP TABLE IF EXISTS `log_nopower`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_nopower` (
  `logid` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) DEFAULT NULL,
  `ip` varchar(15) DEFAULT NULL,
  `host` text NOT NULL,
  `dateline` int(20) DEFAULT NULL,
  `request` text NOT NULL,
  `post` text NOT NULL,
  `sid` text NOT NULL,
  `whid` int(10) NOT NULL,
  `bot` int(1) NOT NULL,
  PRIMARY KEY (`logid`),
  KEY `ip` (`ip`),
  KEY `bot` (`bot`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_nopower`
--

LOCK TABLES `log_nopower` WRITE;
/*!40000 ALTER TABLE `log_nopower` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_nopower` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_attempts`
--

DROP TABLE IF EXISTS `login_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_attempts` (
  `uid` int(10) DEFAULT NULL,
  `ip` varchar(15) DEFAULT NULL,
  `dateline` int(10) DEFAULT NULL,
  KEY `uid` (`uid`,`ip`,`dateline`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_attempts`
--

LOCK TABLES `login_attempts` WRITE;
/*!40000 ALTER TABLE `login_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mycards`
--

DROP TABLE IF EXISTS `mycards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mycards` (
  `uid` int(10) NOT NULL DEFAULT '0',
  `theme` enum('glorious','slim','profound','grid','champ','gemini','wide','bold','framed','caption','onion') DEFAULT NULL,
  `data` text,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mycards`
--

LOCK TABLES `mycards` WRITE;
/*!40000 ALTER TABLE `mycards` DISABLE KEYS */;
/*!40000 ALTER TABLE `mycards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `names`
--

DROP TABLE IF EXISTS `names`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `names` (
  `nameid` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `password` text,
  `claimed` int(1) NOT NULL,
  PRIMARY KEY (`nameid`),
  UNIQUE KEY `username_2` (`username`),
  KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `names`
--

LOCK TABLES `names` WRITE;
/*!40000 ALTER TABLE `names` DISABLE KEYS */;
INSERT INTO `names` VALUES (1,'Fire Xhin','m3tN3<Y9XJbhq-^B',0);
/*!40000 ALTER TABLE `names` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permabans`
--

DROP TABLE IF EXISTS `permabans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permabans` (
  `banid` int(10) NOT NULL AUTO_INCREMENT,
  `ip` varchar(15) DEFAULT NULL,
  `uid` int(10) DEFAULT NULL,
  `dateline` int(20) DEFAULT NULL,
  PRIMARY KEY (`banid`),
  KEY `ip` (`ip`,`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permabans`
--

LOCK TABLES `permabans` WRITE;
/*!40000 ALTER TABLE `permabans` DISABLE KEYS */;
/*!40000 ALTER TABLE `permabans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plugins` (
  `pluginid` int(10) NOT NULL AUTO_INCREMENT,
  `slug` varchar(30) NOT NULL,
  `name` text,
  `desc` text,
  PRIMARY KEY (`pluginid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
INSERT INTO `plugins` VALUES (1,'post_pagination','Post Pagination',NULL);
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_edits`
--

DROP TABLE IF EXISTS `post_edits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post_edits` (
  `editid` int(10) NOT NULL AUTO_INCREMENT,
  `pid` int(10) DEFAULT NULL,
  `dateline` int(20) DEFAULT NULL,
  `uid` int(10) DEFAULT NULL,
  `ip` varchar(15) DEFAULT NULL,
  `message` text,
  PRIMARY KEY (`editid`),
  KEY `pid` (`pid`),
  KEY `dateline` (`dateline`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_edits`
--

LOCK TABLES `post_edits` WRITE;
/*!40000 ALTER TABLE `post_edits` DISABLE KEYS */;
/*!40000 ALTER TABLE `post_edits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posting_filters`
--

DROP TABLE IF EXISTS `posting_filters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `posting_filters` (
  `filterid` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `field` enum('username','message','title') DEFAULT NULL,
  `type` enum('is','contains','length','regex') DEFAULT NULL,
  `value` text,
  PRIMARY KEY (`filterid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posting_filters`
--

LOCK TABLES `posting_filters` WRITE;
/*!40000 ALTER TABLE `posting_filters` DISABLE KEYS */;
/*!40000 ALTER TABLE `posting_filters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `posts` (
  `pid` int(10) NOT NULL AUTO_INCREMENT,
  `tid` int(10) NOT NULL,
  `fid` int(10) NOT NULL,
  `user` varchar(50) CHARACTER SET latin1 NOT NULL,
  `dateline` int(20) NOT NULL,
  `message` text CHARACTER SET utf8 NOT NULL,
  `interaction` text COLLATE latin1_general_ci NOT NULL,
  `ip` text COLLATE latin1_general_ci NOT NULL,
  `tag_reason` text COLLATE latin1_general_ci NOT NULL,
  `tag_nameid` int(10) NOT NULL,
  `sban` int(1) NOT NULL,
  `editline` int(20) NOT NULL DEFAULT '0',
  `no_freaking_clue` int(1) NOT NULL,
  `branchid` int(10) NOT NULL DEFAULT '1',
  `unblockable` int(1) NOT NULL,
  `mature` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`pid`),
  KEY `dateline` (`dateline`),
  KEY `tid` (`tid`),
  KEY `fid` (`fid`,`user`),
  KEY `user` (`user`),
  KEY `fid_2` (`fid`),
  KEY `branchid` (`branchid`),
  KEY `tag_nameid` (`tag_nameid`),
  KEY `sban` (`sban`),
  KEY `mature` (`mature`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scrub`
--

DROP TABLE IF EXISTS `scrub`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scrub` (
  `tid` int(10) NOT NULL,
  UNIQUE KEY `tid` (`tid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scrub`
--

LOCK TABLES `scrub` WRITE;
/*!40000 ALTER TABLE `scrub` DISABLE KEYS */;
/*!40000 ALTER TABLE `scrub` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scrub_users`
--

DROP TABLE IF EXISTS `scrub_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scrub_users` (
  `user` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scrub_users`
--

LOCK TABLES `scrub_users` WRITE;
/*!40000 ALTER TABLE `scrub_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `scrub_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `sessid` varchar(32) NOT NULL,
  `uid` int(10) DEFAULT NULL,
  `ip` varchar(15) DEFAULT NULL,
  `dateline` int(20) DEFAULT NULL,
  PRIMARY KEY (`sessid`),
  KEY `uid` (`uid`),
  KEY `ip` (`ip`),
  KEY `dateline` (`dateline`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `signed`
--

DROP TABLE IF EXISTS `signed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `signed` (
  `type` enum('ip','uid') NOT NULL,
  `value` varchar(15) NOT NULL,
  `fid` int(10) NOT NULL,
  PRIMARY KEY (`type`,`value`,`fid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `signed`
--

LOCK TABLES `signed` WRITE;
/*!40000 ALTER TABLE `signed` DISABLE KEYS */;
/*!40000 ALTER TABLE `signed` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `spyrit`
--

DROP TABLE IF EXISTS `spyrit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spyrit` (
  `tid` int(10) NOT NULL,
  PRIMARY KEY (`tid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `spyrit`
--

LOCK TABLES `spyrit` WRITE;
/*!40000 ALTER TABLE `spyrit` DISABLE KEYS */;
/*!40000 ALTER TABLE `spyrit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `survey_answers`
--

DROP TABLE IF EXISTS `survey_answers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `survey_answers` (
  `answerid` int(10) NOT NULL AUTO_INCREMENT,
  `quid` int(10) DEFAULT NULL,
  `answer_type` enum('normal','custom','text') NOT NULL DEFAULT 'normal',
  `value` text,
  PRIMARY KEY (`answerid`),
  KEY `quid` (`quid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey_answers`
--

LOCK TABLES `survey_answers` WRITE;
/*!40000 ALTER TABLE `survey_answers` DISABLE KEYS */;
/*!40000 ALTER TABLE `survey_answers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `survey_questions`
--

DROP TABLE IF EXISTS `survey_questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `survey_questions` (
  `quid` int(10) NOT NULL AUTO_INCREMENT,
  `survid` int(10) DEFAULT NULL,
  `name` text,
  `type` enum('poll','free_poll','text') DEFAULT NULL,
  PRIMARY KEY (`quid`),
  KEY `survid` (`survid`),
  KEY `type` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey_questions`
--

LOCK TABLES `survey_questions` WRITE;
/*!40000 ALTER TABLE `survey_questions` DISABLE KEYS */;
/*!40000 ALTER TABLE `survey_questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `survey_responses`
--

DROP TABLE IF EXISTS `survey_responses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `survey_responses` (
  `survid` int(10) NOT NULL,
  `user` varchar(50) NOT NULL,
  `quid` int(10) NOT NULL,
  `answer` int(10) DEFAULT NULL,
  `text_answer` text NOT NULL,
  PRIMARY KEY (`survid`,`user`,`quid`),
  KEY `survid` (`survid`),
  KEY `user` (`user`),
  KEY `quid` (`quid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey_responses`
--

LOCK TABLES `survey_responses` WRITE;
/*!40000 ALTER TABLE `survey_responses` DISABLE KEYS */;
/*!40000 ALTER TABLE `survey_responses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `surveys`
--

DROP TABLE IF EXISTS `surveys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `surveys` (
  `survid` int(10) NOT NULL AUTO_INCREMENT,
  `tid` int(10) DEFAULT NULL,
  PRIMARY KEY (`survid`),
  UNIQUE KEY `tid` (`tid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `surveys`
--

LOCK TABLES `surveys` WRITE;
/*!40000 ALTER TABLE `surveys` DISABLE KEYS */;
/*!40000 ALTER TABLE `surveys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `thread_views`
--

DROP TABLE IF EXISTS `thread_views`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `thread_views` (
  `tid` int(10) NOT NULL DEFAULT '0',
  `uid` int(10) NOT NULL DEFAULT '0',
  `dateline` int(20) NOT NULL,
  `pid` int(10) NOT NULL,
  `read_pid` int(10) NOT NULL,
  PRIMARY KEY (`tid`,`uid`),
  KEY `tid` (`tid`),
  KEY `uid` (`uid`),
  KEY `pid` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `thread_views`
--

LOCK TABLES `thread_views` WRITE;
/*!40000 ALTER TABLE `thread_views` DISABLE KEYS */;
/*!40000 ALTER TABLE `thread_views` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `threads`
--

DROP TABLE IF EXISTS `threads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `threads` (
  `tid` int(10) NOT NULL AUTO_INCREMENT,
  `fid` int(10) NOT NULL,
  `quirk` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `title` text COLLATE latin1_general_ci NOT NULL,
  `user` varchar(50) CHARACTER SET latin1 NOT NULL,
  `firstpost` int(10) NOT NULL,
  `lastposter` text COLLATE latin1_general_ci NOT NULL,
  `dateline` int(20) NOT NULL,
  `replies` int(10) NOT NULL,
  `sticky` int(1) NOT NULL,
  `cement` int(1) NOT NULL DEFAULT '0',
  `locked` int(1) NOT NULL,
  `ip` text COLLATE latin1_general_ci NOT NULL,
  `lastpid` int(10) NOT NULL,
  `slug` varchar(110) COLLATE latin1_general_ci NOT NULL,
  `groupslug` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `dupeslug` int(1) NOT NULL,
  `branchid` int(10) NOT NULL DEFAULT '1',
  `badslug` int(1) NOT NULL,
  `icon` text COLLATE latin1_general_ci NOT NULL,
  `mature` int(1) NOT NULL DEFAULT '0',
  `link_color` varchar(6) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`tid`),
  KEY `dateline` (`dateline`),
  KEY `replies` (`replies`),
  KEY `firstpost` (`firstpost`),
  KEY `lastpid` (`lastpid`),
  KEY `user` (`user`),
  KEY `slug` (`slug`),
  KEY `fid` (`fid`),
  KEY `mature` (`mature`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `threads`
--

LOCK TABLES `threads` WRITE;
/*!40000 ALTER TABLE `threads` DISABLE KEYS */;
/*!40000 ALTER TABLE `threads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_data`
--

DROP TABLE IF EXISTS `user_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_data` (
  `uid` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `value` text,
  PRIMARY KEY (`uid`,`name`),
  KEY `uid` (`uid`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_data`
--

LOCK TABLES `user_data` WRITE;
/*!40000 ALTER TABLE `user_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_plugins`
--

DROP TABLE IF EXISTS `user_plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_plugins` (
  `uid` int(10) NOT NULL,
  `pluginid` int(10) NOT NULL,
  PRIMARY KEY (`uid`,`pluginid`),
  KEY `uid` (`uid`),
  KEY `pluginid` (`pluginid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_plugins`
--

LOCK TABLES `user_plugins` WRITE;
/*!40000 ALTER TABLE `user_plugins` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `uid` int(10) NOT NULL AUTO_INCREMENT,
  `branchid` int(10) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `primary_nameid` int(10) DEFAULT NULL,
  `hash` text,
  `email` text,
  `is_mod` int(1) NOT NULL,
  `is_admin` int(1) NOT NULL,
  `banned` int(1) NOT NULL,
  `invisible` int(1) NOT NULL,
  PRIMARY KEY (`uid`),
  KEY `branchid` (`branchid`),
  KEY `username` (`username`),
  KEY `primary_uid` (`primary_nameid`)
) ENGINE=InnoDB AUTO_INCREMENT=5421 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (-73,1,'Fire Xhin',1,'d5368077b81f02d9cfb964578ff5b56b','',1,1,0,0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vars`
--

DROP TABLE IF EXISTS `vars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vars` (
  `name` varchar(20) NOT NULL,
  `value` text,
  `cat` enum('lockdown') NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vars`
--

LOCK TABLES `vars` WRITE;
/*!40000 ALTER TABLE `vars` DISABLE KEYS */;
INSERT INTO `vars` VALUES ('accounts_required','0','lockdown'),('autotagger','0','lockdown'),('autotagger_max','360',''),('autotagger_min','180',''),('filter_30','0','lockdown'),('filter_31','1','lockdown'),('mod_lockdown','0','lockdown'),('registrations_locked','0','lockdown'),('reply_freeze','30','lockdown'),('the_nuclear_option','0','lockdown');
/*!40000 ALTER TABLE `vars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `whitelist`
--

DROP TABLE IF EXISTS `whitelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `whitelist` (
  `ip` varchar(15) NOT NULL,
  `uid` int(10) NOT NULL,
  `dateline` int(20) DEFAULT NULL,
  `whid` int(10) NOT NULL,
  PRIMARY KEY (`ip`,`uid`),
  KEY `ip` (`ip`),
  KEY `dateline` (`dateline`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `whitelist`
--

LOCK TABLES `whitelist` WRITE;
/*!40000 ALTER TABLE `whitelist` DISABLE KEYS */;
/*!40000 ALTER TABLE `whitelist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `whitelist_log`
--

DROP TABLE IF EXISTS `whitelist_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `whitelist_log` (
  `whid` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) DEFAULT NULL,
  `ip` varchar(15) DEFAULT NULL,
  `dateline` int(20) DEFAULT NULL,
  `host` text,
  PRIMARY KEY (`whid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `whitelist_log`
--

LOCK TABLES `whitelist_log` WRITE;
/*!40000 ALTER TABLE `whitelist_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `whitelist_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zold_blocks`
--

DROP TABLE IF EXISTS `zold_blocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zold_blocks` (
  `blockid` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) DEFAULT NULL,
  `user` text,
  `mode` varchar(50) NOT NULL,
  `thread` varchar(50) NOT NULL,
  PRIMARY KEY (`blockid`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zold_blocks`
--

LOCK TABLES `zold_blocks` WRITE;
/*!40000 ALTER TABLE `zold_blocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `zold_blocks` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-02-22 23:06:28
