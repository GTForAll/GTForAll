<style type="text/css">
    #search {
        width: 100% !important;
    }
    
    #search td {
        text-align: left !important;
    }
    
    #search .full input, #search .full select {
        min-width: 150px;
    }
    
    #search .half input, #search .half select {
        min-width: 150px;
    }
    
    .search-mine {
        display: inline-block;
        margin-left: 15px;
    }
    
    #search-forums select {
        display: block;
        margin-bottom: 10px;
    }
    
    label.smol {
        padding: 5px 16px;
        display: inline-block;
        font-size: 0.8em;
    }
    
    label.smol input {
        width: initial !important;
        min-width: initial !important;
        margin-right: 8px;
    }
    
    input[type=button].smol {
        min-width: initial !important;
        padding: 3px 15px;
        font-size: 0.8em;
    }
</style>
<h1 class="there-are">Search</h1>

<?=f('search')?>
<table class="tm" id="search">
    <tr><th>Title</th><td class="full">
        <input name="title" />    
    </td></tr>
    
    <tr><th>First poster</th><td class="half">
        <label class="smol"><input type="checkbox" name="first_poster_not" value="1" />NOT</label>
        <input name="first_poster" /><a class="search-mine" href="" user="<?=my('user')?>"><?=my('user')?></a>
    </td></tr>
    
    <?php if (my('user')) { ?>
    <tr><th>People in thread</th><td class="half">
        <input name="people_in_thread[]" class="dupe-this" />
        <input class="smol" type="button" obj="dupe" func="autodupe" var1="#self" value=" + " dupe_max="2" />
    </td></tr>
    <?php } ?>
    
    <tr><th>Last poster</th><td class="half">
        <label class="smol"><input type="checkbox" name="last_poster_not" value="1" />NOT</label>
        <input name="last_poster" /><a class="search-mine" href="" user="<?=my('user')?>"><?=my('user')?></a>
    </td></tr>
    
    <tr><th>Date</th><td class="half">
        <?=fill_select('date_search',deslug_all(Array('last_post','first_post')),'first_post')?>
        <?=fill_select('date_type',deslug_all(Array('before','after','between')),'',true,'search-date')?>
        <input type="date" name="date" />
        <span id="date-between" style="display: none;">and <input type="date" name="date_range" /></span>
    </td></tr>
    
    <tr><th>Forums</th><td id="search-forums">
        <?=fill_select('forums[]',$data['ql'],'',true,'self-dupe')?>
    </td></tr>
    
    <tr><th>Last Reply Length</th><td>
        From <input name="length_min" value="<?=$data['length_min']?>" type="number" /> to 
        <input name="length_max" value="<?=$data['length_max']?>" type="number" /> characters
    </td></tr>
    
    <th>Sort</th><td class="half">
        <?=fill_select('feed_type',deslug_all(Array('hottest','newest','most_replies')))?>
        <?=fill_select('feed_sort',deslug_all(Array('first','last')))?>
    </td></tr>
    </tr>
</table>
<?=uf('Search')?>