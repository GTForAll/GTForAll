<style type="text/css">
#title, #message { width: 600px !important; }
#message { height: 400px !important; }
</style>

<h1>Edit Documents for <?=$forum['name']?></h1>
<?=f('document_add')?>
<h2>New Document</h2>
<input name="title" id="title" placeholder="Document Title"><br />
<textarea name="message" id="message"></textarea>
<input type="hidden" name="fid" value="<?=$forum['fid']?>" />
<input id="docid" type="hidden" name="docid" value="0" />
<?=uf('Submit')?>

<?php if ($data) { ?>
  <table class="cp">
    <?=f('document_edit')?>
    <table class="cp">
    <tr><th>Title</th><th>Edit</th><th>View</th><th>Delete</th></tr>

    <?php foreach ($data?:Array() as $doc) { ?>
      <tr>
        <td><?=$doc['title']?></td>
        <td><a href="" class="doc-edit" docid="<?=$doc['docid']?>">Edit</a></td>
        <td><a href="/document/<?=$doc['docid']?>">View</a>
        <td><label><input type="checkbox" name="delete[]" value="<?=$doc['docid']?>" />Delete</label></td>
      </tr>
    <?php } ?>
    </table>
    <?=uf('Submit')?>
<?php } ?>
