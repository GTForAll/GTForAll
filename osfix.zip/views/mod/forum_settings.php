
  <?=f('forum_edit')?>
  <input type="hidden" name="fid" value="<?=$forum['fid']?>" />
  <textarea name="description"><?=$forum['description']?></textarea>
  <?=uf('Save Settings')?>
