<style type="text/css">
    #page {
        line-height: 1.3em;
        font-size: 1.1em;
        color: #d0d0d0;
    }

    .center {
      margin-left: auto;
      margin-right: auto;

    }
    p {

        padding: 5px;
    }

    table {
      margin-left: auto;
      margin-right: auto;
    }

    th {

       padding-left: 5px;
       padding-bottom: 5px;
       padding-right: 20px;

    }

    td {
      padding-left: 5px;
      padding-bottom: 5px;
      padding-right: 20px;

    }



    ol {
        margin: 20px;
        padding: 0px;
    }

    li {
        margin-top: 15px;
        margin-left: 10px;
    }
</style>

<h2 class="there-are">Join the Community!</h2>

<div class="list" style="text-align:center">
<a href="https://discord.gg/kty84UeaBE">Official Discord</a>
<a href="https://www.facebook.com/teamgtforall"><?=ic('facebook')?>Official Facebook</a>
<a href="mailto:teamgtforall@gmail.com">Official Email</a>
</div>

<h2 class="there-are" style="margin-top:5px">Contact Us on Discord!</h2>

<table class="center">
  <tr>
    <th>Contact</th>
    <th>Discord</th>
  </tr>
  <tr>
    <td>Weird Occurance (Owner)</td>
    <td>Jade22020#4746</td>
  </tr>
  <tr>
    <td>Lord Denida (Global Mod)</td>
    <td>Essery81#4729</td>
  </tr>
</table>
