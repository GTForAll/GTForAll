<style type="text/css">

    #mycard-inner {
        padding: 10px;
        margin: 10px;
        background-color: #222;
        border: 1px solid #444;
        box-shadow: 0px 0px 10px #000 inset;
        border-radius: 15px;
        text-align: center;
    }

    #mycard-wrapper {
        text-align: center;
    }

    #mycard-wrapper > div {
        display: inline-block; 
        vertical-align: top;
    }
    
</style>
<h2 class="there-are">All Mycards</h2>
<?php $mycards = Engine::mycards()->all(); ?>
<div id="mycard-wrapper">
<?php foreach ($mycards as $card) { ?>
    <div id="mycard-inner">
    <h2 class="there-are"><?=$card['username']?></h2>
    <?=$card['data']?>
    </div>
<?php } ?>
</div>