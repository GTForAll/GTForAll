<head>
    <title><?=$title?></title>
    <?php foreach ($css?:Array() AS $src) {
        if (!has($src,'http')) { $src .= '?v='.time(); }
    ?>
        <link rel="stylesheet" type="text/css" media="screen" href="<?=$src?>" />
    <?php } ?>
    <?php if (Engine::View()->name_is('thread')) { ?>
    <?php } ?>
</head>
<body>

<style type="text/css">

    #ql {
        margin-top: 0px;
        margin-bottom: 0px;
    }

    #ql a {
        color: #d0d0d0;
    }

    #ql td:hover {
        background-color: #222;
    }

    #ql a:hover {
        color: #ffa;
    }
</style>

<div id="content">

<?php if (!page('no_uptop')) { ?>

<header>
    <a href="/"><img src="/images/logo_crop.png" /></a>
    <div id="navs">
    <?php foreach ($navs AS $nav) {
        $extra = '';
        if ($nav['ajax'])
        {
            $extra = 'ajax="'.$nav['ajax'].'"';
        }
        elseif ($nav['ajax_html'])
        {
            $extra = 'ajax_html="'.$nav['ajax_html'].'"';
        }

        if ($nav['obj'])
        {
            $extra .= 'obj="'.$nav['obj'].'" func="'.$nav['func'].'"';
        }
        if (!$nav['color']) { $nav['color'] = 'default'; }
    ?>
        <a id="nav-<?=$nav['enslug']?>" href="<?=$nav['link']?>" <?=$extra?> style="color: #<?=$nav['color']?>;">
            <i class="material-icons"><?=$nav['icon']?></i>
            <span><?=$nav['name']?></span>
        </a>
    <?php } ?>
    </div>
    <div id="uptop" class="stone needy" style="display: none;"></div>
</header>

<div id="addy-boxy"></div>

<style type="text/css">
    .xql {
        display: block;
        background-color: #111;
        padding: 15px;
    }

    .xql a {
        width: auto;
        padding: 10px;
        background-color: #142339;
        margin-left: 15px;
    }

    .xqlo {
        background-color: #454228 !important;
    }

    .xql a:hover {
        background-color: #444 !important;
    }

    #comm-feedback {
        display: inline-block;
        vertical-align: top;
        padding: 10px;
        background-color: #222;
        box-shadow: 0px 0px 10px #000 inset;
        margin-top: 5px;
    }
</style>

<!-- Announcements -->
<div class="list td xql">
  <!--  <a href="https://gtforall.com/thread/shrines_legacy_kickstarter_laxans_game">Shrine's Legacy Kickstarter!</a> -->
</div>

<table class="tm" id="ql"><tr>
    <?php $spacing = 4; ?>
    <?php $i = -1; foreach ($data['forums'] as $forum) { $i++; ?>

        <?php if ($i % $spacing == 0) { ?></tr><tr><?php } ?>

        <td><a href="/forum/<?=$forum['slug']?>"><?=$forum['name']?></a></td>
    <?php } ?>

    <?php $last = $i%$spacing;  ?>

    <?php for ($i=$last; $i < ($spacing-1); $i++) { ?>
        <td>&nbsp;</td>
    <?php } ?>

    </tr>
</table>

<div class="list td xql">
<?php if (1==1) { ?>

    <span id="comm-feedback">File a Complaint: </span>
    <a href="/new/thread/complaints"><?=ic('add_comment')?> New</a>

<?php } else { ?>

    <span id="comm-feedback">GTX0 is community-run.</span>
    <a href="/new/thread/feedback"><?=ic('add_comment')?> New request</a>
    <a href="https://gtforall.com/new/survey/community-decisions"><?=ic('add_comment')?> Change the way things work</a>
    <a href="https://gtforall.com/new/thread/feedback"><?=ic('add_comment')?> Make smaller suggestions</a>

<?php } ?>
</div>

<div id="page-wrapper" class="page-center">

<?php if (has($data['modules'],'sidebar')) { include "../views/sidebar.php"; } ?>

<div id="page" class="stone">
<?php if ($GLOBALS['page_error']) { ?>
    <h2 class="there-are-red">Error</h2>
    <div class="page-error"><?=$GLOBALS['page_error']?></div>
<?php } ?>

<?php if ($GLOBALS['page_conf']) { ?>
    <h2 class="there-are-green">Success</h2>
    <div class="page-conf"><?=$GLOBALS['page_conf']?></div>
<?php } ?>
<?php } ?>
