<h1 class="there-are-red">Semi-permanent Lockdown</h1>

<div class="big-text"><?=$data['message']?></div>