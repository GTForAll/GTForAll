<style type="text/css">
    .home-last {
        max-width: 400px;
    }

    #index-bottom > div {
        display: inline-block;
        width: 49%;
        vertical-align: top;
    }

    #index-stats td {
        text-align: left;
    }
</style>
<!--
<h1 class="there-are">Don't panic!</h1>

<div class="big-text list">
<a href="/thread/dontpanic">Come here first</a>
</div>-->

<h1 class="there-are">Forums</h1>

<style type="text/css">
     
</style>

<table class="tm" id="forum-list">
    <tr><th>Forum</th><th>Threads</th><th>Posts</th><th>Last post</th></tr>
    <?php foreach ($data['threads']?:array() AS $fid => $val) {
        $forum = $data['forums'][$fid]; 
        $post = $data['threads'][$fid];
        if ($post['lastposter'] == '-' || !$post['lastposter'])
        {
            $post['lastposter'] = $post['user'];
            $post['post_dateline'] = $post['dateline'];
        }
    ?>
        <tr>
            <td><a href="/forum/<?=$forum['slug']?>"><?=$forum['name']?></a></td>
            <td><?=number_format($data['thread_count'][$fid]['amt'])?></td>
            <td><?=number_format($data['post_count'][$fid]['amt'])?></td>          
            <td class="left home-last">
                <a href="/thread/<?=$post['slug']?>"><?=$post['title']?></a><br />
                    by <?=$post['lastposter']?> <?=dinpago($post['post_dateline'])?>
            </td>
        </tr>
    <?php } ?>
</table>

<div id="index-bottom">
<div>
<h1 class="there-are">Users</h1>

<?=Engine::ajax_html_routing()->people(false)?>
</div>
<div>
    <h1 class="there-are">Stats</h1>
    <table class="tm" id="index-stats">
        <tr><td>Posts today</td><td><?=number_format(Engine::stats()->posts_today())?></td><td><?=Engine::stats()->posts_today(true)?></td></tr>
        <tr><td>Posts this week</td><td><?=number_format(Engine::stats()->posts_this_week())?></td><td><?=Engine::stats()->posts_this_week(true)?></td></tr>
        <tr><td>Posts this month</td><td><?=number_format(Engine::stats()->posts_this_month())?></td><td><?=Engine::stats()->posts_this_month(true)?></td></tr>
        <tr><td>Posts this year</td><td><?=number_format(Engine::stats()->posts_this_year())?></td><td><?=Engine::stats()->posts_this_year(true)?></td></tr>
        <tr><th colspan="3">&nbsp;</th></tr>
        <tr><td>Total Threads</td><td colspan="2"><?=number_format(Engine::stats()->threads())?></td></tr>
        <tr><td>Total Posts</td><td colspan="2"><?=number_format(Engine::stats()->posts())?></td></tr>
        <tr><td>Accounts</td><td colspan="2"><?=number_format(Engine::stats()->accounts())?></td></tr>
    </table>
</div>
</div>