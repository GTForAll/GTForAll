<h1 class="there-are-cyan">Site Feed: <?=deslug($data['type'])?></h1>

<?php /*
<?=Engine::plugins()->bar(Array('newest_replies'))?>
*/ ?>

<div class="list">
    
<?php if ($data['type'] != 'newest') { ?>
<a href="/feed/newest">Newest</a>
<?php } ?>

<?php if ($data['type'] != 'hottest') { ?>
<a href="/feed/hottest">Hottest</a>
<?php } ?>

<?php if ($data['type'] != 'mine') { ?>
<a href="/feed/mine">Mine</a>
<?php } ?>

</div>    