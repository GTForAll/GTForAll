<style type="text/css">
    .thread-title {
        width: 50%;
        text-align: left !important;
    }

    a.mature-hide{
      color: #faa000;

    }


    tr.sticky-1 td {
        background-color: #2a2a2a;
    }

    tr.sticky-2 td {
        background-color: #3a3a3a;
    }


    tr.locked .thread-title {
        background-color: #000;
        color: #777;
        font-style: italic;
    }


    .thread-title {
        max-width: 500px;
    }

    .icon-url {
        background-size: 100% 100%;
    }

    .icon-url > img {
        display: none;
    }

</style>
<?php if (iam('mod')) { ?>
    <?=f('moderate')?>
    <input type="hidden" name="modmode" value="forum" />
<?php } ?>

<table class="tm" id="forum-table">
    <tr><th colspan="2">Message</th><th>Replies</th><th>Person</th><th>Date</th>
        <?php if (iam('mod')) { ?>
            <th>Mark</th>
        <?php } ?>
    </tr>
    <?php foreach ($data['threads'] as $row) {
        $classes = Array();
        if (get_setting('show_mature_content')) { $row['thread_mature'] = 0; }
        if ($row['sticky']) { $classes[] = 'sticky-'.$row['sticky']; }
        if ($row['locked']) { $classes[] = 'locked'; }
        if ($row['tag_nameid']) { $classes[] = 'tagged'; }
        $classes = implode(' ',$classes);

        $is_blocked = 'display: none;';
        $not_blocked = '';
        if ($data['blocks'][$row['user']])
        {
            $is_blocked = '';
            $not_blocked = 'display: none;';
            $block_type = 'user';
        }
        elseif ($data['blocks']['thread_'.$row['tid']])
        {
            $is_blocked = '';
            $not_blocked = 'display: none;';
            $block_type = 'thread';
        }

        $obj = ZXC::sel('user/posts')->sort('pid--')->where('tid',$row['tid']);

        if (!my('sban_white'))
        {
            $obj->where('sban',0);
        }

        $lastposter = $obj->the();

        if ($row['replies'] == 0) { $lastposter = '-'; }

        $link_style = '';
        if ($row['link_color'])
        {
            $link_style .= 'color: #'.$row['link_color'];
        }

        // $lastposter = $row['lastposter'];
    ?>

        <tr id="thread-blocked-<?=$row['tid']?>" class="thread-blocked" style="<?=$is_blocked?>">
            <td></td><td style="text-align: left;" colspan="5">
                Blocked <?=$block_type?>. <a href="" obj="user_block" func="show_thread" var1="<?=$row['tid']?>" style="margin-left: 10px;">Show thread</a>
            </td>
        </tr>

        <tr class="<?=$classes?>" style="<?=$not_blocked?>" id="thread-<?=$row['tid']?>">
            <?php Engine::icon()->format('td',$row['icon'])?>
            <td class="thread-title">

            <?php if (!$row['thread_mature']) { ?>
                <a href="/thread/<?=$row['slug']?>" style="<?=$link_style?>"><?=$row['title']?></a>
            <?php } else { ?>
                <a href="/thread/<?=$row['slug']?>" class="mature-show" style="display: none;<?=$link_style?>">
                    <?=$row['title']?>
                </a>
                <a href="" class="mature-hide" obj="mature" func="show_thread" var1="#self">Show mature content</a>
            <?php } ?>

            <?php /*(<?=$row['tid']?>)*/ ?></td>

            <td><?=$row['replies']?></td>
            <td><?=$row['user']?><br />(<?=$lastposter?>)</td>
            <td><?=dinpago($row['post_dateline'])?></td>
            <?php if (Engine::auth()->can_mod($row['fid'])) { ?>
                <td class="marker"><label><input name="marked[]" value="<?=$row['tid']?>" class="mark" type="checkbox" /></label></td>
            <?php } ?>
        </tr>
    <?php } ?>
</table>

<?php if (iam('mod')) { ?>
    <div id="mod-tools" style="display: none;">
        <div id="mod-tools-tools">
        <input type="button" obj="mark" func="down" value="v Toggle Down v" />
        <label>Tag <input name="tag_mode" value="tag" type="radio" /></label>
        <label>Delete <input name="tag_mode" value="recycle" type="radio" /> </label>
        <label>Untag <input name="tag_mode" value="untag" type="radio" /></label>
        <label>Mature Content <input name="mature_toggle" value="1" type="checkbox" /></label>
        <label>Kick OP<input name="kick_OP" value="1" type="checkbox" /></label>
        <label>Ban OP <input name="ban_op" value ="1" type = "checkbox" class="trigger" func="toggle" var1="ban-form" /></label>
        <label>Permaban OP<input name="permaban_OP" value="1" type="checkbox" /></label>
        <label>Sticky/Unsticky <input name="sticky" value="1" type="checkbox" /></label>
        <label>Lock/Unlock <input name="lock" value="1" type="checkbox" /></label>
        <label>Link Color<input class="jscolor" name="link_color" value="ffffaa" /></label>
        </div>
        <div id="ban-form" style="display: none;">
            <input name="ban_data[reason]" placeholder="Ban Reason" value="" />
            <input name="ban_data[end_time]" placeholder="Ban Until (MM/DD/YYYY)" type="date" value="" />
            <label>Local Ban <input name="ban_data[fid]" value="local" type="radio" /></label>
            <label>Global Ban <input name="ban_data[fid]" value="global" type="radio" /></label>
            <label>IP Ban <input name="ban_data[type]" value="ip" type="radio" /></label>
            <label>Name Ban <input name="ban_data[type]" value="user" type="radio" /></label>
        </div>
        <?php if (get_var('mod_lockdown')) { ?>
        <div><input name="password" type="password" placeholder="Moderator Password" /></div>
        <?php } ?>
        <div id="mod-tools-submit">
        <?=uf('Moderate')?>
        </div>
    </div>
<?php } ?>
