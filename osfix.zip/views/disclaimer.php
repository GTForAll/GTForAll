<h1 class="there-are-red">Disclaimer</h1>

<div id="page-text">

<?php if ($forum['disclaimer'] == 1) { $sign = 'Submit'; ?>
The forum you are visiting may contain content you find offensive.<br /><br />

Sensitive subjects and controversial opinions can be expressed freely.<br /><br />

If you're okay with this, click the button below to verify and you will be able to view the forum and have it appear as part of your Site Feed. <br /><br />

<?php } elseif ($forum['disclaimer'] == 2) { $sign = 'I am 18 years or older'; ?>
The forum you are visiting contains adult content.<br /><br />

Please verify that you are at least 18 years old and wish to view this kind of content in your Site Feed.<br /><br />
<?php } ?>

<?php if ($data['type'] == 'ip') { ?>
NOTE: Since you aren't logged in, your preference here won't be saved permanently.<br /><br />
<?php }?>

<?=f('sign_disclaimer')?>
<input type="hidden" name="type" value="<?=$data['type']?>" />
<input type="hidden" name="fid" value="<?=$data['forum']['fid']?>" />
<?=uf($sign)?>

</div>