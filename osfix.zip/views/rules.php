<style type="text/css">
    #page {
        line-height: 1.3em;
        font-size: 1.1em;
        color: #d0d0d0;
    }
    p {

        padding: 5px;
    }


    ol {
        margin: 20px;
        padding: 0px;
    }

    li {
        margin-top: 15px;
        margin-left: 10px;
    }
</style>

<h2 class="there-are">I. Accountability</h2>

<ol type="A">
<li>Community Standards</li>
<p>Everyone using this site, including the moderation and administrative team, will be beholden to the same level of Accountability. Rule breaking will be handled appropriately for all users. Please be mindful of others and respect the following rules at all times while using this site.
</p>

<li>Administrative Team Neutrality</li>
<p>GT For All is a new site, even though it is a continuation of the GT Legacy. The administrative team would like to offer users a blank slate. Thusly, users will not be banned for past transgressions on any former iteration of GT.

<br />
<br />Additionally, users will not face discrimination from the moderation team for their politics, sex/gender, religious affiliations, etc. Users on this site will only face repercussions for breaking the GT For All rules on this site.

<br />
<br />Please leverage the Complaints Forum or official teamgtforall@gmail.com email address if you believe a moderator has overstepped and we will investigate the situation.
</p>
</ol>

<h2 class="there-are">II. Sharing Personal Information</h2>

<ol type="A">
<li>Doxxing</li>
<p>Doxxing is revealing another user's personal information, which could include their name, email address, phone number, location, or any other information that can be used to identify a user on this site. Doxxing is forbidden on GT For All and will result in a warning/ban.
</p>

<li>Sharing Your Own Information</li>
<p>You may share your own personal identifying information at your own risk on this site, but we advise that you use discretion.</p>

<li>Resharing another User's Private Information</li>
<p>Even if a user has posted any private information about themselves in the past on GT For All, you are not permitted to share that information again in the future without that user's consent.
</p>

<li>Sharing Contact Information with Permission</li>
<p>If a user has permitted you to share a specific piece of information (e.g. a Discord handle) on GT For All, you may share that specific piece of information for that user. This may only be done with that user's consent. If the moderation team is alerted that information was shared without consent, you are committing doxxing and will face a warning/ban.
</p>

<li>Bumping Threads With Private Information</li>
<p>If a thread is bumped and the OP or replies contain sensitive user information, users may contact the moderation team to redact the content.
<br />
<br />See <a style="color:lightskyblue; text-decoration-color:lightskyblue;  text-decoration: underline"  href="https://gtforall.com/thread/the_spotify_playlist_link">This Thread</a> for context.
</p>
</ol>

<h2 class="there-are">III. Respectful Language</h2>

<ol type="A">
<p><b>Please be aware that the severity of a breach of the following rules will determine the severity of the administrative team's response. In the most severe cases, the administrative team may forego issuing a warning in favor of banning the party violating these respectful language causes.
</b>
</p>

<li>Swears in Thread Titles and/or Usernames</li>
<p>To keep this site's appearance clean, the administrative team is forbidding any swear words from appearing in thread titles and/or usernames.
<br />
<br /> Additionally, inflammatory usernames are not allowed on GT For All. These include names that include derogatory or hateful language.
<br />
<br />Infrequent violations will be enforced with a suggestion that you modify the thread title/username. Repeat offenses will result in a ban.
</p>

<li>Name Calling / Personal Attacks / Flaming </li>
<p>Name calling, personal attacks, and repetitive efforts to insult users will result in a warning. Repeat offenses will result in a ban.
</p>

<li>Mockery / Baiting</li>
<p>Mocking a user or enticing them to respond via trolling or covert attacks is against the rules on GT For All and will result in a warning/ban.
</p>
<p style="color: cyan"> Acting like a provocateur (making inflammatory remarks to elicit a strong emotional response) is a flavor of baiting that will not be tolerated on GT For All, as it generates frustration and breaks down communication. This behavior will result in a warning/ban.
</p>

<li>Hate Speech</li>
<p>Hate speech is defined as verbal discrimination against someone for protected characteristics, which may include gender, sex, age, religion, etc. Hate speech is forbidden on GT For All and will result in a warning/ban.

<br />
<br />Additionally, any supremacist speech of any kind will be disallowed at GT For All. This site will not tolerate Nazism or White Supremacy and hateful ideologies will be handled with swift action from our administrative team.
</p>

<p> Please see Rule XII to learn about our new forum for sharing ideologies and opinions that may be unpopular, but do not violate this hate speech clause.
</p>

<li>Be Courteous</li>
<p>If another user has expressed discomfort with your behavior towards them in their threads, please respect their wishes.

<br />
<br />Users who feel uncomfortable with another user’s behavior towards them can file a report in the Complaints Forum or email <a style="color:lightskyblue; text-decoration-color:lightskyblue; text-decoration: underline" href="mailto:teamgtforall@gmail.com">teamgtforall@gmail.com</a> to ask that the administrative team investigate the matter privately.
</p>

<li>Bumping a Thread with Rude Content</li>
<p style="color: cyan">Bumping an inactive thread just to post something rude or condescending falls under trolling and a lack of courtesy. This is disallowed at GTFA.

<br />
<br /> Engaging in bumping threads with rude trolling content will result in a ban.
</p>
</ol>

<h2 class="there-are">IV. Staying on Topic</h2>

<p>Threads should only be posted in the forum where they belong and must comply with both the site-wide and forum-specific rules.

<br />
<br />Replies to threads must stay on topic. Do not derail another user's thread.

<br />
<br />The moderation team reserves the right to split threads if a thread naturally diverges.

<br />
<br />Repeated attempts to derail another user's thread(s) will result in a warning/ban.
</p>


<h2 class="there-are">V. Impersonation</h2>
<p>Impersonation is the act of utilizing a variant of another user's name or identity, or logging in as that user, in order to pretend to be them without their consent. This is forbidden at GT For All and offenders will be warned/banned.
</p>

<h2 class="there-are">VI. Illegal Activities</h2>
<p>Encouraging illegal activities, such as the download of pirated movies, emulated games, etc; or coercing another user to commit a crime is not permitted on GT For All.
<br />
<br />Talking about your own drug/narcotic use isn't expressly forbidden, but should be done so with the Mature Content label (when available) and the onus is on you to post in accordance with your local laws.
</p>

<h2 class="there-are">VII. Sexual / Erotic Content</h2>

<ol type="A">
<li>Cybering</li>
<p>Cybering, or sexual roleplaying with another user is forbidden at GT For All. Attempts to cyber will be tagged and violators will be warned/banned.
</p>

<li>Other Erotic Content</li>
<p>Other erotic content that does not violate the cybering clause must only be posted in the Sexuality Forum. Pornographic/explicit content should utilize the Mature Content label (when available).
</p>
</ol>

<h2 class="there-are">VIII. Blank, Test, or Repeat Posts and Threads</h2>
<p>Infrequent blank/test/repeat posts and/or threads are permissible on GT For All. The administrative team will remove them on sight.

<br />
<br />Repeated efforts to post blank/test posts will be considered spamming/flooding and will result in a warning/ban.
</p>

<h2 class="there-are">IX. Spamming / Flooding</h2>
<p>Spamming/Flooding is defined as repeatedly posting empty or unreadable threads/replies in a malicious effort to attack or crash a site. This behavior is forbidden at GT For All and violators will be warned/banned.
</p>

<h2 class="there-are">X. Warnings and Bans</h2>
<p>Rule breaking will result in your post or topic being tagged/deleted and a Warning from the administrative / moderation team.

<br />
<br />Warnings will include the reason for the content being tagged/deleted and consequences that will be faced in the event of further rule violations.

<br />
<br />Repeated violations will result in a ban. During a ban, you are not allowed to post on GT For All. Evading your ban with Proxies / VPNs will result in your content being tagged/deleted on sight and your ban will be prolonged in accordance with the administration team's discretion.
</p>

<h2 class="there-are">XI. Complaints Forum</h2>
<p>We want to hear your Complaints!
<br />
<br />The Complaints Forum can be used to bring administrative attention to rule-breaking content or a problem with the site. Complaints should be restricted to the complaints forum. Please be sure to avoid violating side-wide rules when filing a complaint.
<br />
<br />In the event that you are uncomfortable filing a public complaint, you may email the administrator directly at <a style="color:lightskyblue; text-decoration-color:lightskyblue; text-decoration: underline" href="mailto:teamgtforall@gmail.com">teamgtforall@gmail.com</a>.
<br />
<br />You will never be penalized for reporting an issue, so please leverage Complaints or the official email as needed.
</p>

<h2 class="there-are">XII. Hot Takes Forum</h2>
<p>The Hot Takes Forum will allow discussions about ideologies and opinions that may cause heated debates and interesting conversations, but do not violate a hate speech clause, such as MGTOW, Feminism, ACAB, BLM, and other ideologies (this list is not comprehensive).

<br />
<br />Questionable content that does not infringe on any of the above rules may be posted in this forum and will be monitored closely by the administrative team. Abuse of this forum will result in a warning/ban.
</p>

<h2 class="there-are">XIII. Mature Content Flag</h2>
<p>This section is to address the new Mature Content Flag.
<br />
<br />Please use this flag to mark your threads/posts that contain swears or overt sexual content. Additionally, threads / posts about mature content in Rated R movies or Mature video games should also be flagged Mature. (e.g., talking about a mature game doesn't necessarily require it, unless it's a post about a sexually explicit moment in gameplay or a link to a swear-heavy moment.
<br />
<br />For the time being, we recognize that is a new feature, so it will take some getting used to. Mods will be lenient and flag the content for you if you forget and let you know they have.
<br />
<br /> We will re-evaluate this rule in the future after it's been around for a while.
<br />
</p>

<h2 class="there-are">XIV. GT For All Official Platforms</h2>
<p>In addition to the site, GT For All has several official platforms that you may interact with. Please adhere to the relevant above rules when interacting with these platforms, too. Violations of rules when interacting with these platforms will result in you being blocked on the platform where the transgression occurred. In extreme cases, a ban on one platform may result in an implicit warning or worse on another, even if not explicitly stated by the moderation team.
</p>

<ol type="A">
<li>The official GT For All Discord: <a style="color:lightskyblue; text-decoration-color:lightskyblue; text-decoration: underline" href="https://discord.gg/kty84UeaBE">Discord Link</a></li>
<li>The official GT For All Facebook: <a style="color:lightskyblue; text-decoration-color:lightskyblue; text-decoration: underline" href="https://www.facebook.com/teamgtforall">Facebook Link</a></li>
<li>The official email: <a style="color:lightskyblue; text-decoration-color:lightskyblue; text-decoration: underline" href="mailto:teamgtforall@gmail.com">teamgtforall@gmail.com</a></li>
</ol>

<h2 class="there-are">XV. Have Fun!</h2>
<p style="text-align:center;">We welcome you to GT For All! We're excited to have you all here!
</p>
<p style="text-align:center;">Owner: <b>¤¤♅êîrÐ Øccu®＠nç€¤¤</b>
<br />
<br / style="text-align:center;">Global Mod: <b>¤LðŗÐ Ð£ŋįd@¤</b>
</p>
