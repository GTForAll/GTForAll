<div class="content">

<style type="text/css">
    body { font-family: Verdana;  color: #efefef; }

    input:not([type=submit]):not([type=button]),textarea,select { font-size: 1.2em; background-color: #000; color: #fff; border: 1px solid #555; box-shadow: 0px 0px 10px #000; padding: 10px; border-radius: 6px; }

    .reghelp {
        display: inline-block; 
        min-height: 120px;
        vertical-align: top;
        line-height: 1.3em;
        font-size: 1em;
    }
</style>

<?=f('login')?>
<h1>
    <?php if ($_GET['cont']) { ?>
    Login or Register to continue
    <?php } else {  ?>
    User Login 
    <?php } ?>
</h1>

<table class="cp">
<tr><td>Username</td><td><input name="user" value="<?=$user?>" size="60" /></td></tr>
<tr><td>Password</td><td><input name="pass" type="password" size="60" /></td></tr>
</table>


<?=uf()?>


<div style="margin-top: 20px; margin-bottom: -10px;">

<!--
<div class="help reghelp">
    Forgotten password? <br /><br />
    <div class="list">
        <a href="newpost.php?forum=Complaints&forgot_account=1">Help! I forgot my username or password </a>
    </div>
</div>-->

<div class="help reghelp">
    Need an account? <br /><br />
    <div class="list">
    <a href="/register">Register</a>
    </div>
</div>
</div>
