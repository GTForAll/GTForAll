<?php if (!page('no_footer')) { ?>

</div>
</div>
<!-- off #page -->

<style type="text/css">
    #footer-left a, #footer-right a {
        text-decoration: none;
        padding: 5px;
        font-size: 1.2em;
    }

    #footer-creds td {
        padding-top: 10px;
    }
</style>
<footer>
<table>

<tr style="font-size: 0.9em;">
    <td id="footer-left">
        <a href="/rules"><?=ic('gavel')?> Rules</a>
    </td>

    <td rowspan="2"></td>
    <td></td>
    <td id="footer-right">
        <a href="/social_media"><?=ic('campaign')?> Social Media</a>
        <?php /* <a href="https://discord.gg/w4K4Gj7HHw">Hell Discord</a> */ ?>
    </td>
</tr>

<tr id="footer-creds">
    <td><span class="y">GT For All</span> &copy; 2021-<?=date('Y')?> Weird Occurance
    <br /> Special Thanks to Xhin for Code Assistance!</td>
    <td><span class="y">GTX0</span> &copy; 2009-<?=date('Y')?>
    <br /> The legacy lives on, Xhin</td>
    <td><span class="y">GameTalk</span> &copy; 1999-2008 lives on
    <br /> Thank you for the memories, Mike Pooler</td>
</tr>

<tr>
    <td colspan="4" class="memoriam">You are not forgotten:
        Kevin,
        Liane,
        Norma,
        Jason, and
        Garrett
    </td>
</tr>

<table>

<div id="bottom-adbox">
<!--<script type="text/javascript">
google_ad_client = "ca-pub-6506690139225292";
/* Bottom Ad */
google_ad_slot = "9085255225";
google_ad_width = 728;
google_ad_height = 90;
</script>
<script type="text/javascript"
src="https://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>-->
</div>

</footer>

<style type="text/css">
    /* Not the best solution for sure, but w/e */
   a.confirm-color {
        color: #faa !important;
   }
</style>

<?php } ?>

<div id="debug"></div>
</div><!-- off #content -->
<?php foreach ($js?:Array() AS $src) {
    if (!has($src,'http')) { $src .= '?v='.rand(1,999999999); }
?>
    <script type="text/JavaScript" src="<?=$src?>"></script>
<?php } ?>

<script type="text/JavaScript">

    <?php foreach ($js_vars?:Array() AS $key => $val) { ?>
        var _<?=$key?> = <?=$val?>;
    <?php } ?>

    <?php foreach ($js_exec?:Array() AS $js) { ?>
        window['<?=$js['obj']?>']['<?=$js['func']?>'](<?=json_encode($js['vars'])?>);
    <?php } ?>

</script>
</body>
