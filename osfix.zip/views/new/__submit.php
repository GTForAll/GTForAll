
<div id="quickreply-submit-wrapper">
<?=uf($data['submit_name'])?>
</div>
