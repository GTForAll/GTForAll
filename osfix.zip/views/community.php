<style type="text/css">
    #page {
        line-height: 1.3em;
        font-size: 1.1em;
        color: #d0d0d0;
    }
    p {
        background-color: #111; 
        padding: 20px;
        border: 1px solid #333;
    }
    
    
    ol {
        margin: 20px;
        padding: 0px;
    }
    
    li {
        margin-top: 15px;
        margin-left: 10px;
    }
</style>
<h2 class="there-are">GTX0 is Community-run</h2>
