<style type="text/css">
    #docs-list {
        text-align: center;
        background-color: #222;
        box-shadow: 0px 0px 10px #000 inset;
        padding: 10px 0px;
    }

    #docs-list a {
        padding: 7px;
        font-size: 0.9em;
        width: auto;
        border-radius: 7px;
    }

    #modded-by {
        background-color: #111;
        padding: 15px 0px;
        text-align: center;
        box-shadow: 0px 0px 5px #000 inset;
    }

    #modded-by-title {
        font-size: 1.2em;
        margin-right: 20px;
        padding: 10px;
    }

    #modded-by-list {

    }

    #modded-by-list > span {
        background-color: #000;
        border: 1px solid #333;
        padding: 8px;
        margin-right: 10px;
    }
</style>
<h1 class="there-are"><a href="/forum/<?=$data['slug']?>"><?=$data['name']?></a></h1>

<?php if ($data['mods']) { ?>
<div id="modded-by"><span id="modded-by-title">Moderated by:</span><span id="modded-by-list">
    <?php foreach ($data['mods'] as $mod) { ?>
        <span><?=$mod['username']?></span>
    <?php } ?>
</span>
</div>
<?php } ?>

<?php if ($data['docs']) { ?>
    <div class="list" id="docs-list">
        <?php foreach ($data['docs']?:Array() AS $doc) { ?>
            <a href="/document/<?=$doc['docid']?>"><?=$doc['title']?></a>
        <?php } ?>
    </div>
    <?php } ?>
<?php if ($data['description']) { ?><div class="quote forum-desc" style="text-align:center;"><?=parse($data['description'])?></div><?php } ?>
