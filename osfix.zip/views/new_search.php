<style type="text/css">

    #search-top {  
        position: relative;
        padding: 10px;
        background-color: #444;
        margin-bottom: 20px;
        margin-left: 10px;
        box-shadow: 0px 0px 10px #000 inset;
    }

    .search-block {
        background-color: #272727;
        padding: 5px;
        padding-left: 0px;
        margin-right: 25px;
        border: 1px solid #444;
    }
    
    .search-key {
        background-color: #033c58;
        padding: 5px;
        margin-right: 10px;
    }
    
    .search-val {
    }
    
    .search-wild {
        color: #ff7;
    }
</style>
<div id="search-top"><?=unsafe($data['say'])?></div>
<?=f('new_search')?>
<?=uf('New Search')?>