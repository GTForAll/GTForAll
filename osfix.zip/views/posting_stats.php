<style type="text/css">
    #username { color: #fc0; }
    #ps-search input[type=submit] {
        display: inline-block;
        vertical-align: top;
    }
    
    #ps-search input[type=text] {
        min-width: 400px;
        margin-right: 10px;
    }
    
    #ps-search input {
        padding: 10px !important;
        font-size: 1em !important;
    }
    
</style>
<h1 class="there-are">Posting Stats for <span id="username"><?=$data['user']?></span></h1>

<table class="tm" id="ps-search"><tr><td>Posting Stats for: </td><td><?=f('get_posting_stats')?><input type="text" name="user" value="<?=$data['user']?>" /><?=uf('Search')?></td></tr></table>

<table class="tm"><tr><th>Forum</th><th>Threads</th><th>Posts</th></tr>
    <?php $t_t = 0; $t_p = 0; ?>
    <?php foreach ($data['stats']?:Array() AS $stat) { $t_t += $stat['threads']; $t_p += $stat['posts']; ?>
    <tr>
        <td><a href="/forum/<?=$stat['forum_slug']?>"><?=$stat['forum_name']?></a></td>
        <td><?=$stat['threads']?></td>
        <td><?=$stat['posts']?></td>
    </tr>
    <?php } ?>
    <tr><th>Total</th><td><?=$t_t?></td><td><?=$t_p?></td></tr>
</table>