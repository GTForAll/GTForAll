<h1>Accounts</h1>
<style type="text/css">
    .list a {
        width: auto !important;
    }
</style>
<div class="list">
<?php $letters = Array('a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','newest_50'); 
foreach ($letters as $letter)
{
    ?>
    <a href="/admins/accounts/<?=$letter?>"><?=deslug($letter)?></a>
<?php } ?>
</div>

<?=f('admin_accounts')?>
<table class="cp">
    <tr><th>Account Username</th><th>Primary Username</th><th>Banned</th><th>Ban/Unban</th></tr>
    <?php foreach ($data['accounts']?:Array() AS $account) { ?>
        <tr>
            <?php if ($account['username'] != $account['primary_username']) { ?>
            <td><?=$account['username']?></td>
            <td><?=$account['primary_username']?></td>
            <?php } else { ?>
            <td colspan="2" style="text-align: left;"><?=$account['username']?></td>
            <?php } ?>
            <td><?php if ($account['banned']) { ?><div class="error">YES</div><?php } else { ?><div class="conf">No</div><?php } ?></td>
            <td>
                <label>Ban/Unban
                <input type="checkbox" name="ban[]" value="<?=$account['uid']?>" /></label>
            </td>
        </tr>
    <?php } ?>
</table>
<?=uf()?>