<a href="/feed" class="back">&lt;-- Back to Site Feed</a>
<?php

$panels = Array();

$panels = array_merge($panels,Array(
    Array('/my/settings', 'Account Settings', Array(
        'Change Account username',
        'Change Password'
    )),

    Array('/posting_stats','Posting Stats', Array(
        'See how many threads and posts you\'ve made across the site',
        'See this information for other users as well'
    )),

    Array('/my/site_settings', 'Settings', Array(
      'Change default handling for Mature posts and threads'
    ))

    /*
    Array('/my/mycard', 'MyCard', Array(
        'Change Display picture'
    )),*/

    // TODO: ASAP to all of the three below.
    /*
    Array('/my/blocklist','User Block List',Array(
        'Block users from showing up on the site',
        'Set them to either be toggle-viewable or hide them entirely'
    )),*/

));


if (iam('mod'))
{
    $panels = array_merge($panels,Array(

      Array('/admins/permabans', 'Permabans', Array(
          'See all permabans',
          'Remove them'
      ))
    ));
}







if (iam('white'))
{
    $panels = array_merge($panels,Array(


        Array('/admins/accounts', 'Accounts', Array(
            'Ban Accounts',
            'Will eventually be used for other account stuff as well.'
        )),

        Array('/admins/lockdown', 'Lockdown', Array(
            'Mod lockdown',
            'Accounts Required',
            'Registrations Locked',
            'Reply Time Freeze',
            'Nuclear Option'
        )),

        Array('/admins/posting_filters', 'Posting Filters', Array(
            'Restrict the way posts and threads can be made'
        )),

        Array('/admins/filter_queue', 'Filter Queue', Array(
            'Approve threads and posts that get caught by the filters',
            'Alternately, reject them'
        )),


        Array('/admins/filter_30', 'Filter #30', Array(
            'Thread-specific registration-only lockdown',
            'Also allows whitelisting exceptions to this'
        )),

        Array('/admins/filter_31', 'Filter #31 (Shadowban)', Array(
            'Ban people without them (or their friends) knowing about it'
        )),

        Array('/admins/filter_33', 'Filter #33 (Autotagger)', Array(
            'Customize Autotagger settings'
        ))

        /*
        Array('/admins/accounts', 'Account Editor', Array(
            'WIP'
        )),
        Array('/admins/mod_editor', 'Mod Editor', Array(
            'WIP'
        )),
        Array('/admins/change_user_password', 'Change User Password', Array(
            'Change the password of a posting name (outside of the accounts system)'
        ))*/
    ));
}

?>

<div id="content">
    <h1 style="background-color: #222; box-shadow: 0px 0px 10px #000 inset; border: 0px;">Welcome Home, <?=my('user')?>!</h1>

    <h2>User CP Panels</h2>

    <div class="panels">
    <?php foreach ($panels AS $i => $row) {
        $color = $colors[$i%8];
        $style = '1b2161';
        $bg = '/images/there_are_'.$color.'.png';
    ?>
        <a href="<?=$row[0]?>">
            <h2 style="background-image: url('<?=$bg?>'); <?=$style?>"><?=$row[1]?></h2>
            <ul>
                <?php foreach ($row[2]?:Array() AS $unit) { ?><li><?=$unit?></li><?php } ?>
            </ul>
        </a>
    <?php } ?>
    </div>
</div>
