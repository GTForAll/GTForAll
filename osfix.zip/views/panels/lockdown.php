<style type="text/css">
    .warning {
        font-size: 1.5em;
        color: #faa;
        background-color: #111;
        padding: 10px;
    }
</style>
<h1>Lockdown</h1>


<div class="warning">WARNING: Any changes made here will change the site for everyone. <br />Use with caution and only under 
dire circumstances. <br />See the guide in the admin forum until I make this panel more intuitive.</div>

<?=f('admin_vars')?>
<table class="cp">
    <tr><th>Setting</th><th>Value</th></tr>
    <?php foreach ($data['vars'] as $name => $value) { ?>
    <tr>
        <td><?=deslug($name)?></td>
        <td><input name="<?=$name?>" value="<?=$value?>" /></td>
    </tr>
    <?php } ?>
</table>
<?=uf()?>