<h1>Filter #31</h1>

<?=enable_var('filter_31')?>

<h2>Add Entry</h2>
<?=f('admin_f31_add')?>
<table class="cp">
    <tr><td>Field</td><td><?=fill_select('field',deslug_all(Array('ip','host')),'ip')?></td></tr>
    <tr><td>Type</td><td><?=fill_select('type',deslug_all(Array('is','contains')),'is')?></td></tr>
    <tr><td>Value</td><td><input name="value" /></td></tr>
</table>
<?=uf()?>

<?php if ($data['filters']) { ?>
<h2>Filters</h2>
<?=f('admin_f31_edit')?>
<table class="cp">
    <tr><th>Field</th><th>Type</th><th>Value</th><th>Remove</th></tr>
    <?php foreach ($data['filters'] as $row) { ?>
    <tr>
        <td><?=deslug($row['field'])?></td>
        <td><?=deslug($row['type'])?></td>
        <td><?=$row['value']?></td>
        <td><label>Remove<input type="checkbox" name="remove[]" value="<?=$row['id']?>" /></label></td>
    </tr>
    <?php } ?>
</table>
<?=uf()?>
<?php } ?>

<h2>Add whitelist entry</h2>
<?=f('admin_f31_whitelist_add')?>
<table class="cp">
    <tr><td>Field</td><td><?=fill_select('field',deslug_all(Array('ip','host')),'ip')?></td></tr>
    <tr><td>Type</td><td><?=fill_select('type',deslug_all(Array('is','contains')),'is')?></td></tr>
    <tr><td>Value</td><td><input name="value" /></td></tr>
</table>
<?=uf()?>

<?php if ($data['whitelist']) { ?>
<h2>Filters</h2>
<?=f('admin_f31_whitelist_edit')?>
<table class="cp">
    <tr><th>Field</th><th>Type</th><th>Value</th><th>Remove</th></tr>
    <?php foreach ($data['whitelist'] as $row) { ?>
    <tr>
        <td><?=deslug($row['field'])?></td>
        <td><?=deslug($row['type'])?></td>
        <td><?=$row['value']?></td>
        <td><label>Remove<input type="checkbox" name="remove[]" value="<?=$row['id']?>" /></label></td>
    </tr>
    <?php } ?>
</table>
<?=uf()?>
<?php } ?>