<style type="text/css">
    #enabler > div {
        display: inline-block;
        vertical-align: middle;
        margin-left: 15px;
    }
</style>

<div id="enabler">
    <div>
    <?=enable_var('autotagger')?>
    </div>

    <div>
    <?php

    $arr = Array('seconds' => 1, 'minutes' => 60, 'hours' => 3600);
    $buttons = Array();
    foreach ($arr as $key => $val)
    {
        $buttons[] = Array(
            'name' => deslug($key),
            'obj' => 'input_math',
            'func' => 'multiply',
            'var1' => '#self',
            'var2' => $val,
        );
    }

    echo set_vars('Autotagger Settings',Array(
        'autotagger_min' => 'Minimum Duration',
        'autotagger_max' => 'Maximum Duration'
    ),$buttons)

    ?>
  </div>
</div>

<?=f('admin_f33_add')?>
<h2>Add Filter</h2>
<table class="cp">
<tr><td>Field</td><td><?=fill_select('field',deslug_all(Array('ip','host','user')),'ip')?></td></tr>
<tr><td>Type</td><td><?=fill_select('type',deslug_all(Array('is','contains')),'is')?></td></tr>
<tr><td>Value</td><td><input name="value" /></td></tr>
</table>
<?=uf()?>

<?php if ($data) { ?>

<h2>Edit Entries</h2>
<?=f('admin_f33_edit')?>
<table class="cp">
<tr><th>Entry</th><th>Delete</th></tr>
<?php foreach ($data?:Array() as $row) { ?>
    <tr>
        <td><?=$row['field'].' '.$row['type'].' <span class="y">'.$row['value']?></span></td>
        <td><label><input type="checkbox" name="remove[]" value="<?=$row['id']?>" />Remove</label></td>
    </tr>
<?php } ?>
</table>
<?=uf()?>

<?php } ?>
