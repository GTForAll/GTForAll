var toggler = {
		remote: function(start,parent,find)
		{
				var el = start.closest(parent).find(find);
				el.slideToggle();
		}
};

var input_math = {
		__el: {},
		__get: function(el) {
				this.__el = el.closest('td').find('input[type!=button]');
				return this.__el.val();
		},
		__set: function(val) {
				this.__el.val(val);
		},
		// --
		multiply: function(el,amt) {
				var val = this.__get(el);
				val *= amt;
				this.__set(val);
		}
};

function safe_reload() {
	drafts.save();
	location.reload();
}

var alerts = {
	archive: function(alertid) {
		ajax.push('archive_alert',{ alertid: alertid },function() {
			nav.render();
		});
	}
};

var mature = {
    show_thread: function(el) {
			el.parent().find('.mature-show').fadeIn();
			el.hide();
    },
    show_post: function(el) {
			el.parent().find('.hide-message').fadeIn();
			el.hide();
    }
};

var scroll = {
	to_post: function(pid) {

		var loc = $(".post-"+pid).offset().top;
		loc -= $("header").height();

	    $([document.documentElement, document.body]).animate({
        	scrollTop: loc
    	}, 1000);
	}
};

var ajax = {
	push: function(url,data,success) {
		data.ajax = true;
		$.ajax({
			url: '/ajax/'+url,
			type: 'POST',
			data: data,
			success: success
		});
	},
	html_push: function(url,data,success) {
		data.ajax = true;
		$.ajax({
			url: '/ajax_html/'+url,
			type: 'POST',
			data: data,
			success: success
		});
	},
	get_html: function(el,url,data) {
		if (!data) { data = {}; }
		data.ajax = true;
		$.ajax({
			url: '/ajax_html/'+url,
			type: 'POST',
			data: data,
			success: function(resp) {
				$(el).html(resp);
				bind_buttons();
			}
		});
	}
};

var settings = {
	set: function(key,value){
		var data = {};
		data[key] = value;
		ajax.push('settings',data,function() { });
	}
};

var nav = {
	func: '',
	open: function(el) {
		this.func = el.attr('ajax_html');
		$("#uptop").show();
		$("#uptop").html('Loading...');
		this.render();
	},
	render: function() {
		var data = {};
		if (typeof _my_fid != 'undefined') { data['my_fid'] = _my_fid; }
		ajax.get_html('#uptop',this.func,data);
	}
};

var plugins = {
	ajax: function(type,name,redir) {
		if (typeof _my_uid == 'undefined') { return login_first(); }
		ajax.push('plugins',{ type: type, name: name },function(e) {
			if (redir)
			{
				window.location.href = redir;
				return;
			}
			safe_reload();
		});
	},
	enable: function(name,redir) {
		this.ajax('enable',name,redir);
	},
	disable: function(name,redir) {
		this.ajax('disable',name,redir);
	},
	settings_link: function(id) {
		$("#"+id).slideToggle();
	}
};

var edit = {
	link: function(el) {
		var td = el.closest('.td');
		td.find('.posts-message').hide();
		td.find('.posts-edit').show();
	},
	edit_thread: function() {
		$("#thread-op").hide();
		$("#thread-edit").show();
	},
	send_data: function(el,title) {

		var data = {
			message: el.find('textarea').val(),
			pid: el.find('.posts-edit-pid').val(),
			pass: el.find('.posts-edit-password').val()
		};

		if (title)
		{
			data['edit_title'] = true;
			data['title'] = $("#posts-edit-title").val();
			data['tid'] = $("#posts-edit-tid").val();
		}

		ajax.html_push('edit_post',data,function(e) {
			//alert(JSON.stringify(e));
			var par = el.parent();
			par.find('.posts-edit').hide();
			par.find('.posts-message').html(e).fadeIn();
			if (data['edit_title'])
			{
				$("#thread-title").html(data['title']);
			}
			bind_buttons();
			bind_links();
		});
	},
	save: function(el) {
		var td = el.closest('.td');
		el = td.find('.posts-edit');

		this.send_data(el);
	},
	save_thread: function() {
		this.send_data($('#thread-edit'),true);
	},
	try_again: function(el) {
		var message = el.parent().find('.edit-passbad').val();
		el.parent().parent().find('.posts-message').hide();
		el.parent().parent().find('.posts-edit').show();
		el.parent().find('.posts-edit textarea').val(message);
	}
};

var drafts = {
	save: function() {

		if (!$("#qr-message")) { return; }

		var data = {
			type: $("#draft-type").val(),
			id: $("#draft-id").val(),
			message: $("#qr-message").val()
		};


		ajax.push('save_draft',data,function(e) {
			$("#save-draft-status").show().html('Draft Saved!').fadeOut(5000);
		});
	}
};

var preview = {
	preview: function() {
		var val = $("#qr-message").val();
		var m = $("#qr-message");
		m.hide();
		$("#qr-preview").show();
		$("#qr-preview").css('width',m.width()).css('height',m.height());
		$("#preview-button").attr('func','hide').html('Return');

		ajax.push('preview',{ message: val},function(e) {
			e = JSON.parse(e);
			$("#qr-preview").html(e);
		});
	},
	hide: function() {
		$("#qr-preview").hide();
		$("#qr-message").show();
		$("#preview-button").attr('func','preview').html('Preview');
	}
};


var mark = {
	last: {},
	down: function() {
		if (!obj_size(this.last)) { return; }
		this.last.closest('.tr,tr').nextAll().find('input.mark').trigger('click');
	}
};

var dupe = {
	autodupe: function(el) {
		var amt = parseInt(el.attr('dupe_amt'));
		if (!amt) { amt = 1; }

		var old = el.parent().find('.dupe-this');
		old.clone().insertAfter(old).val('');
		old.removeClass('dupe-this');
		amt++;
		el.attr('dupe_amt',amt);
		if (amt == parseInt(el.attr('dupe_max')))
		{
			el.hide();

		}
	}
};

var user_block = {
	block: function(hash,pid) {
		$(".user-"+hash).fadeOut();
		$(".blocked-"+hash).show();
		ajax.push('block_user',{ pid: pid });
	},
	unblock: function(hash,pid) {
		$(".user-"+hash).show();
		$(".blocked-"+hash).hide();
		ajax.push('unblock_user',{pid: pid });
	},
	show: function(el,index) {
		el.closest('.tr-blocked').hide();
		$("#tr-"+index).fadeIn();
	},
	show_thread: function(tid) {
		$("#thread-blocked-"+tid).hide();
		$("#thread-"+tid).fadeIn();
	},
	block_thread: function(tid) {
		ajax.push('block_thread',{ tid: tid },function(e) {
			window.location.href = '/feed';
		});
	},
	unblock_thread: function(tid){
		ajax.push('unblock_thread',{tid: tid}, function(e) {
			window.location.reload(true);
		});
	}
};
