
var pages = {
	on_page: 1,
	// TODO: Might want to generalize these if I use them more often.
	disable: function() {
		plugins.disable('post_pagination');
	},
	save_settings: function() {
		settings.set('pagination_amt',$("#post-pages-amt").val());
		safe_reload();
	},
	// -------------
	only: function(page) {
		this.set_page(page);
		
		$("#thread-replies .tr").hide();
		$(".page-"+page).show();
				
		this.common();
	},
	set_page: function(page) {
		this.on_page = page;
		page = parseInt(page);
		
		$(".page-link-hidable").hide();
		$("#page-link-"+(page-1)).show();
		
		$("#page-link-"+(page)).show();
		$("#page-link-"+(page)).addClass('current-page');
		
		$("#page-link-"+(page+1)).show();
		
		$(".dots").hide();
		var chunk1 = parseInt($(".page-chunk-1").attr('page'));
		var chunk2 = parseInt($(".page-chunk-2").attr('page'));
		
		if ((page-1) > chunk1) { $("#dots-1").show(); }
		if ((page+1) < chunk2) { $("#dots-2").show(); }		
		
		$("#prev-page").show();
		if (page == 1)
		{
			$("#prev-page").hide();
		}
	},
	common: function() {
		var page = this.on_page;

		ajax.push('set_read_pid',{ tid: _tid, page: page },function(e) { 
			//say(e);
		}); 
		
		$("#bottom-curr-page").html(page);
		
		this.fix_bottom_nav();
	},
	fix_bottom_nav: function() {
		$("#bottom-navigation").show();
		if (this.on_page == _last_page)
		{
			$("#bottom-navigation").hide();
		}
	},
	all: function() {
		$(".posts-tr").show();
		this.on_page = _last_page;
		this.common();
	},
	load_prev: function() {
		var prev = this.on_page-1;
		$(".page-"+prev).show();
		
		var off = $($(".page-"+this.on_page)[0]).offset();
		$(window).scrollTop(off.top-75);
		
		this.set_page(prev);
		this.fix_bottom_nav();
	},
	load_next: function() {
		this.on_page = parseInt(this.on_page)+1;
		$(".page-"+this.on_page).show();
		this.common();
	},
	load_rest: function() {
		var page = parseInt(this.on_page)+1;
		for (var i = page; i <= _last_page; i++)
		{
			$(".page-"+i).show();
		}
		this.on_page = _last_page;
		this.common();
	}
};

$("#post-pages-bottom a").click(function(e) { 
	e.preventDefault();
	window['pages'][$(this).attr('action')]();
});

$("#post-pages-links a").click(function(e) {
	e.preventDefault();
	if ($(this).attr('obj')) { return; }
	$(".current-page").removeClass('current-page');
	$(this).addClass('current-page');
	
	var off = $("#there-are-replies").offset();
	var h = $("#there-are-replies").height();
	$(window).scrollTop(off.top-75);
	
	var page = $(this).attr('page');
	if (page == 'all') { return pages.all(); }
	if (page == 'prev') { $(this).removeClass('current-page'); return pages.load_prev(); }
	pages.only(page);
});

$(document).ready(function() {
	if (typeof _on_page != 'undefined')
	{
		$("#bottom-curr-page").html(_on_page);
		$("#bottom-total-pages").html(_last_page);
		pages.on_page = _on_page;
		pages.fix_bottom_nav();
	}
});