function say(d)
{
    alert(JSON.stringify(d));
}

function obj_pick(obj) {
    var arr = Object.keys(obj);
    
    var key = Math.floor(Math.random() * (arr.length));
    
    key = arr[key];
    return obj[key];
}

_drop = {};
function stop() {
    clearInterval(_drop);
}

var pieces_data = {
    L: [
        [
            [0,0,1],
            [2,2,2]
        ],
        [        
            [1,0],
            [1,0],
            [2,2]
        ],
        [
            [1,2,2],
            [2,0,0]
        ],
        [
            [2,1],
            [0,1],
            [0,2],
        ],
        
    ],
    J: [
        [
            [1,0,0],
            [2,2,2]
        ],
        [
            [1,2],
            [1,0],
            [2,0],
        ],
        [
            [2,2,1],
            [0,0,2]
        ],
        [
            [0,1],
            [0,1],
            [2,2]
        ],
    ],
    O: [
        [
            [1,1],
            [2,2]
        ]
    ],
    I: [
        [
            [2,2,2,2]
        ],
        [
            [1],
            [1],
            [1],
            [2]
        ],
    ],
    T: [
        [
            [0,1,0],
            [2,2,2]
        ],
        [
            [1,0],
            [1,2],
            [2,0]
        ],
        [
            [2,1,2],
            [0,2,0]
        ],
        [
            [0,1],
            [2,1],
            [0,2]
        ],
    ],
    S: [
        [
            [0,1,2],
            [2,2,0]
        ],
        [
            [1,0],
            [2,1],
            [0,2]
        ]
    ],
    Z: [
        [
            [2,1,0],
            [0,2,2]
        ],
        [
            [0,1],
            [1,2],
            [2,0]
        ]
    ]
};

var grid = {
	el: {},
    data: [],
    width: 0,
    height: 0,
    graphics: [' ','█','▓'],
    init: function() {
        this.data = [];
        
        for (var y = 0; y < this.height; y++)
        {
            this.data[y] = [];
            for (var x = 0; x < this.width; x++)
            {
                this.data[y][x] = this.graphics[0];
            }
        }
        this.render();
    },
    add: function(coord,sym) {
        if (!this.data[coord[0]]) { return; }
        if (!this.data[coord[0]][coord[1]]) { return; }
        this.data[coord[0]][coord[1]] = sym;
    },
    remove: function(coord) { 
        this.add(coord,this.graphics[0]);
    },
    mode: 'start',
    render: function() {
                
        var sidebar = [];
        var piece = pieces.next_piece[0];
        sidebar.push('NEXT');
        var row = '';
        for (var y = 0; y < piece.length; y++)
        {
            row = '';
            for (var x = 0; x < piece[y].length; x++)
            {
                if (piece[y][x])
                {
                    row += this.graphics[1];
                }
                else
                {
                    row += this.graphics[0];
                }
            }
            sidebar.push(row);
        }
        if (piece.length == 1)
        {
            sidebar.push('');
        }
        
        sidebar = sidebar.concat(this['mode_'+this.mode]());
        
        var txt = '';
        for (var y = 0; y < this.height; y++)
        {
            txt += '\n▐';
            for (var x = 0; x < this.width; x++)
            {
                txt += this.data[y][x];
            }
            txt += '▌'; 
            if (sidebar[y])
            {
                txt += '  '+sidebar[y];
            }
        }
        txt += '\n ';
        for (var x = 0; x < this.width; x++)
        {
            txt += '▀';
        }
        
        this.el.value = txt;
    },
    mode_start: function() {
        return [
            'ARROW KEYS TO PLAY', 
            'SPACE DROPS',
            'ESC TO PAUSE/RESET',
            'ENTER TO RESIZE',
            'BACKSPACE TO STOP PLAYING'
        ];
    },
    mode_play: function() {
        return [
            'LEVEL: '+game.level,
            'LINES: '+lines.lines,
            'SCORE: '+game.score
        ];
    },
    mode_pause: function() {
        return [
            'PAUSED',
            'ESC TO RESUME',
            'SPACE TO RESET'
        ];
    },
    mode_resize: function() {
        return [
            'ARROW KEYS TO RESIZE',
            'ENTER TO CONFIRM'
        ];
    },
    mode_game_over: function() {
        return [
            'GAME OVER',
            'SCORE: '+game.score,
            'ESC TO REPLAY'
        ];
    }
};

var lines = {
    lines: 0,
    lines_overflow: 0,
    lines_overflow_max: 10,
    add_piece: function() {
        var coord = [];
        for (var i in pieces.tagged)
        {
            coord = pieces.tagged[i];
            grid.add(coord,grid.graphics[2]);
        }
        pieces.tagged = [];
        this.check_lines();
    },
    check_lines: function() {
        var sum = 0;
        var total_cleared = 0;
        for (var y = 0; y < grid.data.length; y++)    
        {
            sum = 0;
            for (var x = 0; x < grid.data[y].length; x++)
            {
                if (grid.data[y][x] == grid.graphics[2])
                {
                    sum++;
                }
            }
            if (sum == grid.width)
            {
                total_cleared++;
                this.lines_overflow++;
                this.lines++;
                this.clear_row(y);
                this.gravity(y);
            }
        }
        if (this.lines_overflow >= this.lines_overflow_max)
        {
            this.lines_overflow %= this.lines_overflow_max;
            game.next_level();
        }
        game.line_score(total_cleared);
    },
    clear_row: function(y) {
        var coord = [];
        for (var x = 0; x < grid.width; x++)
        {
            grid.remove([y,x]);
        }
    },
    gravity: function(ymax) {
        var row = [];
        for (var y = ymax-1; y >= 0; y--)
        {
            for (var x = 0; x < grid.width; x++)
            {
                grid.add([y+1,x],grid.data[y][x]);
            }
        }
        
        this.clear_row(0);
    }
};

var pieces = {
    piece: [],
    rot: 0,
    top: 0,
    left: 0,
    tagged: [],
    next_piece: [],
    new_piece: function() {
        this.piece = this.next_piece;
        this.next_piece = obj_pick(pieces_data);
        this.rot = 0;
        this.top = 0;
        this.left = Math.floor((grid.width/2));
        this.left -= Math.floor(this.piece.length/2);
        
        this.render();
    },
    reset_tagged: function() {
        for (var i in this.tagged)
        {
            grid.remove(this.tagged[i]);
        }
        this.tagged = [];
    },
    render: function() {
        var data = this.piece[this.rot];
        this.reset_tagged();
        var coord = [];
        for (var y = 0; y < data.length; y++)
        {
            for (var x = 0; x < data[y].length; x++)
            {
                if (!data[y][x]) { continue; }
                coord = [y+this.top , x+this.left];
                if ((grid.data[coord[0]][coord[1]] == grid.graphics[2]) && this.top == 0) { return game.over(); }
                this.tagged.push(coord);
                grid.add(coord,grid.graphics[1]);
            }
        }
        grid.render();
    },
    // ----
    move: function(amt) {
        if (this.check_side(amt)) { return; }
        this.left += amt;
    },
    fast_drop: function() {
        var last_top = this.top;
        var status = false;
        for (var y = 0; y < grid.height; y++)   
        {
            status = this.slow_drop();
            if (status) { break; }
            pieces.render(); 
        }
        game.score_drop(last_top);
    },
    slow_drop: function() {
        if (this.check_blocked() || this.check_end())
        {
            this.next();
            return true;
        }
        this.top++;
    },
    rotate: function() {
        var rot = (this.rot+1)%this.piece.length;
        var next_piece = this.piece[rot];
        
        for (var y = 0; y < next_piece.length; y++)
        {
            for (var x = 0; x < next_piece[y].length; x++)
            {
                if (!next_piece[y][x]) { continue; }
                check = [y+this.top,x+this.left];
                if (!grid.data[check[0]]) { continue; }
                if (grid.data[check[0]][check[1]] == grid.graphics[2]) { return; }
            }
        }
        
        this.rot = rot;
        var excess = this.piece[this.rot][0].length+this.left-grid.width;
        if (excess > 0)
        {
            this.move(-excess);
        }
    },
    // ----
    check_end: function() {
        if (this.top+this.piece[this.rot].length >= grid.height)
        {
            return true;
        }
    },
    check_blocked: function() {
        var piece = this.piece[this.rot];
        var check = [];
        for (var y = 0; y < piece.length; y++)
        {
            for (var x = 0; x < piece[y].length; x++)
            {
                if (piece[y][x] != 2) { continue; }
                check = [y+this.top+1,x+this.left];
                if (check[0] >= grid.height) { return true; }
                if (grid.data[check[0]][check[1]] == grid.graphics[2])
                {
                    return true;
                }
            }
        }
    },
    check_side: function(dir) {
        var piece = this.piece[this.rot];
        var ux, uy;
        for (var y = 0; y < piece.length; y++)
        {
            for (var x = 0; x < piece[y].length; x++)
            {
                if (!piece[y][x]) { continue; }
                uy = y+this.top;
                ux = x+this.left+dir;
                if (grid.data[uy][ux] == grid.graphics[2]) 
                { 
                    return true; 
                }
                if (ux == -1) { return true; }
                if (ux == grid.width) { return true; }
            }
        }
        
    },
    next: function() {
        lines.add_piece();
        this.new_piece();
    }
};

var game = {
    level: 0,
    level_drop: 60,
    // ----
    speed: 1000,
    score: 0,
    line_scores: {
        1: 40,
        2: 100,
        3: 300,
        4: 1200
    },
    line_score: function(amt) {
        if (!amt) { return; }
        amt = this.line_scores[amt]*(this.level+1);
        this.score += amt;
    },
    score_drop: function(amt) {
        amt = grid.height-amt;
        amt *= 2;
        this.score += amt;
        grid.render();
    },
    next_level: function() {
        if (this.level >= 20) { return; }
        stop();
        this.level++;
        this.speed -= this.level_drop;
        this.start_timer();
    },
    start: function() {
        this.level = 0;
        this.speed = 1000;
        this.score = 0;
        
        lines.lines = 0;
        pieces.next_piece = [];
        pieces.next_piece = obj_pick(pieces_data);
        
        grid.init();
        
        stop();
    },
    play: function() {
        grid.mode = 'play';
        pieces.new_piece();
        this.start_timer();
    },
    start_timer: function() {
        _drop = setInterval(function() {
             pieces.slow_drop();
             pieces.render();
        },this.speed);
    },
    reset: function() {
        if (grid.mode == 'resize') { return; }
        grid.mode = 'start';
        this.start();
    },
    resize: function(width,height) {
        grid.width += width;
        grid.height += height;
        grid.init();
        this.reset();
    },
    over: function() {
        stop();
        lines.add_piece();
        grid.mode = 'game_over';
        grid.render();
    }
};

var controls = {
    left: function() {
        if (grid.mode == 'start') { return game.play(); }
        if (grid.mode == 'resize') { return game.resize(-1,0); }
        pieces.move(-1);
        pieces.render();
    },
    up: function() {  
        if (grid.mode == 'start') { return game.play(); }
        if (grid.mode == 'resize') { return game.resize(0,-1); }
        pieces.rotate();
        pieces.render();
    },
    right: function() {
        if (grid.mode == 'start') { return game.play(); }
        if (grid.mode == 'resize') { return game.resize(1,0); }
        pieces.move(1);
        pieces.render();
    },
    down: function() {
        if (grid.mode == 'start') { return game.play(); }
        if (grid.mode == 'resize') { return game.resize(0,1); }
        game.score++;
        pieces.slow_drop();
        pieces.render();
    },
    space: function() {
        if (grid.mode == 'pause') { return game.reset(); }
        if (grid.mode == 'start') { return game.play(); }
        pieces.fast_drop();
    },
    pause: function() {
        if (grid.mode == 'game_over')
        {
            game.reset();
            return;
        }
        if (grid.mode != 'pause')
        {
            stop();
            grid.mode = 'pause';
            grid.render();
            return;
        }
        
        grid.mode = 'play';
        game.start_timer();
        grid.render();
    },
    // ----
    enter: function() {
        if (grid.mode == 'resize')
        {   
            grid.mode = 'play';
            game.play();  
            return;
        }
        
        stop();
        grid.mode = 'resize';    
        grid.render();
    }
};

var _keyboard = function(e) {
    var code = e.keyCode;
    
    if (code == 8)
    {
        stop();
        grid.el.removeEventListener('keydown',_keyboard);
        grid.el.value = '';
        return; 
    }
    
    var codes = {
        37: 'left',
        38: 'up',
        39: 'right',
        40: 'down',
        32: 'space',
        27: 'pause',
        13: 'enter'
    };
       
    if (grid.mode == 'game_over')
    {
        if (code == 27)
        {
            game.reset();
        }
        return;
    }
    
    code = codes[code];
    if (!code) { return; }
    controls[code]();
};

grid.width = 10;
grid.height = 12;
grid.el = document.getElementsByTagName('textarea')[0];
grid.el.style.fontFamily = 'Courier';
grid.el.style.fontSize = '1.2em';
grid.el.style.height = '360px';
grid.el.style.lineHeight = '1em';
game.start();

grid.el.addEventListener('keydown',_keyboard);
grid.el.focus();