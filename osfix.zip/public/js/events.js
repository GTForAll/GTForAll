// TODO: Should really stick this in an object
$(".survey-answer").change(function() {
	var el = $(this).closest('td').find('.survey-answer-custom');
	var val = $(this).val();
	if (val == 'custom')
	{
		el.show();
	}
	else
	{
		el.val('').hide();
	}
});

$("#survey-add").click(function(e) {
	e.preventDefault();
	var cc = $("#survey-question-template").clone().show();
	cc.find('input[type=text]').val('');
	cc.find('select').val('poll');
	cc.find('.survey-question-choices').show();
	cc.attr('id','');
	cc.appendTo("#survey-questions-list");
	bind_survey();
});

function bind_survey() {
	$(".survey-question-type select").change(function() {
		var el = $(this).closest('.survey-question').find('.survey-question-choices');
		var val = $(this).val();
		if (val == 'poll' || val == 'free_poll')
		{
			el.show();
		}
		else
		{
			el.hide();
		}
	});
}

bind_survey();

$(".inline-spoiler").mouseover(function() {
	$(this).css('color','efefef');
}).mouseout(function() {
	$(this).css('color','000');
}).click(function() {
	$(this).css('color','');
	$(this).removeClass('inline-spoiler');
	$(this).unbind();
});

function bscroll(el) {
	if (typeof el == 'undefined')
	{
		return $(window).scrollTop(document.body.scrollHeight);
	}
	$(el).scrollTop($(el).prop('scrollHeight'));
}

function toggle(el)
{
	$("#"+el).toggle();
}

function login_first()
{
	window.location.href = '/login';
}

function say(d)
{
	alert(JSON.stringify(d));
}

$(".show-picture").click(function(e) {
	e.preventDefault();
	var img = $(this).find('img');
	img.addClass('img-full');
});

$(".self-dupe").change(function() {
	var el = $(this).clone();
	var val = $(this).val();

	el.appendTo($(this).parent());
	el.val(val);
	$(this).val('');
	$(this).appendTo($(this).parent());

	$(this).find("option[value='"+val+"']").remove();

	if ($(this).find('option').length == 1)
	{
		$(this).hide();
	}
});

$(".search-mine").click(function(e) {
	e.preventDefault();
	$(this).parent().find('input').val($(this).attr('user'));
	$(this).hide();
});


$("#posting-as-change").click(function(e) {
	e.preventDefault();
	$(this).closest('tr').hide();
	$(this).closest('table').find('.ups').fadeIn();
	$("input[name=use_primary]").val(0);
});

function d2u(u)
{
	return u.replace('-','_');
}

// TODO: Should really merge all three of these.
function bind_triggers()
{
	$(".trigger").unbind().click(function(e) {
		e.stopPropagation();
		var obj = $(this).attr('obj');
		var func = $(this).attr('func');
		var var1 = $(this).attr('var1');
		var var2 = $(this).attr('var2')

		if (var1 == '#self') { var1 = $(this); }

		if (!obj)
		{
			window[func](var1,var2);
			return;
		}

		window[obj][func](var1,var2);
	});
}

bind_triggers();

function bind_links()
{
	$("a[obj]").unbind().click(function(e) {
		e.preventDefault();
		e.stopPropagation();

		if ($(this).hasClass('confirm'))
		{
			$(this).removeClass('confirm');
			$(this).html('Confirm');
			$(this).addClass('confirm-color');
			return;
		}

		var obj = $(this).attr('obj');
		var func = $(this).attr('func');
		var var1 = $(this).attr('var1');
		var var2 = $(this).attr('var2');
		var var3 = $(this).attr('var3')

		if (var1 == '#self') { var1 = $(this); }

		window[obj][func](var1,var2,var3);
	});
}

bind_links();

function bind_buttons()
{
	$("input[type=button]").not('.no-unbind').unbind().click(function() {
		var obj = $(this).attr('obj');
		var func = $(this).attr('func');
		var var1 = $(this).attr('var1');

		if (var1 == '#self') { var1 = $(this); }

		window[obj][func](var1,$(this).attr('var2'),$(this).attr('var3'),$(this).attr('var4'));
	});
}

bind_buttons();


$(".mark").change(function() {
	$(this).parent().toggleClass('tagsel');
	$(this).closest('.tr,tr').toggleClass('marked');
	mark.last = $(this);
	if ($('.marked').length)
	{
		$("#mod-tools").show();
	}
	else
	{
		$("#mod-tools").hide();
	}
});

$("#mod-tools input").change(function() {
	$(this).parent().find('input').each(function() {
		if ($(this).is(':checked'))
		{
			$(this).parent().addClass('tagsel');
		}
		else
		{
			$(this).parent().removeClass('tagsel');
		}
	});
});

$(".marker,.marker label").click(function() {
	$(this).find('input').trigger('click');
});

$("#navs a[ajax_html]").click(function(e) {
	e.preventDefault();
	e.stopPropagation();
	nav.open($(this));
});

$(document).click(function() {
	$(".needy").hide();
});

$(".needy").click(function(e) {
	e.stopPropagation();
});

$(".search-date").click(function() {
	var val = $(this).val();
	if (val == 'between')
	{
		$("#date-between").show();
	}
	else
	{
		$("#date-between").hide();
	}
});

$("label input").change(function() {
	$(this).closest('label').toggleClass('labelsel');
});
