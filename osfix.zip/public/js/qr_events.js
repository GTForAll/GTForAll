
var quicksmart = {
	auto_quote: 0,
	scroll: -1,
	pos: [undefined,undefined],
	toggle: function() {
		var el = $("#quickr");
		if (!el.hasClass('popped'))
		{
			this.pop();
		}
		else
		{
			this.unpop();
		}
	},
	open: function(txt) {
		var html = $("#quickreply").val();
		var last_char = html.substr(-1,1); 
		if (last_char != "\n")
		{
			html += "\n";
		}
		$("#quickreply").val(html+'> '+txt+'\n\n'); 
		this.pop();
	},
	get_sel: function() {
		var sel = window.getSelection();
		var txt = sel.toString();
		if (!txt) { txt = ''; }
		return txt;
	},
	mouseup: function(e) {
		var txt = quicksmart.get_sel();
		if (txt.length < 5) { return; }
		
		if (this.auto_quote)
		{
			return quicksmart.open(txt);
		}
		
		$("#auto-quote").show();
		$("#auto-quote").css({ left: e.pageX+2, top: e.pageY+2 }); 
		
		$(".posts-message").unbind().mouseup(function(e) {
			$("#auto-quote").hide();
			$(this).mouseup(function(e) {
				quicksmart.mouseup(e);
			});
			
			if (quicksmart.get_sel().length > 5)
			{
				quicksmart.mouseup(e);
			}
		});
		
		return;
		
	},
	pop: function() {
		
		// #quickr, #firstp-wrapper, #quickreply, #content, .posts-user-top, #message-buttons-inner, #pop
		$("#quickr").addClass('popped');
		
		$("#firstp-wrapper").addClass('posts-left');
		$("#quickreply").focus();
		$("#quickreply").scrollTop($("#quickreply").scrollHeight-$("#quickreply").height());
		$("#content").removeClass('table-center');
		
		// TODO: css(height), not height()
		$("#quickreply").height(screen.height-$("#head").height()-$("#pop").height()-220);
		$("#quickreply").width(screen.width-$(".posts-left:first").width()-160);
		bscroll("#quickreply");
		
		$(".posts-user-top").show();
		$("#message-buttons-inner").appendTo($("#pop"));
		
		if (this.scroll != -1)
		{
			$(window).scrollTop(this.scroll);
		}
	},
	unpop: function(scroll_down) {
		if (typeof scroll_down == 'undefined')
		{
			scroll_down = true;
		}

		$("#quickr").removeClass('popped');
		
		$("#firstp-wrapper").removeClass('posts-left');
		$("#content").addClass('table-center');
		$("#quickreply").height('initial');
		$("#quickreply").width('initial');
		
		$(".posts-user-top").hide();
		
		$("#message-buttons-inner").appendTo($("#message-buttons-right"));
		
		this.scroll = $(window).scrollTop();
		if (scroll_down)
		{
			bscroll();
		}
	},
	close: function() {
		this.unpop(false);
		this.scroll = -1;
	}
};

// TODO: Should merge the above into this
var qr = {
	pop: function() {
		quicksmart.pop();
		$("#qr-popper").attr('func','unpop').html('Collapse');
	},
	unpop: function() {
		quicksmart.unpop();
		$("#qr-popper").attr('func','pop').html('Expand');
	}
};

$(document).mousemove(function(e) {
	if (quicksmart.pos[0] == undefined && quicksmart.pos[1] == undefined)
	{
		return;
	}
	
		e.preventDefault();
	
	var x_dist = quicksmart.pos[0]-e.pageX;
	var y_dist = quicksmart.pos[1]-e.pageY;
	
	var height = $("#quickreply").height();
	var width = $("#quickreply").width();
	
	height += y_dist;
	width += x_dist; 
	
	$("#quickreply").height(height);
	$("#quickreply").width(width);
	
	quicksmart.pos = [e.pageX,e.pageY];
});

$(document).mouseup(function(e) {
	e.preventDefault();
	quicksmart.pos = [undefined,undefined];
});

