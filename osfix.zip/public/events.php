<?php
$_SERVER['REQUEST_URI'] = '/events';
require "index.php";